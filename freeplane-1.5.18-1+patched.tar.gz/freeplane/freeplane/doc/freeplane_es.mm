<map version="freeplane 1.5.9">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node FOLDED="false" ID="Freeplane_Link_37609021" CREATED="1124560950701" MODIFIED="1170661549281" COLOR="#993300"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body width="">
    <p align="center">
      Freeplane<br/><small>- Aplicaci&#243;n libre para la creaci&#243;n de mapas mentales -</small>&#160;
    </p>
  </body>
</html>

</richcontent>
<font NAME="Dialog" SIZE="18" BOLD="true"/>
<hook NAME="MapStyle">
    <properties fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt" TEXT_SHORTENED="true">
<font SIZE="24"/>
<richcontent TYPE="DETAILS" LOCALIZED_HTML="styles_background_html"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="default" COLOR="#000000" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0.0 pt" FORMAT="NO_FORMAT" TEXT_ALIGN="CENTER" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font NAME="Arial" SIZE="9" BOLD="true" ITALIC="false"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details">
<font SIZE="11"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#000000" BACKGROUND_COLOR="#ffffff">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
<edge COLOR="#0000cc"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" UNIFORM_SHAPE="true" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font SIZE="24" ITALIC="true"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2">
<edge COLOR="#ff0033"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3">
<edge COLOR="#009933"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4">
<edge COLOR="#3333ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5">
<edge COLOR="#ff6600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6">
<edge COLOR="#cc00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7">
<edge COLOR="#ffbf00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8">
<edge COLOR="#00ff99"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9">
<edge COLOR="#0099ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10">
<edge COLOR="#996600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12">
<edge COLOR="#cc0066"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13">
<edge COLOR="#33ff00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14">
<edge COLOR="#ff9999"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15">
<edge COLOR="#0000cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16">
<edge COLOR="#cccc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17">
<edge COLOR="#0099cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18">
<edge COLOR="#006600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19">
<edge COLOR="#ff00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20">
<edge COLOR="#00cc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21">
<edge COLOR="#0066cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22">
<edge COLOR="#00ffff"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="P&#xe1;gina web de Freeplane" POSITION="left" ID="Freeplane_Link_367746551" CREATED="1124560950701" MODIFIED="1170318639020" LINK="http://freeplane.sourceforge.net">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Tabla de teclas r&#xe1;pidas" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1091417446" CREATED="1124560950701" MODIFIED="1170318817613" COLOR="#006699">
<node TEXT="Comandos de fichero&#xa;Nuevo mapa                                      - Ctrl+N&#xa;Abrir mapa                                      - Ctrl+O&#xa;Guardar mapa                                    - Ctrl+S&#xa;Guardar como&#x2026;                                   - Ctrl+A&#xa;Imprimir                                        - Ctrl+P&#xa;Cerrar                                          - Ctrl+Q&#xa;Mapa anterior                                   - Ctrl+Izquierda&#xa;Mapa siguiente                                  - Ctrl+Derecha&#xa;Exportar fichero a HTML                         - Ctrl+E&#xa;Exportar rama a HTML                            - Ctrl+H&#xa;Exportar rama a un nuevo fichero MM             - Alt+A&#xa;Abrir el primer fichero del hist&#xf3;rico           - Ctrl+SHIFT (MAY&#xda;SCULAS)+W&#xa;&#xa;Comandos de edici&#xf3;n&#xa;Buscar                                          - Ctrl+F&#xa;Buscar siguiente                                - Ctrl+G&#xa;Cortar                                          - Ctrl+X&#xa;Copiar                                          - Ctrl+C&#xa;Copiar elemento                                 - Ctrl+Y&#xa;Pegar                                           - Ctrl+V&#xa;&#xa;Comandos de modos&#xa;Modo Mapa mental (MindMap)                      - Alt+1&#xa;Modo navegaci&#xf3;n                                 - Alt+2&#xa;Modo fichero                                    - Alt+3&#xa;&#xa;Comandos de formato de nodos&#xa;Cursiva                                         - Ctrl+I&#xa;Negrita                                         - Ctrl+B&#xa;Nube (Cloud)                                    - Ctrl+SHIFT (MAY&#xda;SCULAS)+B&#xa;Cambiar el color del nodo                       - Alt+C&#xa;Mezclar el color del nodo                       - Alt+B&#xa;Cambiar el color del borde del nodo             - Alt+E&#xa;Aumentar el tama&#xf1;o de letra del nodo            - Ctrl+L&#xa;Disminuir el tama&#xf1;o de letra del nodo           - Ctrl+M&#xa;Aumentar el tama&#xf1;o de letra de la rama          - Ctrl+SHIFT (MAY&#xda;SCULAS)+L&#xa;Disminuir el tama&#xf1;o de letra de la rama         - Ctrl+SHIFT (MAY&#xda;SCULAS)+M&#xa;&#xa;Comandos del modo navegaci&#xf3;n&#xa;Ir a la ra&#xed;z                                    - ESCAPE&#xa;Subir                                           - ARRIBA&#xa;Bajar                                           - ABAJO&#xa;Izquierda                                       - IZQUIERDA&#xa;Derecha                                         - DERECHA&#xa;Seguir el enlace                                - Ctrl+ENTER&#xa;Disminuir Zoom                                  - Alt+ARRIBA&#xa;Aumentar Zoom                                   - Alt+ABAJO&#xa;&#xa;Comandos para un nuevo nodo&#xa;A&#xf1;adir un nodo hermano                          - ENTER&#xa;A&#xf1;adir un nodo hijo                             - INSERT&#xa;A&#xf1;adir un nodo hermano anterior (padre)         - SHIFT (MAY&#xda;SCULAS)+ENTER&#xa;&#xa;Comandos de edici&#xf3;n de nodos&#xa;Editar el nodo seleccionado                     - F2&#xa;Editar la longitud del nodo                     - Alt+ENTER&#xa;Unir nodos                                      - Ctrl+J&#xa;Desplegar/Replegar nodo                         - BARRA ESPACIADORA&#xa;Desplegar/Replegar todas las ramas de un nodo   - Ctrl+BARRA ESPACIADORA&#xa;Establecer enlace con un fichero                - Ctrl+SHIFT (MAY&#xda;SCULAS)+K&#xa;Establecer enlace con una entrada de texto      - Ctrl+K&#xa;Establecer enlace con un fichero de imagen      - Alt+K&#xa;Subir nodo (mover)                              - Ctrl+ARRIBA&#xa;Bajar nodo (mover)                              - Ctrl+ABAJO" ID="Freeplane_Link_1439762647" CREATED="1124560950701" MODIFIED="1170662308844" COLOR="#338800">
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node TEXT="Instalaci&#xf3;n" FOLDED="true" POSITION="left" ID="_Freeplane_Link_904501221" CREATED="1124560950701" MODIFIED="1170319517218" COLOR="#006633">
<arrowlink SHAPE="LINE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_904501221" STARTINCLINATION="0;0;" ENDINCLINATION="0;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<node TEXT="Enlaces" FOLDED="true" ID="_Freeplane_Link_1911559485" CREATED="1124560950701" MODIFIED="1170319539983" COLOR="#006699">
<node TEXT="Descargar el entorno de ejecuci&#xf3;n de Java (J2RE 1.4 &#xf3; superior)" ID="Freeplane_Link_355384845" CREATED="1124560950701" MODIFIED="1170319548608" LINK="http://java.sun.com/j2se">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Descargar la aplicaci&#xf3;n" ID="_Freeplane_Link_1612101865" CREATED="1124560950701" MODIFIED="1170319561858" LINK="http://sourceforge.net/project/showfiles.php?project_id=211069">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Para instalar Freeplane en Microsoft Windows, instalar Java de Sun e instalar Freeplane usando el instalador de &#xe9;ste." ID="Freeplane_Link_1046224624" CREATED="1170319584827" MODIFIED="1170319584827"/>
<node TEXT="Para instalar Freeplane en Linux, descargar el entorno de ejecuci&#xf3;n de Java y la propia aplicaci&#xf3;n de Freeplane. Primero instale Java, y despu&#xe9;s descomprima Freeplane. Para usar Freeplane, ejecutar freeplane.sh." ID="ID_1422958662" CREATED="1170319584827" MODIFIED="1170319584827"/>
<node TEXT="En Microsoft Windows y MAC OS X, tambi&#xe9;n puede hacer doble click en el fichero freeplane.jar alojado en carpeta lib para ejecutar Freeplane." ID="ID_1849276090" CREATED="1170319584827" MODIFIED="1170319584827"/>
</node>
<node TEXT="Explorando los ficheros de su ordenador" FOLDED="true" POSITION="left" ID="_Freeplane_Link_353522063" CREATED="1124560950701" MODIFIED="1170319618577" COLOR="#407000">
<node TEXT="Para explorar los ficheros en su ordenador, seleccione el modo fichero en el men&#xfa; desplegable Modos &#xf0e0; File. [Alt+3]" ID="Freeplane_Link_1640650757" CREATED="1170320065246" MODIFIED="1170661644279" HGAP_QUANTITY="25.0 px" VSHIFT_QUANTITY="-13.0 px"/>
<node TEXT="Navegar&#xe1; por su &#xe1;rbol de ficheros/directorios como si fuese un mapa mental. " ID="Freeplane_Link_555797793" CREATED="1170320065246" MODIFIED="1170661634201"/>
<node TEXT="Para hacer que una carpeta sea el nodo central, en el men&#xfa; contextual de nodos (Bot&#xf3;n izquierdo del rat&#xf3;n en el nodo) seleccione &#x201c;Centrar&#x201d;." ID="Freeplane_Link_1148324994" CREATED="1170320065246" MODIFIED="1170320065246"/>
<node TEXT="Para ver, editar &#xf3; ejecutar fichero, siga el enlace de su nodo." ID="Freeplane_Link_1098215924" CREATED="1170320065246" MODIFIED="1170326984528"/>
<node TEXT="El modo fichero actualmente no es muy &#xfa;til. Es una demostraci&#xf3;n de que no es mucho m&#xe1;s dif&#xed;cil generar &#xe1;rboles de informaci&#xf3;n desde otras fuentes que de mapas mentales. No hay evidencia de que actualmente la gente utilice este modo." ID="Freeplane_Link_223431013" CREATED="1170320065246" MODIFIED="1170662169175"/>
</node>
<node TEXT="Explorando mapas mentales" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1530607683" CREATED="1124560950701" MODIFIED="1170661606154" COLOR="#407000">
<node TEXT="Tanto para explorar como para editar mapas mentales, seleccione el modo navegaci&#xf3;n (Browse) en el men&#xfa; desplegable Modos&#xf0e0;Browse. [Alt+2]" ID="Freeplane_Link_1803255787" CREATED="1170327125916" MODIFIED="1170661616154"/>
<node TEXT="Las razones para separar el modo de exploraci&#xf3;n son t&#xe9;cnicas. Navegar &#xf3; explorar es lo &#xfa;nico que se puede hacer con el applet que se puede colocar en su sitio web. Normalmente, usted no usar&#xe1; el modo exploraci&#xf3;n en Freeplane." ID="ID_422041960" CREATED="1170327125916" MODIFIED="1170327125916"/>
</node>
<node TEXT="Sobre los modos" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1136088046" CREATED="1124560950701" MODIFIED="1170327167056" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Aunque Freeplane es principalmente una herramienta para editar mapas mentales, est&#xe1; dise&#xf1;ado para ser capaz de visualizar informaci&#xf3;n de diversas fuentes de datos. Para hacer una fuente de datos espec&#xed;fica visible en Freeplane, un programador tiene que escribirla con un modo a tal fin. El modo fichero es un ejemplo. No sabemos si se han implementado otros modos. No est&#xe1; claro si alguien realmente querr&#xed;a hacer uso de esta arquitectura; es un recurso a explotar si alguien est&#xe1; interesado y lo desea hacer." ID="Freeplane_Link_1279853809" CREATED="1170327180322" MODIFIED="1170661662794" HGAP_QUANTITY="30.0 px" VSHIFT_QUANTITY="4.0 px"/>
<node TEXT="Hay c&#xf3;digo casi preparado para el modo &#x201c;esquema&#x201d; (Scheme) que deja editar programas de esquematizaci&#xf3;n. De nuevo, la utilidad no est&#xe1; clara. A diferencia del modo de mapa mental, otros modos son m&#xe1;s bien demostraciones de las posibilidades de la aplicaci&#xf3;n diferentes a las actuales." ID="Freeplane_Link_501151798" CREATED="1170327180322" MODIFIED="1170661865274"/>
</node>
<node TEXT="Instalar el applet de Freeplane en su sitio web" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1525986009" CREATED="1124560950701" MODIFIED="1170327302117" COLOR="#407000">
<node TEXT="Usted puede instalar el applet en su sitio web para que otros usuarios puedan ver su mapas mentales." ID="Freeplane_Link_728262703" CREATED="1170327314148" MODIFIED="1170662179237"/>
<node TEXT="Descargue el applet, que se llama freeplane-browser." ID="Freeplane_Link_1253169862" CREATED="1124560950701" MODIFIED="1170327467943" LINK="http://sourceforge.net/project/showfiles.php?group_id=211069" VSHIFT_QUANTITY="-6.0 px"/>
<node TEXT="El fichero descargado contiene los ficheros freeplanebrowser.jar y freeplanebrowser.html. Cree un enlace desde su p&#xe1;gina al freeplanebrowser.html. En el fichero freeplanebrowser.html cambie la ruta para que apunte a su mapa mental." ID="Freeplane_Link_748768856" CREATED="1170327314148" MODIFIED="1170662189253"/>
<node TEXT="El fichero de extensi&#xf3;n .jar del applet debe estar alojado en el mismo servidor que el mapa, por razones de seguridad de Java. Tiene que subir por tanto, el fichero .jar del applet de Freeplane y su mapa mental a su sitio web." ID="Freeplane_Link_1041757100" CREATED="1170327314164" MODIFIED="1170662204284"/>
</node>
<node TEXT="Usando el applet de Freeplane" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1083756111" CREATED="1124560950701" MODIFIED="1170327531427" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="En el applet de Freeplane, s&#xf3;lo puede usar el modo exploraci&#xf3;n/navegaci&#xf3;n; no podr&#xe1; editar los mapas. Haga click en el nodo para desplegar/replegarlo, o para seguir un enlace. Arrastre el fondo para mover el mapa. Para buscar dentro del mapa, utilice el modo contextual de los nodos. (Bot&#xf3;n izquierdo del rat&#xf3;n)." ID="Freeplane_Link_1893434848" CREATED="1170327537224" MODIFIED="1170327537224"/>
</node>
<node TEXT="Cambios en la interfaz de usuario en la versi&#xf3;n 0.6.5" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1976458022" CREATED="1124560950701" MODIFIED="1170327564379" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Algunas configuraciones de teclado han tenido que ser redefinidas para darles un uso m&#xe1;s intuititvo y considerado est&#xe1;ndar. Algunas de las nuevas configuraciones de teclado son usadas en herramientas de Microsoft. La nueva configuraci&#xf3;n de teclas incluyen el &#x201c;Enter&#x201d; para editar nuevos nodos sobre el seleccionado, insertar nuevos nodos hijos, F2 para editar los nodos &#x2013; Aqu&#xed; la influencia de Microsoft es aparente aunque puede que no hay una raz&#xf3;n de uso intuitivo para usar la tecla F2 para tener que editar nodos. Pero una vez que se acostumbre al uso de las teclas r&#xe1;pidas en todas las aplicaciones que use (En ingl&#xe9;s, claro), querr&#xe1; hacer uso de ellas en Freeplane tambi&#xe9;n." ID="Freeplane_Link_361392781" CREATED="1170327577817" MODIFIED="1170327577817"/>
<node TEXT="La configuraci&#xf3;n del teclado puede cambiarse en el men&#xfa; desplegable Herramientas &#xf0e0; Preferencias (Preferences)." ID="ID_1876397405" CREATED="1170327577817" MODIFIED="1170327577817"/>
</node>
<node TEXT="Cr&#xe9;ditos" FOLDED="true" POSITION="left" ID="_Freeplane_Link_784043927" CREATED="1124560950701" MODIFIED="1170327604301" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Autores" FOLDED="true" ID="Freeplane_Link_415458128" CREATED="1124560950701" MODIFIED="1170327624629" COLOR="#006699">
<node TEXT="Joerg Mueller" FOLDED="true" ID="_Freeplane_Link_1896457660" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="ponders@t-online.de" ID="ID_1053467941" CREATED="1124560950701" MODIFIED="1124560950701" LINK="mailto:ponders@t-online.de" COLOR="#558000">
<font NAME="Dialog" SIZE="10"/>
</node>
<node TEXT="Universidad de Freiburg, Alemania" ID="Freeplane_Link_268552515" CREATED="1124560950701" MODIFIED="1170327672284" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Daniel Polansky" ID="_Freeplane_Link_984984595" CREATED="1124560950701" MODIFIED="1124560950701" LINK="http://mujweb.cz/www/danielpolansky" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Petr Novak" ID="_Freeplane_Link_459203293" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Christian Foltin" ID="_Freeplane_Link_875814410" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Dimitri Polivaev" ID="_Freeplane_Link_1415293905" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Peque&#xf1;as contribuciones" FOLDED="true" ID="Freeplane_Link_816166020" CREATED="1124560950701" MODIFIED="1170327637519" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Andrew Iggleden" FOLDED="true" ID="Freeplane_Link_189984007" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Instalador de Windows" ID="Freeplane_Link_117526613" CREATED="1124560950701" MODIFIED="1170327651956" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Bob Alexander" FOLDED="true" ID="Freeplane_Link_1096673251" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Eclipse howto" ID="ID_585592040" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="David Butt" FOLDED="true" ID="Freeplane_Link_1024053399" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Tutorial flash" ID="ID_133522658" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="David Low" FOLDED="true" ID="Freeplane_Link_1534904708" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Helpful" ID="ID_743506244" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
</node>
<node TEXT="Traducciones" FOLDED="true" ID="Freeplane_Link_360501151" CREATED="1124560950701" MODIFIED="1170327642550" COLOR="#006699">
<node TEXT="Bob Alexander" FOLDED="true" ID="Freeplane_Link_807977431" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Italian translation" ID="ID_1524052044" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Knud Riish&#xf8;jg&#xe5;rd" FOLDED="true" ID="Freeplane_Link_1853214917" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Danish translation" ID="ID_1376899494" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Takeshi Kakeda" FOLDED="true" ID="Freeplane_Link_1676529317" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Japanese translation" ID="ID_1398373821" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Kohichi Aoki" FOLDED="true" ID="Freeplane_Link_1172193026" CREATED="1124562983644" MODIFIED="1124562984816" COLOR="#996600">
<node TEXT="Japanese translation" ID="ID_1500966066" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Alex Dukal" FOLDED="true" ID="Freeplane_Link_1928961904" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Spanish translation" ID="ID_1410733080" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Hugo Gayosso" FOLDED="true" ID="Freeplane_Link_757563697" CREATED="1124562998159" MODIFIED="1124563008034" COLOR="#996600">
<node TEXT="Spanish translation" ID="Freeplane_Link_1783275246" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Sylvain Gamel" FOLDED="true" ID="Freeplane_Link_929540960" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<node TEXT="French translation" ID="ID_1545871352" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Koen Roggemans" FOLDED="true" ID="Freeplane_Link_946171164" CREATED="1124561242082" MODIFIED="1124561245019" COLOR="#996600">
<node TEXT="Dutch translation" ID="Freeplane_Link_1819881845" CREATED="1124561245957" MODIFIED="1124561251675" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Rafal Kraik" FOLDED="true" ID="Freeplane_Link_235962981" CREATED="1124561374999" MODIFIED="1124561376718" COLOR="#996600">
<node TEXT="Polish translation" ID="Freeplane_Link_459079511" CREATED="1124561377702" MODIFIED="1124561382155" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Goliath" FOLDED="true" ID="Freeplane_Link_653284985" CREATED="1124561969717" MODIFIED="1124561972920" COLOR="#996600">
<node TEXT="Korean translation" ID="Freeplane_Link_1387213811" CREATED="1124561438294" MODIFIED="1124561445950" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Miles a.k.a. filmsi" FOLDED="true" ID="Freeplane_Link_35211963" CREATED="1124561753254" MODIFIED="1124563712385" COLOR="#996600">
<node TEXT="Slovenian translation" ID="Freeplane_Link_835144271" CREATED="1124561491886" MODIFIED="1124561506386" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="William Chen" FOLDED="true" ID="Freeplane_Link_1008886206" CREATED="1124561814721" MODIFIED="1124561818580" COLOR="#996600">
<node TEXT="Chinese translation" ID="Freeplane_Link_1960552629" CREATED="1124561497308" MODIFIED="1124561506011" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Radek &#x160;varc" FOLDED="true" ID="Freeplane_Link_1650138043" CREATED="1124561823877" MODIFIED="1124561876907" COLOR="#996600">
<node TEXT="Czech translation" ID="Freeplane_Link_768227373" CREATED="1124561515761" MODIFIED="1124561519885" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Bal&#xe1;zs M&#xe1;rton" FOLDED="true" ID="Freeplane_Link_901975324" CREATED="1124562250475" MODIFIED="1124562252007" COLOR="#996600">
<node TEXT="Hungarian translation" ID="Freeplane_Link_557911120" CREATED="1124562252585" MODIFIED="1124562258428" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Luis Ferreira " FOLDED="true" ID="Freeplane_Link_290351026" CREATED="1124562948942" MODIFIED="1124562950270" COLOR="#996600">
<node TEXT="Portuguese translation" ID="Freeplane_Link_6081004" CREATED="1124562956332" MODIFIED="1124562961879" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="The credits for translations are probably incomplete. If we have forggoten you, let us know. All people who we know to contribute a least an incomplete translation are listed." ID="Freeplane_Link_23652566" CREATED="1124563066204" MODIFIED="1124563189197" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node TEXT="Pulse Ctrl+F para buscar. Pulse Ctrl+G para buscar el siguiente. Para hacer un b&#xfa;squeda global, pulse ESCAPE antes de la b&#xfa;squeda." POSITION="right" ID="Freeplane_Link_1273736577" CREATED="1124560950701" MODIFIED="1170327716253" COLOR="#0033ff"/>
<node TEXT="Pulse DERECHA para desplegar una caja de texto." POSITION="right" ID="Freeplane_Link_1043530021" CREATED="1124560950701" MODIFIED="1170338370893" COLOR="#0033ff"/>
<node TEXT="Introducci&#xf3;n" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1596161299" CREATED="1124560950701" MODIFIED="1170338378534" COLOR="#407000">
<node TEXT="Freeplane hace posible la creaci&#xf3;n los llamados mapas mentales. Es m&#xe1;s, la gente la utiliza como alternativa de un bloc de notas tabulado &#xf3; de un gestor personal de informaci&#xf3;n." ID="Freeplane_Link_792489824" CREATED="1170338389205" MODIFIED="1170661902868" VSHIFT_QUANTITY="-1.0 px"/>
<node TEXT="La informaci&#xf3;n se almacena en cajas de texto, llamados nodos. Los nodos se conectan entre s&#xed; usando l&#xed;neas curvas llamadas bordes (ramas)." ID="ID_1465373711" CREATED="1170338389205" MODIFIED="1170338389205"/>
<node TEXT="Esta es una documentaci&#xf3;n para Freeplane 0.8.0, por lo que el mapeo de teclas r&#xe1;pidas &#xf3; las funciones de los men&#xfa;s pueden cambiar de una versi&#xf3;n a otra." ID="ID_1313498008" CREATED="1170338389205" MODIFIED="1170338389205"/>
</node>
<node TEXT="Demostraci&#xf3;n de algunas caracter&#xed;sticas" FOLDED="true" POSITION="right" ID="_Freeplane_Link_706084071" CREATED="1124560950701" MODIFIED="1170401730966" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Apariencia" FOLDED="true" ID="_Freeplane_Link_735193624" CREATED="1124560950701" MODIFIED="1170401751153" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Los nodos pueden tener diferentes colores" FOLDED="true" ID="Freeplane_Link_801391449" CREATED="1124560950701" MODIFIED="1170401759200">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Rojo" ID="Freeplane_Link_1935642015" CREATED="1124560950701" MODIFIED="1170401763778" COLOR="#ff0000">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Verde" ID="Freeplane_Link_358662946" CREATED="1124560950701" MODIFIED="1170401767216" COLOR="#009900">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Azul" ID="Freeplane_Link_569149865" CREATED="1124560950701" MODIFIED="1170401772466" COLOR="#0000cc">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Los nodos pueden tener varios colores de fondo" FOLDED="true" ID="_" CREATED="1124560950701" MODIFIED="1170401783950">
<node TEXT="&#xc9;ste" ID="_Freeplane_Link_1358611533" CREATED="1124560950701" MODIFIED="1170401812419" BACKGROUND_COLOR="#ff66cc"/>
<node TEXT="&#xf3; &#xe9;ste" ID="_Freeplane_Link_1317973766" CREATED="1124560950701" MODIFIED="1170401826248" BACKGROUND_COLOR="#66ff66"/>
</node>
<node TEXT="Los nodos pueden tener diferentes estilos de fuentes" FOLDED="true" ID="Freeplane_Link_542663260" CREATED="1124560950701" MODIFIED="1170401836498">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Negrita" ID="Freeplane_Link_807716236" CREATED="1124560950701" MODIFIED="1170401842685">
<font NAME="Dialog" SIZE="12" BOLD="true"/>
</node>
<node TEXT="Cursiva" ID="Freeplane_Link_1517956725" CREATED="1124560950701" MODIFIED="1170401848310">
<font NAME="Dialog" SIZE="12" ITALIC="true"/>
</node>
<node TEXT="Negrita y cursiva" ID="Freeplane_Link_1716797514" CREATED="1124560950701" MODIFIED="1170401855592">
<font NAME="Dialog" SIZE="12" BOLD="true" ITALIC="true"/>
</node>
</node>
<node TEXT="Los tama&#xf1;os de fuente puedes ser diferentes" FOLDED="true" ID="Freeplane_Link_1651709962" CREATED="1124560950701" MODIFIED="1170401864248">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Peque&#xf1;o" ID="Freeplane_Link_94543529" CREATED="1124560950701" MODIFIED="1170401870482">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node TEXT="Normal" ID="Freeplane_Link_1637486722" CREATED="1124560950701" MODIFIED="1170401875560">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node TEXT="Grande" ID="Freeplane_Link_660570324" CREATED="1124560950701" MODIFIED="1170401882482">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node TEXT="Gigante" FOLDED="true" ID="Freeplane_Link_232732639" CREATED="1124560950701" MODIFIED="1170401889154">
<font NAME="SansSerif" SIZE="20"/>
<node TEXT="OOh" ID="ID_61348334" CREATED="1124560950701" MODIFIED="1124560950701">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node TEXT="Se pueden utilizar diferente fuentes de letra" FOLDED="true" ID="Freeplane_Link_277624866" CREATED="1124560950701" MODIFIED="1170401897076">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#xc9;sta" ID="Freeplane_Link_1872197155" CREATED="1124560950701" MODIFIED="1170401905951">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node TEXT="&#xc9;sta otra" ID="_Freeplane_Link_1568731425" CREATED="1124560950701" MODIFIED="1170401911608">
<font NAME="Verdana" SIZE="12"/>
</node>
<node TEXT="&#xd3; &#xe9;sta otra" ID="Freeplane_Link_704399864" CREATED="1124560950701" MODIFIED="1170401921873">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node TEXT="Se puede utilizar diferentes tipos de nodos" FOLDED="true" ID="_Freeplane_Link_1193071041" CREATED="1124560950701" MODIFIED="1170401933139">
<node TEXT="Con bifurcaciones" FOLDED="true" ID="_Freeplane_Link_1979277285" CREATED="1124560950701" MODIFIED="1170402078187">
<node TEXT="Con bifurcaciones" ID="_Freeplane_Link_89124429" CREATED="1124560950701" MODIFIED="1170402083218"/>
<node TEXT="Con bifurcaciones" ID="_Freeplane_Link_173850525" CREATED="1124560950701" MODIFIED="1170402086124"/>
</node>
<node TEXT="Con burbujas" FOLDED="true" ID="_Freeplane_Link_1001811541" CREATED="1124560950701" MODIFIED="1170402091952" STYLE="bubble">
<node TEXT="Con burbujas" ID="_Freeplane_Link_1677737286" CREATED="1124560950701" MODIFIED="1170402095281" STYLE="bubble"/>
<node TEXT="Con burbujas" ID="_Freeplane_Link_978246353" CREATED="1124560950701" MODIFIED="1170402098093" STYLE="bubble"/>
</node>
</node>
</node>
<node TEXT="Los nodos se pueden desplegar" FOLDED="true" ID="Freeplane_Link_1271086229" CREATED="1124560950701" MODIFIED="1170402128468" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Doblez" FOLDED="true" ID="_Freeplane_Link_307016912" CREATED="1124560950701" MODIFIED="1170402134671">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Oculta" ID="Freeplane_Link_339068638" CREATED="1124560950701" MODIFIED="1170402138140">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#xc1;rbol" FOLDED="true" ID="_Freeplane_Link_1488567837" CREATED="1124560950701" MODIFIED="1170402144875">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Roble" ID="Freeplane_Link_1450639329" CREATED="1124560950701" MODIFIED="1170402149750">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Haya" ID="Freeplane_Link_1463816938" CREATED="1124560950701" MODIFIED="1170402159531">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Olmo" ID="Freeplane_Link_1006242670" CREATED="1124560950701" MODIFIED="1170402153547">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Los pueden contener enlaces a&#x2026;" FOLDED="true" ID="Freeplane_Link_271846593" CREATED="1124560950701" MODIFIED="1170402170062" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="P&#xe1;ginas web" FOLDED="true" ID="Freeplane_Link_1178924051" CREATED="1124560950701" MODIFIED="1170402176937" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="http://www.google.com/" ID="ID_506767272" CREATED="1124560950701" MODIFIED="1124560950701" LINK="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="www.google.com" FOLDED="true" ID="Freeplane_Link_1626963395" CREATED="1124560950701" MODIFIED="1124560950701" LINK="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Freeplane thinks this is executable :)" ID="Freeplane_Link_1646455138" CREATED="1124560950701" MODIFIED="1170402230875" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node TEXT="Carpetas locales" FOLDED="true" ID="Freeplane_Link_1571818298" CREATED="1124560950701" MODIFIED="1170402185078" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:/Program files/" ID="Freeplane_Link_134747683" CREATED="1124560950701" MODIFIED="1170402246313" LINK="file:/C:/Program%20Files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="/home/" ID="ID_243521134" CREATED="1124560950701" MODIFIED="1124560950701" LINK="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Ejecutables" FOLDED="true" ID="Freeplane_Link_179286322" CREATED="1124560950701" MODIFIED="1170402191875" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:\WINNT\regedit.exe" FOLDED="true" ID="Freeplane_Link_801065485" CREATED="1124560950701" MODIFIED="1124560950701" LINK="file:/C:/WINNT/regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="You see that the node is executable by icon." ID="ID_1367578508" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#006600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Cualquier otro documento en su ordenador o en la red de su empresa." ID="Freeplane_Link_597537942" CREATED="1124560950717" MODIFIED="1170402198969">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Nodos multil&#xed;nea" FOLDED="true" ID="_Freeplane_Link_839677176" CREATED="1124560950717" MODIFIED="1170402256219" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Los nodos multil&#xed;nea se puede ver como un p&#xe1;rrafo o varios p&#xe1;rrafos. Si va a construir una base de conocimiento usando Freeplane, es la mejor manera de hacerlo usando este tipo de nodos. En vez de tener un fichero de texto plano para almacenar sus notas, puede tener un nodo ra&#xed;z con m&#xfa;ltiples nodos como hijos." ID="_Freeplane_Link_1423568963" CREATED="1124560950717" MODIFIED="1170402268204"/>
<node TEXT="&#x201c;La Ciencia son hechos; al igual que las casa se hacen de piedra, la Ciencia est&#xe1;  hecha de hechos; pero un mont&#xf3;n de piedras no es una casa y una colecci&#xf3;n de hechos no tiene por que ser necesariamente ciencia&#x201d; -- Henri Poincar&#xe9;." ID="_Freeplane_Link_1686184172" CREATED="1124560950717" MODIFIED="1170402277094"/>
</node>
<node TEXT="Nodos multil&#xed;nea cortos con nuevas l&#xed;neas (newlines)." FOLDED="true" ID="Freeplane_Link_1045645831" CREATED="1124560950717" MODIFIED="1170402296782" COLOR="#669900">
<node TEXT="L&#xed;nea,&#xa;y una segunda&#xa;&#xa;Y todav&#xed;a se puede hacer otra,&#xa;as&#xed; que... Qu&#xe9; le parece &#xe9;sto?" ID="_Freeplane_Link_1957797574" CREATED="1124560950717" MODIFIED="1170402322173"/>
</node>
<node TEXT="Puede emular ramas etiquetadas" FOLDED="true" ID="Freeplane_Link_871345962" CREATED="1124560950717" MODIFIED="1170402339813" COLOR="#669900">
<node TEXT="&#xc1;rbol" FOLDED="true" ID="Freeplane_Link_1576627386" CREATED="1124560950717" MODIFIED="1170402348642">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="es un" FOLDED="true" ID="Freeplane_Link_707227593" CREATED="1124560950717" MODIFIED="1170402363954" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Roble" ID="Freeplane_Link_1405291988" CREATED="1124560950717" MODIFIED="1170402377767">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="es un" FOLDED="true" ID="Freeplane_Link_867032809" CREATED="1124560950717" MODIFIED="1170402368939" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Haya" ID="Freeplane_Link_779687380" CREATED="1124560950717" MODIFIED="1170402382657">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="es un" FOLDED="true" ID="Freeplane_Link_802687707" CREATED="1124560950717" MODIFIED="1170402372720" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Olmo" ID="Freeplane_Link_544688485" CREATED="1124560950717" MODIFIED="1170402386376">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="&#xc1;rbol" FOLDED="true" ID="Freeplane_Link_1421027901" CREATED="1124560950717" MODIFIED="1170402355314">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;&gt;" FOLDED="true" ID="Freeplane_Link_921860045" CREATED="1124560950717" MODIFIED="1124560950717" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Hoja" ID="Freeplane_Link_1635761458" CREATED="1124560950717" MODIFIED="1170402395236">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&lt;&gt;" FOLDED="true" ID="Freeplane_Link_1017438621" CREATED="1124560950717" MODIFIED="1124560950717" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Tronco" ID="Freeplane_Link_1545141692" CREATED="1124560950717" MODIFIED="1170402400142">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="Se pueden poner iconos en los nodos" ID="Freeplane_Link_686526928" CREATED="1124560950717" MODIFIED="1170402409689" COLOR="#669900">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node TEXT="Puede tener nubes" FOLDED="true" ID="_Freeplane_Link_318937820" CREATED="1124560950717" MODIFIED="1170402416736" COLOR="#407000">
<cloud COLOR="#f0f0f0" SHAPE="ARC"/>
<node TEXT="Con colores personalizados" ID="Freeplane_Link_1908793564" CREATED="1124560950717" MODIFIED="1170402436205">
<cloud COLOR="#3333ff" SHAPE="ARC"/>
</node>
</node>
<node TEXT="Puede tener enlaces enlaces gr&#xe1;ficos" FOLDED="true" ID="_Freeplane_Link_1750585847" CREATED="1124560950717" MODIFIED="1170402448392" COLOR="#407000">
<node TEXT="Conectando nodos" ID="_Freeplane_Link_1212380407" CREATED="1124560950717" MODIFIED="1170402453642">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1249400461" STARTINCLINATION="41;0;" ENDINCLINATION="41;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Con otros" ID="_Freeplane_Link_1249400461" CREATED="1124560950717" MODIFIED="1170402460470">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#6600ff" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_880551392" STARTINCLINATION="47;0;" ENDINCLINATION="47;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Con diferentes colores" ID="_Freeplane_Link_880551392" CREATED="1124560950717" MODIFIED="1170402465439">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1789233193" STARTINCLINATION="82;44;" ENDINCLINATION="82;44;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Y diferentes encaminamientos" ID="_Freeplane_Link_1789233193" CREATED="1124560950717" MODIFIED="1170402473017"/>
</node>
<node TEXT="El nodo se puede mover y colocar libremente" FOLDED="true" ID="_Freeplane_Link_127668276" CREATED="1124560950717" MODIFIED="1170402480955" COLOR="#407000">
<node TEXT="Uno" ID="_Freeplane_Link_894936766" CREATED="1124560950717" MODIFIED="1170402486221"/>
<node TEXT="Otro" ID="_Freeplane_Link_1942481455" CREATED="1124560950717" MODIFIED="1170402490908"/>
</node>
</node>
<node TEXT="Crear y borrar nodos" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1709752669" CREATED="1124560950717" MODIFIED="1170402508049" COLOR="#407000">
<node TEXT="Para crear un nodo, pulse INSERT" ID="Freeplane_Link_151246132" CREATED="1170402517861" MODIFIED="1170402517861"/>
<node TEXT="Para crear un nodo hijo mientra edita otro nodo, pulse INSERT mientras edita" ID="ID_1850215735" CREATED="1170402517861" MODIFIED="1170402517861"/>
<node TEXT="Para crear un nodo hermano anterior, pulse ENTER" ID="ID_1728997864" CREATED="1170402517877" MODIFIED="1170402517877"/>
<node TEXT="Para crear un nodo hermano despu&#xe9;s, pulse SHIFT (MAY&#xda;SCULAS)+ENTER" ID="ID_1650945332" CREATED="1170402517877" MODIFIED="1170402517877"/>
<node TEXT="Para borrar un nodo, pulse DELETE &#xf3; SUPR" ID="ID_1309919099" CREATED="1170402517877" MODIFIED="1170402517877"/>
<node TEXT="Para borrar un nodo y poder pegarlo despu&#xe9;s, pulse CTRL+X." ID="ID_314072670" CREATED="1170402517877" MODIFIED="1170402517877"/>
<node TEXT="Como alternativa, puede usar el men&#xfa; contextual, haciendo click izquierdo con el rat&#xf3;n en un nodo." ID="ID_312072195" CREATED="1170402517877" MODIFIED="1170402517877"/>
</node>
<node TEXT="Editar un nodo de texto" FOLDED="true" POSITION="right" ID="Freeplane_Link_1700974092" CREATED="1124560950717" MODIFIED="1170402540752" COLOR="#407000">
<node TEXT="Para editar un nodo, pulse F2, HOME (INICIO) &#xf3; END (FIN), &#xf3; en el men&#xfa; contextual usando Edit. Para terminar la edici&#xf3;n de un nodo, pulse ENTER." ID="Freeplane_Link_611372497" CREATED="1170402567565" MODIFIED="1170402567565"/>
<node TEXT="Para reemplazar un nodo de texto con otro nuevo, comience a escribir directamente." ID="ID_959968929" CREATED="1170402567565" MODIFIED="1170402567565"/>
<node TEXT="Para forzar el cambio de edici&#xf3;n de un nodo largo desde uno corto, pulse ALT+ENTER." ID="ID_509912383" CREATED="1170402567565" MODIFIED="1170402567565"/>
<node TEXT="Para dividir un nodo largo, use el bot&#xf3;n SEPARAR (Split) en la parte superior del editor de nodos, o pulse ALT+S en el editor de nodos largos." ID="ID_182192331" CREATED="1170402567565" MODIFIED="1170402567565"/>
<node TEXT="Para introducir una nueva l&#xed;nea en el editor de nodos largos, pulse CTRL+ENTER. No puede insertar una nueva l&#xed;nea en el editor corto o b&#xe1;sico de nodos." ID="ID_1260605262" CREATED="1170402567565" MODIFIED="1170402567565"/>
<node TEXT="Para copiar una selecci&#xf3;n al portapapeles, haga click con el bot&#xf3;n derecho del rat&#xf3;n y seleccione COPIAR." ID="ID_1580644595" CREATED="1170402567565" MODIFIED="1170402567565"/>
<node TEXT="Por defecto, al pulsar ENTER se termina la edici&#xf3;n de un nodo largo, y con CTRL+ENTER se inserta una nueva l&#xed;nea. Deseleccionando la opci&#xf3;n &#x201c;Confirmar ENTER&#x201d; puede invertir la funci&#xf3;n de la citada combinaci&#xf3;n de teclas, p.e. ENTER inserta una nueva l&#xed;nea y CTRL+ENTER finaliza la edici&#xf3;n. Puede establecer por defecto este valor en el men&#xfa; preferencias, y se almacenar&#xe1; cuando finalice la sesi&#xf3;n de Freeplane." ID="ID_145638445" CREATED="1170402567565" MODIFIED="1170402567565"/>
<node TEXT="Freeplane soporta Unicode. Adem&#xe1;s, puede usar el script que usted elija." ID="ID_1344420212" CREATED="1170402567565" MODIFIED="1170402567565"/>
</node>
<node TEXT="Dar formato a un nodo" FOLDED="true" POSITION="right" ID="Freeplane_Link_1660149394" CREATED="1124560950717" MODIFIED="1170402594612" COLOR="#407000">
<node TEXT="Para poner en negrita un nodo, pulse CTRL+B." ID="Freeplane_Link_183644252" CREATED="1170402604643" MODIFIED="1170402604643"/>
<node TEXT="Para poner en cursiva un nodo, pulse CTRL+I." ID="ID_1269833146" CREATED="1170402604643" MODIFIED="1170402604643"/>
<node TEXT="Para cambiar el color del texto del nodo, pulse ALT+C." ID="ID_1007318855" CREATED="1170402604643" MODIFIED="1170402604643"/>
<node TEXT="Para cambiar el color del fondo de un nodo, en el men&#xfa; contextual utilice Formato --&gt; Color de fondo del nodo." ID="ID_1997800468" CREATED="1170402604643" MODIFIED="1170402604643"/>
<node TEXT="Para aumentar el tama&#xf1;o del texto del nodo, pulse CTRL++ (Tecla +, NO del teclado num&#xe9;rico, sino del de texto)." ID="ID_1835911990" CREATED="1170402604643" MODIFIED="1170402604643"/>
<node TEXT="Para disminuir el tama&#xf1;o del texto del nodo, pulse CTRL+- (Tecla -, NO del teclado num&#xe9;rico, sino del de texto)." ID="ID_377073048" CREATED="1170402604659" MODIFIED="1170402604659"/>
<node TEXT="Para cambiar el tipo de fuente de texto, use el campo a tal fin en la barra principal." ID="ID_422561863" CREATED="1170402604659" MODIFIED="1170402604659"/>
<node TEXT="Para copiar formatos a un nodo, pulse ALT+V." ID="ID_1796169607" CREATED="1170402604659" MODIFIED="1170402604659"/>
</node>
<node TEXT="Usar estilos f&#xed;sicos" FOLDED="true" POSITION="right" ID="Freeplane_Link_526328879" CREATED="1124560950717" MODIFIED="1170402629050" COLOR="#407000">
<node TEXT="Para aplicar un estudio f&#xed;sico, en el men&#xfa; contextual use &#x201c;Estilo f&#xed;sico&#x201d; y seleccione el estilo deseado. Para aplicar estilos m&#xe1;s r&#xe1;pidamente, utilice las teclas r&#xe1;pidas que se muestran en el citado men&#xfa; contextual." ID="Freeplane_Link_1076084298" CREATED="1170402640284" MODIFIED="1170402640284"/>
<node TEXT="Para a&#xf1;adir su propio estilo f&#xed;sico, en el supuesto de que usted sea un usuario con perfil t&#xe9;cnico, puede hacerlo editando el fichero &#x201c;patterns.xml&#x201d; ubicado en la carpeta &#x201c;freeplane&#x201d; de su equipo." ID="ID_225306628" CREATED="1170402640284" MODIFIED="1170402640284"/>
<node TEXT="Una observaci&#xf3;n sobre el fichero de estilos. Los estilos f&#xed;sicos se aplican al nodo, si existe la etiqueta de de nodo (&lt;node&gt;). Se aplicar&#xe1; al borde, si tiene la etiqueta borde (&lt;edge&gt;). La etiqueta nodo (&lt;node&gt;) puede tener una etiqueta fuente (&lt;font&gt;) como un hijo. Estudie atentamente el fichero &#x201c;patterns.xml&#x201d; facilitado por Freeplane." ID="ID_280540155" CREATED="1170402640284" MODIFIED="1170402640284"/>
</node>
<node TEXT="Resaltar los nodos mediante nubes" FOLDED="true" POSITION="right" ID="Freeplane_Link_1697687428" CREATED="1124560950717" MODIFIED="1170402655706" COLOR="#407000">
<node TEXT="Clouds are well suited for highlighting a region. Highlighted are the node and all its descendants." ID="ID_787687042" CREATED="1124560950717" MODIFIED="1124560950717"/>
<node TEXT="Las nubes se pueden utilizar para resaltar una regi&#xf3;n. Lo que se resalta es el nodo y sus descendientes." ID="ID_560539148" CREATED="1170402669175" MODIFIED="1170402669175"/>
<node TEXT="Para a&#xf1;adir una nube, pulse CTRL+SHIFT (MAY&#xda;SCULAS)+B &#xf3; en el men&#xfa; contextual del nodo, utilice Insertar--&gt;Nube." ID="Freeplane_Link_307492688" CREATED="1170402669191" MODIFIED="1170402669191"/>
<node TEXT="Para cambiar el color de la nube, en men&#xfa; contextual de nodo seleccione Formato--&gt;Color de Nube." ID="Freeplane_Link_1144511960" CREATED="1170402669191" MODIFIED="1170402669191"/>
<node TEXT="Las nubes pueden tener varios colores de fondo como verde..." FOLDED="true" ID="Freeplane_Link_1884870247" CREATED="1124560950717" MODIFIED="1170402707785">
<cloud COLOR="#e1f2e1" SHAPE="ARC"/>
<node TEXT="... &#xf3; marr&#xf3;n" ID="Freeplane_Link_335862648" CREATED="1124560950717" MODIFIED="1170402714863">
<cloud COLOR="#ede5d5" SHAPE="ARC"/>
</node>
</node>
</node>
<node TEXT="A&#xf1;adir enlaces &#xf3; hiperv&#xed;nculos" FOLDED="true" POSITION="right" ID="Freeplane_Link_203858515" CREATED="1124560950717" MODIFIED="1170402734160" COLOR="#407000">
<node TEXT="Para a&#xf1;adir un enlace &#xf3; hiperv&#xed;nculo a un nodo, presione CTRL+K &#xf3; en el men&#xfa; contextual utilice Insertar--&gt;Enlace." ID="Freeplane_Link_1312466416" CREATED="1170402743613" MODIFIED="1170402743613"/>
<node TEXT="Para borrar un enlace, Deje el enlace en blanco despu&#xe9;s de pulsar CTRL+K." ID="ID_112243579" CREATED="1170402743613" MODIFIED="1170402743613"/>
<node TEXT="Para enlazar con una cuenta de correo electr&#xf3;nico, establezca el enlace como en este ejemplo: &#x201c;mailto:dircorreo@correo.com&#x201d;" ID="ID_155366812" CREATED="1170402743613" MODIFIED="1170402743613" LINK="mailto:&#x201c;mailto:dircorreo@correo.com&#x201d;"/>
<node TEXT="Para enlazar con una direcci&#xf3;n de correo electr&#xf3;nico e incluir a su vez un asunto, escriba lo siguiente en el enlace: &#x201c;mailto:dircorreo@correo.com?subject=Asunto&#x201d;" ID="ID_779331110" CREATED="1170402743613" MODIFIED="1170402743613" LINK="mailto:&#x201c;mailto:dircorreo@correo.com?subject=Asunto&#x201d;"/>
<node TEXT="Se puede enlazar a p&#xe1;ginas web, ficheros locales &#xf3; direcciones de correo electr&#xf3;nico." ID="ID_602845316" CREATED="1170402743613" MODIFIED="1170402743613"/>
<node TEXT="Links" FOLDED="true" ID="Freeplane_Link_1974937042" CREATED="1170402743707" MODIFIED="1170402743707">
<font NAME="SansSerif" SIZE="12" BOLD="true"/>
<node TEXT="mailto:dircorreo@correo.com" ID="ID_1583474854" CREATED="1170402743707" MODIFIED="1170402743707" LINK="mailto:dircorreo@correo.com"/>
<node TEXT="mailto:dircorreo@correo.com?subject=Asunto" ID="ID_1195481799" CREATED="1170402743707" MODIFIED="1170402743707" LINK="mailto:dircorreo@correo.com?subject=Asunto"/>
</node>
</node>
<node TEXT="A&#xf1;adir iconos" FOLDED="true" POSITION="right" ID="Freeplane_Link_1044397139" CREATED="1124560950717" MODIFIED="1170402783082" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Un nodo puede tener varios iconos." ID="Freeplane_Link_1687645098" CREATED="1170402797691" MODIFIED="1170402797691"/>
<node TEXT="Para a&#xf1;adir iconos a un nodo, seleccione un nodo y haga click en los iconos de la barra de men&#xfa; vertical de la izquierda de su pantalla. Mientras mueve el rat&#xf3;n hacia la citada barra de iconos, mantenga pulsado el bot&#xf3;n ALT &#xf3; CTRL de modo que no pierda el foco &#xf3; selecci&#xf3;n del nodo." ID="ID_1321472721" CREATED="1170402797691" MODIFIED="1170402797691"/>
<node TEXT="Para borrar un icono, pulse la cruz roja en la parte de arriba de la barra de iconos." ID="ID_165187931" CREATED="1170402797691" MODIFIED="1170402797691"/>
<node TEXT="Para borrar todos los iconos, pulse el icono de la papelera en la parte de arriba de la barra de iconos." ID="ID_1084750728" CREATED="1170402797691" MODIFIED="1170402797691"/>
<node TEXT="Para a&#xf1;adir un icono a un nodo sin utilizar la barra de men&#xfa;, presione ALT+I." ID="ID_1195433040" CREATED="1170402797691" MODIFIED="1170402797691"/>
<node TEXT="No existe opci&#xf3;n para utilizar sus propios iconos, por lo que deber&#xe1; elegir los que le ofrece Freeplane &#xfa;nicamente." ID="ID_1099218237" CREATED="1170402797691" MODIFIED="1170402797691"/>
<node TEXT="Para mostrar u ocultar la barra de iconos, utilice el men&#xfa; de la barra superior. Ver--&gt;Des(activar) Barra de herramientas de la izquierda. La barra de herramientas de la izquierda es la forma de llamar a la barra de iconos en la aplicaci&#xf3;n." ID="Freeplane_Link_1437377566" CREATED="1170402797691" MODIFIED="1170402797691"/>
<node TEXT="Los iconos adjuntados a este nodo son todos los que existen, no hay m&#xe1;s." ID="Freeplane_Link_1609274" CREATED="1124560950717" MODIFIED="1170402870301">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node TEXT="A&#xf1;adir enlaces gr&#xe1;ficos (Flechas de enlace)" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1996597932" CREATED="1124560950717" MODIFIED="1170402930317" COLOR="#407000">
<node TEXT="Para crear un enlace gr&#xe1;fico entre dos nodos, arrastre un nodo y su&#xe9;ltelo en otro nodo teniendo pulsadas las teclas SHIFT (MAY&#xda;SCULAS) y CTRL; suelte el bot&#xf3;n del rat&#xf3;n antes de soltar las teclas antes mencionadas." ID="Freeplane_Link_1942968106" CREATED="1170402940036" MODIFIED="1170403283663">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="Freeplane_Link_967984859" STARTINCLINATION="227;0;" ENDINCLINATION="99;-7;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Otro modo ser&#xed;a arrastrando y soltando usando el bot&#xf3;n derecho del rat&#xf3;n." ID="Freeplane_Link_1842889348" CREATED="1170402940036" MODIFIED="1170402940036"/>
<node TEXT="Para cambiar el color del enlace, utilice el men&#xfa; contextual, haciendo click con el bot&#xf3;n derecho del rat&#xf3;n en el enlace gr&#xe1;fico." ID="ID_952648623" CREATED="1170402940036" MODIFIED="1170402940036"/>
<node TEXT="Para cambiar las fechas del enlace, use el men&#xfa; contextual del enlace." ID="ID_183404799" CREATED="1170402940036" MODIFIED="1170402940036"/>
<node TEXT="Para borrar un enlace, use el men&#xfa; contextual del enlace." ID="ID_681591273" CREATED="1170402940036" MODIFIED="1170402940036"/>
<node TEXT="Para navegar al final de uno de los nodos del enlace, utilice el men&#xfa; contextual." ID="Freeplane_Link_967984859" CREATED="1170402940036" MODIFIED="1170403283663"/>
<node TEXT="Para cambiar la ruta de una flecha de enlace, arr&#xe1;strela y mu&#xe9;vela." ID="Freeplane_Link_1478196416" CREATED="1170402940036" MODIFIED="1170403278835">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="Freeplane_Link_967984859" STARTINCLINATION="73;0;" ENDINCLINATION="73;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="A continuaci&#xf3;n, un ejemplo de enlace de flecha:" ID="ID_709190104" CREATED="1170402940036" MODIFIED="1170402940036"/>
<node TEXT="Ejemplo" FOLDED="true" ID="Freeplane_Link_1315155160" CREATED="1170402940036" MODIFIED="1170403388133" COLOR="#cc9900">
<node TEXT="Enlace a otra parte" ID="Freeplane_Link_72153142" CREATED="1170402940036" MODIFIED="1170403462102" COLOR="#cc9900">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="Freeplane_Link_872294215" STARTINCLINATION="135;-8;" ENDINCLINATION="14;-29;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Nodo con un subnodo replegado" FOLDED="true" ID="Freeplane_Link_40913042" CREATED="1170402940036" MODIFIED="1170403419680" COLOR="#cc9900">
<node TEXT="Subnodo" ID="Freeplane_Link_872294215" CREATED="1170402940036" MODIFIED="1170403462102"/>
</node>
<node TEXT="Otro enlace" ID="Freeplane_Link_1982955440" CREATED="1170402940036" MODIFIED="1170403474336" COLOR="#cc9900">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#9999ff" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="Freeplane_Link_72153142" STARTINCLINATION="174;0;" ENDINCLINATION="169;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
</node>
</node>
<node TEXT="Hacer b&#xfa;squedas" FOLDED="true" POSITION="right" ID="Freeplane_Link_423038022" CREATED="1124560950717" MODIFIED="1170403490211" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Para encontrar un texto en un nodo y todos los nodos descendientes, presione CTRL+F &#xf3; en el men&#xfa; contextual, opci&#xf3;n Nodo--&gt;Buscar...." ID="Freeplane_Link_1193426532" CREATED="1170403492446" MODIFIED="1170403492446"/>
<node TEXT="Para seguir buscando m&#xe1;s resultados con un criterio de b&#xfa;squeda, pulse CTRL+G &#xf3; en el men&#xfa; contextual, utilice Nodo-&gt;Buscar Siguiente." ID="ID_409660243" CREATED="1170403492446" MODIFIED="1170403492446"/>
<node TEXT="Para buscar en todo el mapa, col&#xf3;quese en el nodo central, pulsando ESCAPE antes de realizar la b&#xfa;squeda." ID="ID_111025171" CREATED="1170403492446" MODIFIED="1170403492446"/>
<node TEXT="La b&#xfa;squeda es una b&#xfa;squeda de la primera concurrencia. Esto responde a la idea de que, cuanto m&#xe1;s profundo sea un nodo, m&#xe1;s detalle tendr&#xe1;." ID="ID_1327608238" CREATED="1170403492446" MODIFIED="1170403492446"/>
<node TEXT="Recuerde que no se busca un &#xe1;rbol entero, sino que s&#xf3;lo en el nodo y todos sus descendientes." ID="ID_1123566873" CREATED="1170403492446" MODIFIED="1170403492446"/>
</node>
<node TEXT="Seleccionar m&#xfa;ltiples nodos" FOLDED="true" POSITION="right" ID="Freeplane_Link_653540280" CREATED="1124560950717" MODIFIED="1170403527134" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Para seleccionar m&#xfa;ltiples nodos, mantenga pulsado CTRL &#xf3; SHIFT (MAY&#xda;SCULAS) mientras los elige con el rat&#xf3;n." ID="Freeplane_Link_507160373" CREATED="1170403517883" MODIFIED="1170403517883"/>
<node TEXT="Para a&#xf1;adir m&#xe1;s nodos a una selecci&#xf3;n m&#xfa;ltiple de nodos, mantenga pulsado CTRL mientras hace click en ellos." ID="ID_1994258742" CREATED="1170403517883" MODIFIED="1170403517883"/>
<node TEXT="Para seleccionar un rango de nodos consecutivos o seguidos, mantenga pulsado SHIFT (MAY&#xda;SCULAS) mientras los selecciona con el rat&#xf3;n, &#xf3; mantenga pulsado SHIFT (MAY&#xda;SCULAS) mientras se mueve con las flechas de desplazamiento del teclado." ID="ID_1174557916" CREATED="1170403517883" MODIFIED="1170403517883"/>
<node TEXT="Para seleccionar un sub-&#xe1;rbol completo, mantenga pulsado ALT mientras hace click, &#xf3; mantenga pulsado SHIFT (MAY&#xda;SCULAS) mientras se mueve con las teclas de desplazamiento de un nodo a su nodo padre." ID="ID_635991816" CREATED="1170403517883" MODIFIED="1170403517883"/>
<node TEXT="Para cancelar la selecci&#xf3;n de m&#xfa;ltiples nodos, haga click en el fondo del mapa &#xf3; en un nodo no seleccionado." ID="ID_332861751" CREATED="1170403517883" MODIFIED="1170403517883"/>
<node TEXT="Para seleccionar todos los nodos visibles, seleccione la opci&#xf3;n en el men&#xfa; principal: Editar--&gt;Select All Visible (Sin traducir)." ID="ID_588842119" CREATED="1170403517883" MODIFIED="1170403517883"/>
<node TEXT="Para seleccionar todos los nodos visibles de una rama, seleccione la opci&#xf3;n en el men&#xfa; principal: Editar--&gt;Select Visible Branch (Sin traducir)." ID="ID_1766685622" CREATED="1170403517883" MODIFIED="1170403517883"/>
<node TEXT="Html" FOLDED="true" ID="Freeplane_Link_1196067011" CREATED="1170405270836" MODIFIED="1170405270852" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Html/">
<node TEXT="frame.html" ID="Freeplane_Link_566784677" CREATED="1170405270852" MODIFIED="1170405270852" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Html/frame.html"/>
<node TEXT="slideshow.html" ID="Freeplane_Link_1122494705" CREATED="1170405270868" MODIFIED="1170405270868" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Html/slideshow.html"/>
<node TEXT="thumbnails.html" ID="Freeplane_Link_364368875" CREATED="1170405270868" MODIFIED="1170405270868" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Html/thumbnails.html"/>
</node>
<node TEXT="Languages" FOLDED="true" ID="Freeplane_Link_1203928403" CREATED="1170405270883" MODIFIED="1170405270899" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Languages/">
<node TEXT="Deutsch.dll" ID="Freeplane_Link_855733485" CREATED="1170405270899" MODIFIED="1170405270899" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Languages/Deutsch.dll"/>
</node>
<node TEXT="Plugins" FOLDED="true" ID="Freeplane_Link_743205228" CREATED="1170405270899" MODIFIED="1170405270914" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Plugins/">
<node TEXT="Effects.dll" ID="Freeplane_Link_639338292" CREATED="1170405270914" MODIFIED="1170405270914" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Plugins/Effects.dll"/>
<node TEXT="Icons.dll" ID="Freeplane_Link_965606582" CREATED="1170405270914" MODIFIED="1170405270930" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Plugins/Icons.dll"/>
<node TEXT="Mpg.dll" ID="Freeplane_Link_1618897390" CREATED="1170405270930" MODIFIED="1170405270930" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Plugins/Mpg.dll"/>
<node TEXT="Plugins.txt" ID="Freeplane_Link_946430678" CREATED="1170405270930" MODIFIED="1170405270946" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Plugins/Plugins.txt"/>
<node TEXT="Slideshow.exe" ID="Freeplane_Link_756921843" CREATED="1170405270946" MODIFIED="1170405270946" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Plugins/Slideshow.exe"/>
<node TEXT="Video.dll" ID="Freeplane_Link_913413127" CREATED="1170405270946" MODIFIED="1170405270946" LINK="file:/C:/Archivos%20de%20programa/IrfanView/Plugins/Video.dll"/>
</node>
<node TEXT="iv_uninstall.exe" ID="Freeplane_Link_344292187" CREATED="1170405270961" MODIFIED="1170405270961" LINK="file:/C:/Archivos%20de%20programa/IrfanView/iv_uninstall.exe"/>
<node TEXT="i_about.txt" ID="Freeplane_Link_331640781" CREATED="1170405270961" MODIFIED="1170405270961" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_about.txt"/>
<node TEXT="i_changes.txt" ID="Freeplane_Link_823931338" CREATED="1170405270961" MODIFIED="1170405270977" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_changes.txt"/>
<node TEXT="i_languages.txt" ID="Freeplane_Link_1434544883" CREATED="1170405270977" MODIFIED="1170405270977" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_languages.txt"/>
<node TEXT="i_options.txt" ID="Freeplane_Link_1464671418" CREATED="1170405270977" MODIFIED="1170405270977" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_options.txt"/>
<node TEXT="i_plugins.txt" ID="Freeplane_Link_1621670439" CREATED="1170405270992" MODIFIED="1170405270992" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_plugins.txt"/>
<node TEXT="i_view32.chm" ID="Freeplane_Link_1732519486" CREATED="1170405270992" MODIFIED="1170405270992" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_view32.chm"/>
<node TEXT="i_view32.exe" ID="Freeplane_Link_1243859600" CREATED="1170405270992" MODIFIED="1170405271008" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_view32.exe"/>
<node TEXT="i_view32.exe.manifest" ID="Freeplane_Link_1386491854" CREATED="1170405271008" MODIFIED="1170405271008" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_view32.exe.manifest"/>
<node TEXT="i_view32.ini" ID="Freeplane_Link_1958400630" CREATED="1170405271008" MODIFIED="1170405271024" LINK="file:/C:/Archivos%20de%20programa/IrfanView/i_view32.ini"/>
</node>
<node TEXT="Arrastrar y soltar" FOLDED="true" POSITION="right" ID="Freeplane_Link_1024903226" CREATED="1124560950717" MODIFIED="1170403565009" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Puede mover nodos usando arrastrar y soltar." ID="Freeplane_Link_803053837" CREATED="1170403567946" MODIFIED="1170403567946"/>
<node TEXT="Para soltar un nodo como hijo, coloque el cursor en el extremo de un nodo al soltarlo." ID="ID_1792422864" CREATED="1170403567946" MODIFIED="1170403567946"/>
<node TEXT="Para soltar un nodo como hermano, coloque el cursor en la parte superior del nodo destino cuando al soltarlo." ID="ID_1163222765" CREATED="1170403567946" MODIFIED="1170403567946"/>
<node TEXT="Para copiar nodos a la vez que se mueven, presione CTRL mientras lo arrastra, &#xf3; arrastrelo con el bot&#xf3;n central del rat&#xf3;n." ID="ID_158691652" CREATED="1170403567946" MODIFIED="1170403567946"/>
<node TEXT="Para editar un mapa existente, arrastre su fichero y su&#xe9;ltelo en el fondo de pantalla de Freeplane; Esto funciona al menos en ordenadores con Microsoft Windows." ID="ID_165552277" CREATED="1170403567946" MODIFIED="1170403567946"/>
<node TEXT="Para crear un enlace gr&#xe1;fico o de flechas, arrastre y suelte mientras tiene pulsado el bot&#xf3;n derecho del rat&#xf3;n." ID="ID_1376653248" CREATED="1170403567946" MODIFIED="1170403567946"/>
<node TEXT="Si ha seleccionado m&#xfa;ltiples nodos, todos se moveran o copiaran.." ID="ID_1612046496" CREATED="1170403567946" MODIFIED="1170403567946"/>
<node TEXT="Puede arrastrar informaci&#xf3;n de aplicaciones externas, como ficheros en un S.O. Microsoft Windows, &#xf3; piezas de texto seleccionado en Microsoft Internet Explorer." ID="ID_42570001" CREATED="1170403567946" MODIFIED="1170403567946"/>
</node>
<node TEXT="Copiar y pegar (Edici&#xf3;n)" FOLDED="true" POSITION="right" ID="Freeplane_Link_958781924" CREATED="1124560950717" MODIFIED="1170403884683" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Puede copiar y pegar (m&#xfa;ltiples) nodos entre mapas mentales. Adem&#xe1;s, puede pegar texto normal &#xf3; HTML desde otras aplicaciones." ID="Freeplane_Link_1070489177" CREATED="1124560950717" MODIFIED="1170662211252">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Si pega texto plano, cada l&#xed;nea se pegar&#xe1; como un nodo, con la profundidad determinada por el n&#xfa;mero de caracteres de cada l&#xed;nea. &#xc9;ste es un ejemplo:" ID="Freeplane_Link_1215134438" CREATED="1124560950717" MODIFIED="1170403616493"/>
<node TEXT="&#xc1;rbol &#xa;     Roble &#xa;     Haya" FOLDED="true" ID="Freeplane_Link_1656023763" CREATED="1124560950717" MODIFIED="1170403649275" COLOR="#996600">
<node TEXT="es pegado como" FOLDED="true" ID="Freeplane_Link_326960749" CREATED="1124560950717" MODIFIED="1170403674025">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#xc1;rbol" FOLDED="true" ID="Freeplane_Link_639753662" CREATED="1124560950717" MODIFIED="1170403690306" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Roble" ID="Freeplane_Link_142445650" CREATED="1124560950717" MODIFIED="1170403694135" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Haya" ID="Freeplane_Link_68949954" CREATED="1124560950717" MODIFIED="1170403697775" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="Si pega HTML, &#xe9;ste se pega como texto plano. Adem&#xe1;s, los enlaces que contenga en HTML ser&#xe1;n copiados como hijos de un nodo adicional llamado &#x201c;Links&#x201d; (Enlaces). Ejemplo:" ID="Freeplane_Link_1804728980" CREATED="1124560950717" MODIFIED="1170403710088"/>
<node TEXT="Ejemplo resultante tras pegar:" FOLDED="true" ID="Freeplane_Link_374077364" CREATED="1124560950717" MODIFIED="1170403718853">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Shopping (120236)" ID="ID_1762800268" CREATED="1124560950717" MODIFIED="1124560950717">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Urban Living (19)" ID="ID_10207675" CREATED="1124560950717" MODIFIED="1124560950717">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Enlaces" FOLDED="true" ID="Freeplane_Link_1381653791" CREATED="1124560950717" MODIFIED="1170403726979">
<font NAME="Dialog" SIZE="12" BOLD="true"/>
<node TEXT="Shopping" ID="ID_595534642" CREATED="1124560950717" MODIFIED="1124560950717" LINK="http://directory.google.com/Top/Shopping/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Urban Living" ID="ID_1073876455" CREATED="1124560950717" MODIFIED="1124560950717" LINK="http://directory.google.com/Top/Home/Urban_Living/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Si pega una lista de ficheros de Explorer en Microsoft Windows, se pegar&#xe1; como un conjunto de enlaces a los ficheros." ID="Freeplane_Link_1772185342" CREATED="1124560950717" MODIFIED="1170403735744"/>
<node TEXT="Si en Freeplane copia una rama y la pega en un editor de texto plano (p.e.: Bloc de notas), la estructura de &#xe1;rbol se muestra como texto tabulado. Los enlaces se copian entre los simbolos &#x201c;&lt;&gt;&#x201d;. Por ejemplo:" ID="Freeplane_Link_619498024" CREATED="1124560950717" MODIFIED="1170403756166"/>
<node TEXT="&#xc1;rbol" FOLDED="true" ID="Freeplane_Link_1419018130" CREATED="1124560950717" MODIFIED="1170403770010" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Roble" ID="Freeplane_Link_1688306576" CREATED="1124560950717" MODIFIED="1170403774791" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Haya" FOLDED="true" ID="Freeplane_Link_838087851" CREATED="1124560950717" MODIFIED="1170403779760" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="se pega como" FOLDED="true" ID="Freeplane_Link_926901432" CREATED="1124560950717" MODIFIED="1170403787354">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#xc1;rbol&#xa;     Roble &#xa;     Haya&#xa;     Google &lt;http://www.google.com/&gt;" ID="Freeplane_Link_160461667" CREATED="1124560950732" MODIFIED="1170403810901" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Google" ID="ID_1017410762" CREATED="1124560950732" MODIFIED="1124560950732" LINK="http://www.google.com/" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Si en Freeplane usted copia una rama y la pega en un editor de texto que comprenda el formato de texto enriquecido, se mantienes los formatos de color y fuente se incluyen tambi&#xe9;n. Los enlaces tambi&#xe9;n se copian entre &#x201c;&lt;&gt;&#x201d;, igual que en los editores de texto plano. Los editores que soportan texto enriquecido son Microsoft Word, Wordpad &#xf3; Microsoft Outlook, y en Linux, existe algunos (No se mencionan concretos)." ID="Freeplane_Link_847954963" CREATED="1124560950732" MODIFIED="1170403842589"/>
<node TEXT="Para copiar un nodo sin sus descendientes, pulse CTRL+Y &#xf3; en el men&#xfa; contextual use &#x201c;Copia Sencilla&#x201d;." ID="Freeplane_Link_314527267" CREATED="1124560950732" MODIFIED="1170403851432"/>
</node>
<node TEXT="Moverse en la aplicaci&#xf3;n" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1540212684" CREATED="1124560950732" MODIFIED="1170403896261" COLOR="#407000">
<node TEXT="Para mover el cursor hacia arriba, abajo, izquierda &#xf3; derecha, utilice las teclas de desplazamiento." ID="Freeplane_Link_1237405295" CREATED="1170403902527" MODIFIED="1170403902527"/>
<node TEXT="Para moverse a la parte superior del sub-&#xe1;rbol actual, pulse AV. P&#xc1;G." ID="ID_1522378861" CREATED="1170403902527" MODIFIED="1170403902527"/>
<node TEXT="Para moverse a la parte inferior del sub-&#xe1;rbol actual, pulse RE. P&#xc1;G." ID="ID_526489756" CREATED="1170403902527" MODIFIED="1170403902527"/>
<node TEXT="Para moverse al nodo central, pulse ESCAPE." ID="ID_1987074426" CREATED="1170403902527" MODIFIED="1170403902527"/>
<node TEXT="Para mover un nodo libremente, arr&#xe1;strelo por la parte anterior a la caja del texto del nodo (aparecer&#xe1; una especie de elipse), y en ese momento podr&#xe1; ponerlo donde quiera." ID="ID_1452720817" CREATED="1170403902527" MODIFIED="1170403902527"/>
</node>
<node TEXT="Desplegar y Replegar (Doblar y desdoblar)" FOLDED="true" POSITION="right" ID="Freeplane_Link_4727471" CREATED="1124560950732" MODIFIED="1170403918527" COLOR="#407000">
<node TEXT="Para replegar &#xf3; doblar un nodo, pulse ESPACIO, &#xf3; en el men&#xfa; contextual de nodo utilice (Des)Activar Doblez." ID="Freeplane_Link_308302871" CREATED="1170403923714" MODIFIED="1170403923714"/>
<node TEXT="Para desplegar &#xf3; desdoblar un nodo, pulse ESPACIO, &#xf3; en el men&#xfa; contextual de nodo utilice (Des)Activar Doblez. Incluso, se puede desdoblar o desplegar con la tecla de desplazamiento en la direcci&#xf3;n de despliegue. (P.e.: Para desplegar un nodo replegado que est&#xe1; a la derecha, con la tecla derecha se despliega." ID="ID_1397749400" CREATED="1170403923714" MODIFIED="1170403923714"/>
<node TEXT="Para replegar &#xf3; desplegar los nodos por niveles, mantenga pulsado ALT mientras utiliza la rueda del rat&#xf3;n, &#xf3; presione ALT+AV. P&#xc1;G &#xf3; ALT+RE. P&#xc1;G. Con mapas grandes, use esta funci&#xf3;n con cuidado, ya que pueden surgir problemas de memoria." ID="ID_1882764810" CREATED="1170403923714" MODIFIED="1170403923714"/>
<node TEXT="Para desplegar todo, pulse el bot&#xf3;n gris &#x201c;+&#x201d; en la barra de principal, &#xf3; en el men&#xfa; principal: Navegar--&gt;Desdoblar Todos." ID="ID_1459813476" CREATED="1170403923714" MODIFIED="1170403923714"/>
<node TEXT="Para replegar &#xf3; doblar todo, pulse el bot&#xf3;n gris &#x201c;-&#x201d; en la barra principal, &#xf3; en el men&#xfa; principal: Navegar--&gt;Doblar Todos." ID="ID_466714158" CREATED="1170403923714" MODIFIED="1170403923714"/>
<node TEXT="Los nodos replegados &#xf3; doblados se se&#xf1;alan con un peque&#xf1;o c&#xed;rculo en la direcci&#xf3;n de la doblez." ID="ID_1093848876" CREATED="1170403923714" MODIFIED="1170403923714"/>
</node>
<node TEXT="Cambiar de mapas" FOLDED="true" POSITION="right" ID="Freeplane_Link_516331171" CREATED="1124560950732" MODIFIED="1170403959449" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Para cambiar a otro mapa mental ya abierto, haga click con el bot&#xf3;n derecho en el fondo del mapa y seleccione un mapa diferente en el men&#xfa; contextual." ID="Freeplane_Link_1490034065" CREATED="1124560950732" MODIFIED="1170662218299">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Mover un mapa" FOLDED="true" POSITION="right" ID="Freeplane_Link_467411537" CREATED="1124560950732" MODIFIED="1170403980402" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Para mover el mapa, arrastre el fondo y mu&#xe9;valo, &#xf3; use la rueda del rat&#xf3;n. Para desplazarlo horizontalmente con la rueda, mantega pulsado SHIFT (MAY&#xda;SCULAS) &#xf3; uno de los botones del rat&#xf3;n." ID="Freeplane_Link_822614761" CREATED="1170403987433" MODIFIED="1170403987433"/>
</node>
<node TEXT="Hacer Zoom (Ampliar y reducir)" FOLDED="true" POSITION="right" ID="Freeplane_Link_913137192" CREATED="1124560950732" MODIFIED="1170403999887" COLOR="#407000">
<node TEXT="Para hacer zoom, utilice la rueda del rat&#xf3;n mientras presiona la tecla CTRL, &#xf3; presione ALT+ARRIBA &#xf3; ABAJO. Adem&#xe1;s, puede usar el campo de zoom en la lista desplegable de la barra principal (Al lado del icono de la impresora)." ID="Freeplane_Link_1547290575" CREATED="1170404005637" MODIFIED="1170404005637"/>
</node>
<node TEXT="Deshacer cambios" FOLDED="true" POSITION="right" ID="Freeplane_Link_1318678369" CREATED="1124560950732" MODIFIED="1170404020480" COLOR="#407000">
<node TEXT="Para deshacer cambios, pulse CTRL+Z, &#xf3; en el men&#xfa; principal, Editar--&gt;Deshacer." ID="Freeplane_Link_613644644" CREATED="1170404027137" MODIFIED="1170404027137"/>
<node TEXT="Para rehacer cambios, pulse CTRL+Y, &#xf3; en el men&#xfa; principal, Editar--&gt;Rehacer." ID="ID_473232607" CREATED="1170404027137" MODIFIED="1170404027137"/>
<node TEXT="Para establecer el n&#xfa;mero de pasos para poder deshacer, utilice la opci&#xf3;n Herramientas--&gt;Preferencias (Preferences) del men&#xfa; principal." ID="ID_1826464309" CREATED="1170404027137" MODIFIED="1170404027137"/>
</node>
<node TEXT="Exportar a HTML" FOLDED="true" POSITION="right" ID="Freeplane_Link_22510332" CREATED="1124560950732" MODIFIED="1170404045621" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Para exportar una rama a HTML, pulse CTRL+H. La p&#xe1;gina HTML exportada puede contener soporte de ramificaciones o despliegues, dependiendo de la configuraci&#xf3;n de las preferencias." ID="Freeplane_Link_842904736" CREATED="1170404051465" MODIFIED="1170404051465"/>
<node TEXT="Para usar otra funci&#xf3;n de exportaci&#xf3;n, utilice en el men&#xfa; principal la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como XHTML (versi&#xf3;n Javascript)." ID="ID_280667853" CREATED="1170404051465" MODIFIED="1170404051465"/>
<node TEXT="Para exportar un mapa como una vista de imagen en HTML, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como XHTML (versi&#xf3;n mapa seleccionable)." ID="ID_1924456097" CREATED="1170404051465" MODIFIED="1170404051465"/>
</node>
<node TEXT="Exportar a Imagen &#xf3; imagen vectorizada" FOLDED="true" POSITION="right" ID="Freeplane_Link_1908686168" CREATED="1124560950732" MODIFIED="1170404068871" COLOR="#407000">
<node TEXT="Para exportar el mapa como imagen PNG, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como PNG." ID="Freeplane_Link_696364467" CREATED="1170404074075" MODIFIED="1170404074075"/>
<node TEXT="Para exportar el mapa como imagen JPEG, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como JPEG." ID="ID_433157633" CREATED="1170404074075" MODIFIED="1170404074075"/>
<node TEXT="Para exportar el mapa como SVG, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como SVG. Esta opci&#xf3;n s&#xf3;lo estar&#xe1; disponible si tiene instalado en su equipo el plugin de SVG." ID="ID_1875409785" CREATED="1170404074075" MODIFIED="1170404074075"/>
</node>
<node TEXT="Exportar a otros formatos XML" FOLDED="true" POSITION="right" ID="Freeplane_Link_329770204" CREATED="1124560950732" MODIFIED="1170404092059" COLOR="#407000">
<node TEXT="Para exportar el mapa a otros XML, de modo que obtenga una hoja de c&#xe1;lculo XSLT, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como XSLT." ID="Freeplane_Link_1686469512" CREATED="1170404101012" MODIFIED="1170404101012"/>
<node TEXT="Para exportar el mapa a un documento de OpenOffice Writer 1.4,  utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;As OpenOffice Writer Document (Como un documento de OpenOffice Writer)." ID="ID_272334955" CREATED="1170404101012" MODIFIED="1170404101012"/>
</node>
<node TEXT="Importar una estructura de carpetas" FOLDED="true" POSITION="right" ID="Freeplane_Link_1841136119" CREATED="1124560950732" MODIFIED="1170404233263" COLOR="#407000">
<font NAME="Dialog" SIZE="12"/>
<node TEXT="Para importar una estructura de carpetas, en el men&#xfa; principal utilice Fichero--&gt;Importar--&gt;Estructura de carpetas. Se le preguntar&#xe1; sobre qu&#xe9; carpeta cuya estructura desea importar. Por estructura se entiende el &#xe1;rbol de todas los subcarpetas, con los enlaces a los ficheros de esas subcarpetas. Este ser&#xed;a un ejemplo." ID="Freeplane_Link_1764451882" CREATED="1124560950732" MODIFIED="1170404202950"/>
<node TEXT="Ejemplo" FOLDED="true" ID="Freeplane_Link_1904792824" CREATED="1170405208842" MODIFIED="1170405350619" COLOR="#cc9900">
<node TEXT="Carpeta seleccionada    --&gt;   file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS" ID="Freeplane_Link_973626144" CREATED="1170405356830" MODIFIED="1170405536101">
<arrowlink SHAPE="LINE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="Freeplane_Link_973626144" STARTINCLINATION="0;0;" ENDINCLINATION="0;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="DBWIZ" FOLDED="true" ID="Freeplane_Link_482637031" CREATED="1170405329320" MODIFIED="1170405329320" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/">
<node TEXT="ASSETS.GIF" ID="Freeplane_Link_917890101" CREATED="1170405329320" MODIFIED="1170405329335" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/ASSETS.GIF"/>
<node TEXT="CONTACTS.GIF" ID="Freeplane_Link_1920637750" CREATED="1170405329335" MODIFIED="1170405329335" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/CONTACTS.GIF"/>
<node TEXT="EVTMGMT.GIF" ID="Freeplane_Link_52335184" CREATED="1170405329335" MODIFIED="1170405329351" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/EVTMGMT.GIF"/>
<node TEXT="EXPENSES.GIF" ID="Freeplane_Link_1267132541" CREATED="1170405329351" MODIFIED="1170405329351" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/EXPENSES.GIF"/>
<node TEXT="INVENTRY.GIF" ID="Freeplane_Link_1821713435" CREATED="1170405329367" MODIFIED="1170405329367" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/INVENTRY.GIF"/>
<node TEXT="LEDGER.GIF" ID="Freeplane_Link_576748688" CREATED="1170405329367" MODIFIED="1170405329367" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/LEDGER.GIF"/>
<node TEXT="ORDPROC.GIF" ID="Freeplane_Link_1213533940" CREATED="1170405329367" MODIFIED="1170405329382" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/ORDPROC.GIF"/>
<node TEXT="RESOURCE.GIF" ID="Freeplane_Link_806628245" CREATED="1170405329382" MODIFIED="1170405329382" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/RESOURCE.GIF"/>
<node TEXT="SERVICE.GIF" ID="Freeplane_Link_460118543" CREATED="1170405329382" MODIFIED="1170405329398" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/SERVICE.GIF"/>
<node TEXT="TIMEBILL.GIF" ID="Freeplane_Link_12438217" CREATED="1170405329398" MODIFIED="1170405329398" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/DBWIZ/TIMEBILL.GIF"/>
</node>
<node TEXT="STYLES" FOLDED="true" ID="Freeplane_Link_1899130473" CREATED="1170405329398" MODIFIED="1170405329413" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/">
<node TEXT="ACBLENDS.GIF" ID="Freeplane_Link_592922687" CREATED="1170405329413" MODIFIED="1170405329413" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/ACBLENDS.GIF"/>
<node TEXT="ACBLUPRT.GIF" ID="Freeplane_Link_146113010" CREATED="1170405329413" MODIFIED="1170405329429" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/ACBLUPRT.GIF"/>
<node TEXT="ACEXPDTN.GIF" ID="Freeplane_Link_1339877706" CREATED="1170405329429" MODIFIED="1170405329429" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/ACEXPDTN.GIF"/>
<node TEXT="ACINDSTR.GIF" ID="Freeplane_Link_1772818073" CREATED="1170405329429" MODIFIED="1170405329445" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/ACINDSTR.GIF"/>
<node TEXT="ACRICEPR.GIF" ID="Freeplane_Link_1143314187" CREATED="1170405329445" MODIFIED="1170405329445" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/ACRICEPR.GIF"/>
<node TEXT="ACSNDSTN.GIF" ID="Freeplane_Link_1692161100" CREATED="1170405329445" MODIFIED="1170405329445" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/ACSNDSTN.GIF"/>
<node TEXT="ACSUMIPT.GIF" ID="Freeplane_Link_1569128746" CREATED="1170405329460" MODIFIED="1170405329460" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/ACSUMIPT.GIF"/>
<node TEXT="GLOBE.WMF" ID="Freeplane_Link_569631745" CREATED="1170405329460" MODIFIED="1170405329460" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/GLOBE.WMF"/>
<node TEXT="STONE.BMP" ID="Freeplane_Link_345608504" CREATED="1170405329476" MODIFIED="1170405329476" LINK="file:/C:/Archivos%20de%20programa/Microsoft%20Office%202003/OFFICE11/BITMAPS/STYLES/STONE.BMP"/>
</node>
</node>
</node>
<node TEXT="Importar los Favoritos de Internet Explorer" FOLDED="true" POSITION="right" ID="Freeplane_Link_269203785" CREATED="1124560950732" MODIFIED="1170658741756" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Para importar la carpeta favoritos de Microsoft Internet Explorer, utilice la siguiente opci&#xf3;n del men&#xfa; principal: Archivo--&gt;Importar--&gt;Favoritos del Explorer. Se le pedir&#xe1; que indique la carpeta d&#xf3;nde est&#xe1;n ubicados en su equipo. La ubicaci&#xf3;n suele ser: &#x201c;c:\documents and settings\&lt;usuario&gt;\Favoritos\&#x201d;" ID="Freeplane_Link_1571419416" CREATED="1170658759990" MODIFIED="1170658759990"/>
<node TEXT="Palabras clave: Microsoft Internet Explorer, MSIE, MS IE." ID="Freeplane_Link_184137676" CREATED="1170658759990" MODIFIED="1170658849395" COLOR="#999999">
<arrowlink SHAPE="LINE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="Freeplane_Link_184137676" STARTINCLINATION="0;0;" ENDINCLINATION="0;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Importar mapas mentales de MindManager X5" FOLDED="true" POSITION="right" ID="Freeplane_Link_1709974530" CREATED="1124560950732" MODIFIED="1170661959523" COLOR="#407000">
<node TEXT="Para importar un mapa de MindManager X5, utilice la opci&#xf3;n del men&#xfa; principal: Archivo--&gt;Importar--&gt;MindManager X5 map." ID="Freeplane_Link_281596646" CREATED="1170658887175" MODIFIED="1170658887175"/>
</node>
<node TEXT="Integraci&#xf3;n con Microsoft Word &#xf3; Outlook" FOLDED="true" POSITION="right" ID="Freeplane_Link_913645795" CREATED="1124560950732" MODIFIED="1170658902269" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Puede pegar mapas &#xf3; ramas en Microsoft Word, Wordmap &#xf3; mensajes de Outlook. En general, puede pegarlo en cualquier aplicaci&#xf3;n que soporte el formato de texto enriquecido. De ese modo, los enlaces y el formato del texto se mantendr&#xe1;." ID="Freeplane_Link_1195798098" CREATED="1170658910394" MODIFIED="1170658910394"/>
<node TEXT="Haciendo click en un enlace de correo electr&#xf3;nico (mailto:usuario@correo.com) se abrir&#xe1; Microsoft Outlook para crear un nuevo mensaje, &#xf3; el programa de correo electr&#xf3;nico establecido por defecto." ID="ID_635197281" CREATED="1170658910394" MODIFIED="1170658910394" LINK="mailto:(mailto:usuario@correo.com)"/>
<node TEXT="Puede poner el asunto en el enlace de correo." ID="Freeplane_Link_1391168579" CREATED="1170658910394" MODIFIED="1170658942034">
<icon BUILTIN="Mail"/>
</node>
<node TEXT="Otra manera de copiar un mapa mental a Microsoft Word es export&#xe1;ndolo a HTML y despu&#xe9;s copiar y pegarlo en Word." ID="Freeplane_Link_1826214858" CREATED="1170658910394" MODIFIED="1170662230814"/>
</node>
<node TEXT="Configurar las preferencias" FOLDED="true" POSITION="right" ID="Freeplane_Link_1822195277" CREATED="1124560950732" MODIFIED="1170658962190" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Para editar las preferencias, utilice el men&#xfa; principal: Herramientas--&gt;Preferencias. La mayor&#xed;a de los cambios surtir&#xe1;n efecto cuando reinicie Freeplane." ID="Freeplane_Link_1506877434" CREATED="1170658981392" MODIFIED="1170658981392"/>
<node TEXT="Las preferencias incluyen mapeo de teclas, comportamientos al exportar a HTML, el modo de selecci&#xf3;n de nodos mediante rat&#xf3;n, elegir antialising (mejorar pixelado de los mapas), etc." ID="ID_1156010395" CREATED="1170658981392" MODIFIED="1170658981392"/>
<node TEXT="Palabra clave: Customizing." ID="Freeplane_Link_1861005230" CREATED="1170658981392" MODIFIED="1170659009079" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Imprimir" FOLDED="true" POSITION="right" ID="Freeplane_Link_1528828442" CREATED="1124560950732" MODIFIED="1170659031313" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Puede imprimir un mapa ajust&#xe1;ndolo a una p&#xe1;gina, como imprimi&#xe9;ndolo en varios trozos de papel. Esta opci&#xf3;n se puede establecer en el men&#xfa;: Archivo--&gt;Configurar P&#xe1;gina." ID="Freeplane_Link_648343751" CREATED="1170659046235" MODIFIED="1170659046235"/>
<node TEXT="Para hacer mejor uso del espacio, utilice el formato horizontal de p&#xe1;gina &#xf3; apaisado." ID="ID_1119430838" CREATED="1170659046235" MODIFIED="1170659046235"/>
<node TEXT="La previsualizaci&#xf3;n del mapa impreso no se puede hacer directamente. Si tiene una impresora postscript &#xf3; driver gen&#xe9;rico postscript, puede imprimir el mapa a un fichero y despu&#xe9;s verlo con Ghostview &#xf3; aplicaciones similares (Adobe PDF). Si lo imprime con una empresa no entienda Postscript (PS), posiblemente el formato sea PCL, que no le servir&#xe1; para la previsualizaci&#xf3;n." ID="ID_783050821" CREATED="1170659046235" MODIFIED="1170659046235"/>
<node TEXT="Tambi&#xe9;n puede imprimirlo desde su navegador, exportando el mapa a HTML, a Word &#xf3; WordPad despu&#xe9;s de copiarlo y pegarlo all&#xed;. Tambi&#xe9;n lo puede exportar a HTML, copiarlo y pegarlo a Microsoft Word e imprimirlo desde all&#xed;. De ese modo podr&#xe1; hacer tambi&#xe9;n modificaciones de estilos." ID="ID_138283486" CREATED="1170659046235" MODIFIED="1170659046235"/>
</node>
<node TEXT="Usar texto enriquecido por medio de HTML en los nodos" FOLDED="true" POSITION="right" ID="Freeplane_Link_841140408" CREATED="1124560950732" MODIFIED="1170659084531" COLOR="#407000">
<node TEXT="Los nodos que comienzan con &lt;html&gt; son renderizados &#xf3; construidos usando HTML en ellos. Esta caracter&#xed;stica le ser&#xe1; de gran ayuda para personas de perfil t&#xe9;cnico. Ejemplo:" ID="Freeplane_Link_229410555" CREATED="1124560950732" MODIFIED="1170659119233"/>
<node ID="Freeplane_Link_926533297" CREATED="1124560950732" MODIFIED="1170659293886"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3>
      Ejemplo HTML
    </h3>
    <p class="msonormal">
      Hay varios elementos:
    </p>
    <ul type="disc">
      <li class="msonormal">
        Elemento 1
      </li>
      <li class="msonormal">
        Elemento 2
      </li>
    </ul>
    <p class="msonormal">
      Y puede tener <b>negrita</b> &#243; <i>cursiva</i>. <u>Subrayado</u> &#243; <strike>tachado</strike> tambi&#233;n. Puede tener una tabla:
    </p>
    <table cellpadding="0" class="msonormaltable" border="1" cellspacing="0" style="border-top-color: border-color; border-top-style: none; border-top-width: medium; border-right-color: border-color; border-right-style: none; border-right-width: medium; border-bottom-color: border-color; border-bottom-style: none; border-bottom-width: medium; border-left-color: border-color; border-left-style: none; border-left-width: medium">
      <tr>
        <td style="padding-left: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-top: .75pt">
          <p class="msonormal">
            Celda1
          </p>
        </td>
        <td style="border-left-color: border-color; border-left-style: none; border-left-width: medium; padding-left: .75pt; padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt">
          <p class="msonormal">
            Celda2
          </p>
        </td>
      </tr>
      <tr>
        <td style="border-top-color: border-color; border-top-style: none; border-top-width: medium; padding-left: .75pt; padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt">
          <p class="msonormal">
            Celda3
          </p>
        </td>
        <td style="border-top-color: border-color; border-top-style: none; border-top-width: medium; border-left-color: border-color; border-left-style: none; border-left-width: medium; padding-left: .75pt; padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt">
          <p class="msonormal">
            Celda4.
          </p>
        </td>
      </tr>
    </table>
    <p class="msonormal">
      &#160;Puede tener varios colores de <font color="#999900">letra</font> .
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Podemos tener varios colores de fondo." ID="Freeplane_Link_697302079" CREATED="1170659095078" MODIFIED="1170659349682" BACKGROUND_COLOR="#66ff66"/>
<node TEXT="No hay soporte para para nodos HTML e im&#xe1;genes exportando a texto &#xf3; a RTF (Word, Wordpad). Por ello, es conveniente hacer uso del applet para mostrar v&#xed;a web HTML un mapa mental." ID="Freeplane_Link_1287825225" CREATED="1170659095078" MODIFIED="1170662241845"/>
</node>
<node TEXT="Usar im&#xe1;genes en nodos" FOLDED="true" POSITION="right" ID="Freeplane_Link_1325373651" CREATED="1124560950732" MODIFIED="1170659376494" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Para insertar una imagen en Freeplane, pulse ALT+K, &#xf3; en el men&#xfa; contextual de nodo, use Insertar--&gt;Imagen. Si inserta una imagen en un nodo, perder&#xe1; todo el texto del mismo. Las im&#xe1;genes insertadas de este modo, no podr&#xe1;n f&#xe1;cilmente pegadas fuera de Freeplane y no necesariamente se exportar&#xe1;n correctamente a HTML. Las im&#xe1;genes son una caracter&#xed;stica en versi&#xf3;n beta dentro de esta versi&#xf3;n de Freeplane." ID="Freeplane_Link_833228264" CREATED="1170659386072" MODIFIED="1170659386072"/>
<node TEXT="Los formatos de im&#xe1;genes soportados son PNG, JPEG y GIF." ID="ID_1501233865" CREATED="1170659386072" MODIFIED="1170659386072"/>
<node TEXT="Para convertir enlaces de im&#xe1;genes, a im&#xe1;genes visibles, pulse ALT+K. Podr&#xe1; arrastrar y soltar varios ficheros de im&#xe1;genes a Freeplane, seleccion&#xe1;ndolas como nodos m&#xfa;ltiples, y convirti&#xe9;ndolas en im&#xe1;genes presionando ALT+K." ID="ID_101360059" CREATED="1170659386072" MODIFIED="1170659386072"/>
<node TEXT="Existe otro modo de insertar im&#xe1;genes m&#xe1;s t&#xe9;cnico y menos sencillo de hacer. Es posible incluir HTML en nodos, de modo que si se incluyen im&#xe1;genes all&#xed;, comenzando el nodo con la palabra &lt;html&gt;, lo lograr&#xed;amos." ID="ID_122465215" CREATED="1170659386072" MODIFIED="1170659386072"/>
<node TEXT="Por ejemplo&#xa;&lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;&#xa;&lt;html&gt;&lt;img src=&quot;file://C://Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;" ID="Freeplane_Link_1490826264" CREATED="1170659386072" MODIFIED="1170659481852"/>
<node TEXT="Puede enlace a im&#xe1;genes con path relativos (Como en el ejemplo 1)." ID="ID_1569498076" CREATED="1170659386072" MODIFIED="1170659386072"/>
<node TEXT="Ejemplo de im&#xe1;genes, funcionando sobre varias distribuciones de Windows" FOLDED="true" ID="Freeplane_Link_760617188" CREATED="1170659386072" MODIFIED="1170660121542" COLOR="#996600">
<font NAME="SansSerif" SIZE="12" BOLD="true"/>
<node ID="Freeplane_Link_1832742863" CREATED="1170659886641" MODIFIED="1170659933843"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Archivos de programa/Freeplane/doc/freeplane_dragdrop_small.gif"/>
  </body>
</html>

</richcontent>
</node>
<node ID="Freeplane_Link_1808501808" CREATED="1170659993045" MODIFIED="1170660033263"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Archivos de programa/Freeplane/doc/MindmapExample.png"/>
  </body>
</html>

</richcontent>
</node>
<node TEXT="freeplane_dragdrop_small.gif" ID="Freeplane_Link_308307832" CREATED="1170660129605" MODIFIED="1170660732421" LINK="freeplane_dragdrop_small.gif"/>
<node TEXT="MindmapExample.png" ID="Freeplane_Link_341958438" CREATED="1170660745374" MODIFIED="1170660769546" LINK="MindmapExample.png"/>
</node>
</node>
<node TEXT="Usar el bloque de ficheros (Experimental)" FOLDED="true" POSITION="right" ID="Freeplane_Link_538720495" CREATED="1124560950732" MODIFIED="1170660804545" COLOR="#407000">
<node TEXT="La versi&#xf3;n actual de Freeplane tiene una caracter&#xed;stica experimental, deshabilitada por defecto. Deber&#xed;a funcionar bien, pero no est&#xe1; totalmente depurada." ID="Freeplane_Link_765143806" CREATED="1170660815888" MODIFIED="1170660815888"/>
<node TEXT="El bloqueo de ficheros sirve para prevenir problemas de sobreescritura, cuando dos usuarios editan el mismo mapa al mismo tiempo." ID="ID_956414327" CREATED="1170660815888" MODIFIED="1170660815888"/>
<node TEXT="Para habilitar el bloque de ficheros experimental, utilice el men&#xfa; principal Herramientas--&gt;Preferences (Preferencias)." ID="ID_1652290727" CREATED="1170660815888" MODIFIED="1170660815888"/>
</node>
</node>
</map>
