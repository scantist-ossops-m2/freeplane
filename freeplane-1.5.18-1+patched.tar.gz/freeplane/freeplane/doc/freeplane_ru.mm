<map version="freeplane 1.5.9">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body width=&quot;&quot;&gt;&#xa;    &lt;p align=&quot;center&quot;&gt;&#xa;      Freeplane&lt;br&gt;&lt;small&gt;- &amp;#1086;&amp;#1090;&amp;#1082;&amp;#1088;&amp;#1099;&amp;#1090;&amp;#1072;&amp;#1103; &amp;#1087;&amp;#1088;&amp;#1086;&amp;#1075;&amp;#1088;&amp;#1072;&amp;#1084;&amp;#1084;&amp;#1072; - &lt;/small&gt;&#xa;    &lt;/p&gt;&#xa;    &lt;p align=&quot;center&quot;&gt;&#xa;      &lt;small&gt;- &amp;#1076;&amp;#1083;&amp;#1103; &amp;#1088;&amp;#1072;&amp;#1073;&amp;#1086;&amp;#1090;&amp;#1099; &amp;#1089;&amp;#1086; &amp;#1089;&amp;#1093;&amp;#1077;&amp;#1084;&amp;#1072;&amp;#1084;&amp;#1080; &amp;#1084;&amp;#1099;&amp;#1096;&amp;#1083;&amp;#1077;&amp;#1085;&amp;#1080;&amp;#1103; -&lt;/small&gt;&amp;#160;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" FOLDED="false" ID="ID_498367085" CREATED="1465678964117" MODIFIED="1465678964117" COLOR="#993300">
<font NAME="Dialog" SIZE="18" BOLD="true"/>
<hook NAME="MapStyle">
    <properties fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt" TEXT_SHORTENED="true">
<font SIZE="24"/>
<richcontent TYPE="DETAILS" LOCALIZED_HTML="styles_background_html"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="default" COLOR="#000000" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0.0 pt" FORMAT="NO_FORMAT" TEXT_ALIGN="CENTER" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font NAME="Arial" SIZE="9" BOLD="true" ITALIC="false"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details">
<font SIZE="11"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#000000" BACKGROUND_COLOR="#ffffff">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
<edge COLOR="#0000cc"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" UNIFORM_SHAPE="true" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font SIZE="24" ITALIC="true"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2">
<edge COLOR="#ff0033"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3">
<edge COLOR="#009933"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4">
<edge COLOR="#3333ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5">
<edge COLOR="#ff6600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6">
<edge COLOR="#cc00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7">
<edge COLOR="#ffbf00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8">
<edge COLOR="#00ff99"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9">
<edge COLOR="#0099ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10">
<edge COLOR="#996600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12">
<edge COLOR="#cc0066"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13">
<edge COLOR="#33ff00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14">
<edge COLOR="#ff9999"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15">
<edge COLOR="#0000cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16">
<edge COLOR="#cccc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17">
<edge COLOR="#0099cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18">
<edge COLOR="#006600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19">
<edge COLOR="#ff00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20">
<edge COLOR="#00cc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21">
<edge COLOR="#0066cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22">
<edge COLOR="#00ffff"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="&#x414;&#x43e;&#x43c;&#x430;&#x448;&#x43d;&#x44f;&#x44f; &#x441;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;&#x430; Freeplane" POSITION="left" ID="ID_527692916" CREATED="1465678964133" MODIFIED="1465678964133" LINK="http://freeplane.sourceforge.net">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x421;&#x43f;&#x438;&#x441;&#x43e;&#x43a; &#x434;&#x435;&#x439;&#x441;&#x442;&#x432;&#x438;&#x439; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x448;" FOLDED="true" POSITION="left" ID="ID_17107809" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#006699">
<node TEXT="&#x424;&#x430;&#x439;&#x43b;&#x43e;&#x432;&#x44b;&#x435; &#x43a;&#x43e;&#x43c;&#x430;&#x43d;&#x434;&#x44b;:&#xa;&#x41d;&#x43e;&#x432;&#x430;&#x44f; &#x441;&#x445;&#x435;&#x43c;&#x430;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+N&#xa;&#x41e;&#x442;&#x43a;&#x440;&#x44b;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x443;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+O&#xa;&#x421;&#x43e;&#x445;&#x440;&#x430;&#x43d;&#x438;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x443;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+S&#xa;&#x421;&#x43e;&#x445;&#x440;&#x430;&#x43d;&#x438;&#x442;&#x44c; &#x43a;&#x430;&#x43a;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+A&#xa;&#x41f;&#x435;&#x447;&#x430;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+P&#xa;&#x417;&#x430;&#x43a;&#x440;&#x44b;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+W&#xa;&#x412;&#x44b;&#x445;&#x43e;&#x434;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+Q&#xa;&#x41f;&#x440;&#x435;&#x434;&#x44b;&#x434;&#x443;&#x449;&#x430;&#x44f; &#x441;&#x445;&#x435;&#x43c;&#x430; - Ctrl+LEFT&#xa;&#x421;&#x43b;&#x435;&#x434;&#x443;&#x449;&#x430;&#x44f; &#x441;&#x445;&#x435;&#x43c;&#x430;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+RIGHT&#xa;&#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x432; HTML&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+E&#xa;&#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x432;&#x435;&#x442;&#x432;&#x44c; &#x432; HTML&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+H&#xa;&#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x432;&#x435;&#x442;&#x432;&#x44c; &#x432; &#x43d;&#x43e;&#x432;&#x44b;&#x439; MM &#x444;&#x430;&#x439;&#x43b; - Alt+A&#xa;&#x41e;&#x442;&#x43a;&#x440;&#x44b;&#x442;&#x44c; &#x43f;&#x43e;&#x441;&#x43b;&#x435;&#x434;&#x43d;&#x438;&#x439; &#x444;&#x430;&#x439;&#x43b;&#xa0;&#xa0;&#xa0;- Ctrl+Shift+W&#xa;&#xa;&#x41a;&#x43e;&#x43c;&#x430;&#x43d;&#x434;&#x44b; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;:&#xa;&#x41f;&#x43e;&#x438;&#x441;&#x43a;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+F&#xa;&#x41d;&#x430;&#x439;&#x442;&#x438; &#x434;&#x430;&#x43b;&#x435;&#x435;&#xa0;&#xa0;&#xa0;- Ctrl+G&#xa;&#x412;&#x44b;&#x440;&#x435;&#x437;&#x430;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+X&#xa;&#x41a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+C&#xa;&#x41a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x44d;&#x442;&#x43e;&#x442; &#x443;&#x437;&#x435;&#x43b; - Ctrl+Y&#xa;&#x412;&#x441;&#x442;&#x430;&#x432;&#x438;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+V&#xa;&#xa;&#x41a;&#x43e;&#x43c;&#x430;&#x43d;&#x434;&#x44b; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x43e;&#x432;:&#xa;&#x420;&#x435;&#x436;&#x438;&#x43c; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; - Alt+1&#xa;&#x41e;&#x431;&#x437;&#x43e;&#x440; &#x441;&#x445;&#x435;&#x43c;&#xa0;&#xa0;- Alt+2&#xa0;&#xa;&#x424;&#x430;&#x439;&#x43b;-&#x431;&#x440;&#x430;&#x443;&#x437;&#x435;&#x440;&#xa0;&#xa0;&#xa0;&#xa0;- Alt+3&#xa;&#xa;&#x41a;&#x43e;&#x43c;&#x430;&#x43d;&#x434;&#x44b; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x43e;&#x432;:&#xa;&#x41a;&#x443;&#x440;&#x441;&#x438;&#x432;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+I&#xa;&#x416;&#x438;&#x440;&#x43d;&#x44b;&#x439;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+B&#xa;&#x41e;&#x431;&#x43b;&#x430;&#x43a;&#x43e;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+Shift+B&#xa;&#x418;&#x437;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x446;&#x432;&#x435;&#x442; &#x443;&#x437;&#x43b;&#x430;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Alt+C&#xa;&#x412;&#x44b;&#x441;&#x432;&#x435;&#x442;&#x438;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Alt+B&#xa;&#x418;&#x437;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x446;&#x432;&#x435;&#x442; &#x434;&#x443;&#x433;&#x438;&#xa0;&#xa0;&#xa0;&#xa0;- Alt+E&#xa;&#x423;&#x432;&#x435;&#x43b;&#x438;&#x447;&#x438;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43c;&#x435;&#x440; &#x448;&#x440;&#x438;&#x444;&#x442;&#x430; &#x443;&#x437;&#x43b;&#x430;&#xa0;&#xa0;&#xa0;- Ctrl+L&#xa;&#x423;&#x43c;&#x435;&#x43d;&#x44c;&#x448;&#x438;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43c;&#x435;&#x440; &#x448;&#x440;&#x438;&#x444;&#x442;&#x430; &#x443;&#x437;&#x43b;&#x430;&#xa0;&#xa0;&#xa0;- Ctrl+M&#xa;&#x423;&#x432;&#x435;&#x43b;&#x438;&#x447;&#x438;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43c;&#x435;&#x440; &#x448;&#x440;&#x438;&#x444;&#x442;&#x430; &#x432;&#x441;&#x435;&#x439; &#x432;&#x435;&#x442;&#x432;&#x438; - Ctrl+Shift+L&#xa;&#x423;&#x43c;&#x435;&#x43d;&#x44c;&#x448;&#x438;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43c;&#x435;&#x440; &#x448;&#x440;&#x438;&#x444;&#x442;&#x430; &#x432;&#x441;&#x435;&#x439; &#x432;&#x435;&#x442;&#x432;&#x438; - Ctrl+Shift+M&#xa;&#xa;&#x41a;&#x43e;&#x43c;&#x430;&#x43d;&#x434;&#x44b; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f;:&#xa;&#x41a; &#x43a;&#x43e;&#x440;&#x43d;&#x435;&#x432;&#x43e;&#x43c;&#x443; &#x443;&#x437;&#x43b;&#x443;&#xa0;&#xa0;- ESCAPE&#xa;&#x412;&#x432;&#x435;&#x440;&#x445;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- UP&#xa;&#x412;&#x43d;&#x438;&#x445;&#xa0;&#xa0;&#xa0;- DOWN&#xa;&#x412;&#x43b;&#x435;&#x432;&#x43e;&#xa0;&#xa0;&#xa0;- LEFT&#xa;&#x412;&#x43f;&#x440;&#x430;&#x432;&#x43e;&#xa0;&#xa0;- RIGHT&#xa;&#x41f;&#x435;&#x440;&#x435;&#x439;&#x442;&#x438; &#x43f;&#x43e; &#x441;&#x441;&#x43b;&#x44b;&#x43a;&#x435; - Ctrl+ENTER&#xa;&#x41e;&#x442;&#x434;&#x430;&#x43b;&#x438;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;- Alt+UP&#xa;&#x41f;&#x440;&#x438;&#x431;&#x43b;&#x438;&#x437;&#x438;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Alt+DOWN&#xa;&#xa;&#x41d;&#x43e;&#x432;&#x44b;&#x435; &#x43a;&#x43e;&#x43c;&#x430;&#x43d;&#x434;&#x44b; &#x443;&#x437;&#x43b;&#x43e;&#x432;:&#xa;&#x414;&#x43e;&#x431;&#x430;&#x432;&#x438;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;-&#x431;&#x440;&#x430;&#x442;&#xa0;&#xa0;&#xa0;- ENTER&#xa;&#x414;&#x43e;&#x431;&#x430;&#x432;&#x438;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;-&#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43e;&#x43a;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- INSERT&#xa;&#x414;&#x43e;&#x431;&#x430;&#x432;&#x438;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;-&#x431;&#x440;&#x430;&#x442; &#x43f;&#x435;&#x440;&#x435;&#x434; - Shift+ENTER&#xa;&#xa;&#x420;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x443;&#x437;&#x43b;&#x43e;&#x432;:&#xa;&#x418;&#x437;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x442;&#x435;&#x43a;&#x443;&#x449;&#x438;&#x439; &#x443;&#x437;&#x435;&#x43b;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- F2&#xa;&#x418;&#x437;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x432; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;&#x435;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Alt+ENTER&#xa;&#x41e;&#x431;&#x44a;&#x435;&#x434;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x443;&#x437;&#x43b;&#x44b;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+J&#xa;&#x421;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c;/&#x440;&#x430;&#x437;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- SPACE&#xa;&#x421;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c;/&#x440;&#x430;&#x437;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c; &#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x43e;&#x432;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+SPACE&#xa;&#x412;&#x44b;&#x431;&#x440;&#x430;&#x442;&#x44c; &#x444;&#x430;&#x439;&#x43b; &#x434;&#x43b;&#x44f; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438;&#xa0;&#xa0;&#xa0;- Ctrl+Shift+K&#xa;&#x412;&#x432;&#x435;&#x441;&#x442;&#x438; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x443; &#x432;&#x440;&#x443;&#x447;&#x43d;&#x443;&#x44e;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+K&#xa;&#x412;&#x44b;&#x431;&#x440;&#x430;&#x442;&#x44c; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x435; &#x434;&#x43b;&#x44f; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438;&#xa0;&#xa0;- Alt+K&#xa;&#x41f;&#x43e;&#x434;&#x43d;&#x44f;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+UP&#xa;&#x41e;&#x43f;&#x443;&#x441;&#x442;&#x438;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;- Ctrl+DOWN" ID="ID_1702844196" CREATED="1465678964133" MODIFIED="1465678964133">
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node TEXT="&#x423;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x430;" FOLDED="true" POSITION="left" ID="ID_864870804" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#006633">
<node TEXT="&#x421;&#x441;&#x44b;&#x43b;&#x43a;&#x438;" FOLDED="true" ID="ID_1406827422" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#006699">
<node TEXT="&#x421;&#x43a;&#x430;&#x447;&#x430;&#x442;&#x44c; Java Runtime Environment (&#x43a;&#x430;&#x43a; &#x43c;&#x438;&#x43d;&#x438;&#x43c;&#x443;&#x43c; J2RE1.4)" ID="ID_298726508" CREATED="1465678964133" MODIFIED="1465678964133" LINK="http://java.sun.com/javase/downloads/index.jsp">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x421;&#x43a;&#x430;&#x447;&#x430;&#x442;&#x44c; &#x43f;&#x440;&#x438;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x435;" ID="ID_1257373551" CREATED="1465678964133" MODIFIED="1465678964133" LINK="http://freeplane.sourceforge.net/wiki/index.php/Download#Download">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x438; Freeplane &#x432; Microsoft Windows, &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x438;&#x442;&#x435; Java &#x43e;&#x442; &#x444;&#x438;&#x440;&#x43c;&#x44b; Sun &#x438; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x438;&#x442;&#x435; Freeplane &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x44f; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x449;&#x438;&#x43a; Freeplane." ID="ID_551943844" CREATED="1465678964133" MODIFIED="1465678964133"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x438; Freeplane &#x432; Linux, &#x441;&#x43a;&#x430;&#x447;&#x430;&#x439;&#x442;&#x435; Java Runtime Environment &#x438; Freeplane &#x441;&#x430;&#x43c;&#x43e;&#x441;&#x442;&#x43e;&#x44f;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e;. &#x421;&#x43d;&#x430;&#x447;&#x430;&#x43b;&#x430; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x438;&#x442;&#x435; Java, &#x437;&#x430;&#x442;&#x435;&#x43c; &#x440;&#x430;&#x441;&#x43f;&#x430;&#x43a;&#x443;&#x439;&#x442;&#x435; Freeplane. &#x414;&#x43b;&#x44f; &#x437;&#x430;&#x43f;&#x443;&#x441;&#x43a;&#x430; Freeplane, &#x432;&#x44b;&#x43f;&#x43e;&#x43b;&#x43d;&#x44f;&#x439;&#x442;&#x435; freeplane.sh." ID="ID_1013312765" CREATED="1465678964133" MODIFIED="1465678964133"/>
<node TEXT="&#x412; Microsoft Windows &#x438; Mac OS X, &#x432;&#x44b; &#x442;&#x430;&#x43a; &#x436;&#x435; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x43e; &#x434;&#x432;&#x430;&#x436;&#x434;&#x44b; &#x43a;&#x43b;&#x438;&#x43a;&#x430;&#x442;&#x44c; &#x43d;&#x430; freeplane.jar &#x440;&#x430;&#x441;&#x43f;&#x43e;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x43d;&#x44b;&#x439; &#x432; &#x43f;&#x430;&#x43f;&#x43a;&#x435; lib &#x434;&#x43b;&#x44f; &#x437;&#x430;&#x43f;&#x443;&#x441;&#x43a;&#x430; Freeplane." ID="ID_1321921750" CREATED="1465678964133" MODIFIED="1465678964133"/>
</node>
<node TEXT="&#x41e;&#x431;&#x437;&#x43e;&#x440; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; &#x43d;&#x430; &#x432;&#x430;&#x448;&#x435;&#x43c; &#x43a;&#x43e;&#x43c;&#x43f;&#x44c;&#x44e;&#x442;&#x435;&#x440;&#x435;" FOLDED="true" POSITION="left" ID="ID_834359529" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x43e;&#x431;&#x437;&#x43e;&#x440;&#x430; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432;, &#x43f;&#x435;&#x440;&#x435;&#x43a;&#x43b;&#x44e;&#x447;&#x438;&#x442;&#x435;&#x441;&#x44c; &#x432; &#x440;&#x435;&#x436;&#x438;&#x43c; &#x41e;&#x431;&#x43e;&#x437;&#x440;&#x435;&#x432;&#x430;&#x442;&#x435;&#x43b;&#x44f; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; &#x432; &#x43c;&#x435;&#x43d;&#x44e; &#x41a;&#x430;&#x440;&#x442;&#x44b; &gt; &#x41e;&#x431;&#x43e;&#x437;&#x440;&#x435;&#x432;&#x430;&#x442;&#x435;&#x43b;&#x44c; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432;." ID="ID_924725879" CREATED="1465678964133" MODIFIED="1465678964133"/>
<node TEXT="&#x412;&#x44b; &#x432;&#x438;&#x434;&#x438;&#x442;&#x435; &#x434;&#x435;&#x440;&#x435;&#x432;&#x43e; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; &#x43a;&#x430;&#x43a; &#x435;&#x441;&#x43b;&#x438; &#x431;&#x44b; &#x43e;&#x43d;&#x43e; &#x431;&#x44b;&#x43b;&#x43e; &#x441;&#x445;&#x435;&#x43c;&#x43e;&#x439; &#x441;&#x43e;&#x437;&#x43d;&#x430;&#x43d;&#x438;&#x44f;." ID="ID_196481749" CREATED="1465678964133" MODIFIED="1465678964133"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x446;&#x435;&#x43d;&#x442;&#x440;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x43e;&#x431;&#x437;&#x43e;&#x440;&#x430; &#x43d;&#x430; &#x443;&#x437;&#x43b;&#x435;, &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; Center." ID="ID_1933217534" CREATED="1465678964133" MODIFIED="1465678964133"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x440;&#x43e;&#x441;&#x43c;&#x43e;&#x442;&#x440;&#x430;, &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x438;&#x43b;&#x438; &#x437;&#x430;&#x43f;&#x443;&#x441;&#x43a;&#x430; &#x444;&#x430;&#x439;&#x43b;&#x430;, &#x43f;&#x435;&#x440;&#x435;&#x439;&#x434;&#x438;&#x442;&#x435; &#x43f;&#x43e; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x435; &#x435;&#x433;&#x43e; &#x443;&#x437;&#x43b;&#x430;." ID="ID_604549801" CREATED="1465678964133" MODIFIED="1465678964133"/>
<node TEXT="&#x41e;&#x431;&#x437;&#x43e;&#x432; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; &#x432;&#x43e;&#x431;&#x449;&#x435;&#x43c; &#x43d;&#x435; &#x43e;&#x447;&#x435;&#x43d;&#x44c; &#x43f;&#x43e;&#x43b;&#x435;&#x437;&#x435;&#x43d;. &#x42d;&#x442;&#x43e; &#x434;&#x435;&#x43c;&#x43e;&#x43d;&#x441;&#x442;&#x440;&#x430;&#x446;&#x438;&#x44f; &#x442;&#x43e;&#x433;&#x43e;, &#x447;&#x442;&#x43e; &#x434;&#x43e;&#x432;&#x43e;&#x43b;&#x44c;&#x43d;&#x43e; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x43e; &#x43f;&#x440;&#x435;&#x43e;&#x431;&#x440;&#x430;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x434;&#x430;&#x43d;&#x43d;&#x44b;&#x435; &#x438;&#x437; &#x43a;&#x430;&#x43a;&#x43e;&#x433;&#x43e;-&#x43b;&#x438;&#x431;&#x43e; &#x438;&#x441;&#x442;&#x43e;&#x447;&#x43d;&#x438;&#x43a;&#x430; &#x432; &#x434;&#x435;&#x440;&#x435;&#x432;&#x43e;. &#x412;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x434;&#x430;&#x436;&#x435; &#x447;&#x442;&#x43e; &#x43d;&#x438;&#x43a;&#x442;&#x43e; &#x43d;&#x435; &#x431;&#x443;&#x434;&#x435;&#x442; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x44d;&#x442;&#x43e;&#x442; &#x440;&#x435;&#x436;&#x438;&#x43c;." ID="ID_160895175" CREATED="1465678964133" MODIFIED="1465678964133"/>
</node>
<node TEXT="&#x41e;&#x431;&#x437;&#x43e;&#x440; &#x441;&#x445;&#x435;&#x43c;" FOLDED="true" POSITION="left" ID="ID_693879703" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x43e;&#x431;&#x437;&#x43e;&#x440;&#x430; &#x441;&#x445;&#x435;&#x43c; &#x438; &#x43f;&#x43e;&#x441;&#x43b;&#x435;&#x434;&#x443;&#x449;&#x435;&#x433;&#x43e; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;, &#x43f;&#x435;&#x440;&#x435;&#x43a;&#x43b;&#x44e;&#x447;&#x438;&#x442;&#x435;&#x441;&#x44c; &#x432; &#x440;&#x435;&#x436;&#x438;&#x43c; &#x41e;&#x431;&#x43e;&#x437;&#x440;&#x435;&#x432;&#x430;&#x442;&#x435;&#x43b;&#x44c; &#x441;&#x445;&#x435;&#x43c; &#x432; &#x43c;&#x435;&#x43d;&#x44e; &#x41a;&#x430;&#x440;&#x442;&#x44b; &gt; &#x41e;&#x431;&#x437;&#x43e;&#x440; &#x441;&#x445;&#x435;&#x43c;. &#x411;&#x435;&#x437; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; Freeplane applet, &#x44d;&#x442;&#x430; &#x444;&#x443;&#x43d;&#x43a;&#x446;&#x438;&#x44f; &#x432;&#x43f;&#x43e;&#x43b;&#x43d;&#x435; &#x431;&#x435;&#x441;&#x43f;&#x43e;&#x43b;&#x435;&#x437;&#x43d;&#x430;." ID="ID_1918617806" CREATED="1465678964133" MODIFIED="1465678964133"/>
<node TEXT="&#x41f;&#x440;&#x438;&#x447;&#x438;&#x43d;&#x44b; &#x43d;&#x430;&#x43b;&#x438;&#x447;&#x438;&#x44f; &#x440;&#x430;&#x437;&#x434;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x445; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x43e;&#x432; &#x43e;&#x431;&#x437;&#x43e;&#x440;&#x430; - &#x442;&#x435;&#x445;&#x43d;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438;&#x435;. &#x41e;&#x431;&#x437;&#x43e;&#x440; - &#x435;&#x434;&#x438;&#x43d;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x43e;&#x435; &#x447;&#x442;&#x43e; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x434;&#x435;&#x43b;&#x430;&#x442;&#x44c; &#x432; Freeplane applet &#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x439; &#x43c;&#x43e;&#x436;&#x435;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x43d;&#x430; &#x432;&#x430;&#x448;&#x435;&#x43c; &#x432;&#x435;&#x431;-&#x441;&#x430;&#x439;&#x442;&#x435;. &#x421;&#x43a;&#x43e;&#x440;&#x435;&#x435; &#x432;&#x441;&#x435;&#x433;&#x43e; &#x432;&#x430;&#x43c; &#x43d;&#x435; &#x43f;&#x440;&#x438;&#x434;&#x435;&#x442;&#x441;&#x44f; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x44b; &#x43e;&#x431;&#x437;&#x43e;&#x440;&#x430; &#x43d;&#x435;&#x43f;&#x43e;&#x441;&#x440;&#x435;&#x434;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x43e; &#x432; Freeplane." ID="ID_1684751132" CREATED="1465678964133" MODIFIED="1465678964133"/>
</node>
<node TEXT="&#x41e; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x430;&#x445;" FOLDED="true" POSITION="left" ID="ID_885707013" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x425;&#x43e;&#x442;&#x44f; Freeplane &#x432; &#x43e;&#x441;&#x43d;&#x43e;&#x432;&#x43d;&#x43e;&#x43c; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x435;&#x442;&#x441;&#x44f; &#x434;&#x43b;&#x44f; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x441;&#x445;&#x435;&#x43c; &#x43c;&#x44b;&#x448;&#x43b;&#x435;&#x43d;&#x438;&#x44f;, &#x43f;&#x440;&#x43e;&#x435;&#x43a;&#x442; &#x440;&#x430;&#x437;&#x440;&#x430;&#x431;&#x43e;&#x442;&#x430;&#x43d; &#x441; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e;&#x441;&#x442;&#x44f;&#x43c;&#x438; &#x43e;&#x431;&#x437;&#x43e;&#x440;&#x430; &#x440;&#x430;&#x437;&#x43b;&#x438;&#x447;&#x43d;&#x44b;&#x445; &#x442;&#x438;&#x43f;&#x43e;&#x432; &#x434;&#x430;&#x43d;&#x43d;&#x44b;&#x445;.&#xa0;&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x441;&#x434;&#x435;&#x43b;&#x430;&#x442;&#x44c; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x44b;&#x43c; &#x43e;&#x431;&#x440;&#x430;&#x431;&#x43e;&#x442;&#x43a;&#x443; &#x43e;&#x441;&#x43e;&#x431;&#x44b;&#x445; &#x442;&#x438;&#x43f;&#x43e;&#x432; &#x434;&#x430;&#x43d;&#x43d;&#x44b;&#x445; &#x432; Freeplane, &#x43f;&#x440;&#x43e;&#x433;&#x440;&#x430;&#x43c;&#x43c;&#x438;&#x441;&#x442;&#x44b; &#x43f;&#x438;&#x448;&#x443;&#x442; &#x442;&#x430;&#x43a; &#x43d;&#x430;&#x437;&#x44b;&#x432;&#x430;&#x435;&#x43c;&#x44b;&#x435; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x44b; &#x434;&#x43b;&#x44f; &#x44d;&#x442;&#x438;&#x445; &#x442;&#x438;&#x43f;&#x43e;&#x432; &#x434;&#x430;&#x43d;&#x43d;&#x44b;&#x445;. &#x41d;&#x430;&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440; &#x440;&#x435;&#x436;&#x438;&#x43c; &#x43e;&#x431;&#x437;&#x43e;&#x440;&#x430; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432;&#x43e;&#x439; &#x441;&#x438;&#x441;&#x442;&#x435;&#x43c;&#x44b;. &#x41c;&#x44b; &#x43d;&#x435; &#x437;&#x43d;&#x430;&#x435;&#x43c; &#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x440;&#x430;&#x437;&#x43d;&#x43e;&#x43e;&#x431;&#x440;&#x430;&#x437;&#x43d;&#x44b;&#x445; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x43e;&#x432; &#x435;&#x449;&#x435; &#x431;&#x443;&#x434;&#x435;&#x442; &#x432;&#x43d;&#x435;&#x434;&#x440;&#x435;&#x43d;&#x43e;. &#x41d;&#x435;&#x438;&#x437;&#x432;&#x435;&#x441;&#x442;&#x43e;, &#x437;&#x430;&#x445;&#x43e;&#x447;&#x435;&#x442; &#x43b;&#x438; &#x435;&#x449;&#x435; &#x43a;&#x442;&#x43e;-&#x43d;&#x438;&#x431;&#x443;&#x434;&#x44c; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x44d;&#x442;&#x443; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e;&#x441;&#x442;&#x44c;; &#x43e;&#x43d;&#x430; &#x437;&#x434;&#x435;&#x441;&#x44c; &#x435;&#x441;&#x442;&#x44c; &#x43d;&#x430; &#x441;&#x43b;&#x443;&#x447;&#x430;&#x439; &#x435;&#x441;&#x43b;&#x438; &#x43a;&#x43e;&#x43c;&#x443;-&#x442;&#x43e; &#x43f;&#x43e;&#x43d;&#x430;&#x434;&#x43e;&#x431;&#x438;&#x442;&#x441;&#x44f;." ID="ID_1860404355" CREATED="1465678964133" MODIFIED="1465678964133">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x415;&#x441;&#x442;&#x44c; &#x43a;&#x43e;&#x434;, &#x43f;&#x43e;&#x447;&#x442;&#x438; &#x433;&#x43e;&#x442;&#x43e;&#x432;&#x44b;&#x439;, &#x434;&#x43b;&#x44f; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x430; scheme, &#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x439; &#x434;&#x430;&#x435;&#x442; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e;&#x441;&#x442;&#x44c; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x43f;&#x440;&#x43e;&#x433;&#x440;&#x430;&#x43c;&#x43c; &#x43d;&#x430; &#x44f;&#x437;&#x44b;&#x43a;&#x435; scheme. &#x41e;&#x43f;&#x44f;&#x442;&#x44c; &#x436;&#x435; &#x435;&#x433;&#x43e; &#x43f;&#x43e;&#x43b;&#x435;&#x437;&#x43d;&#x43e;&#x441;&#x442;&#x44c; &#x43f;&#x43e;&#x434; &#x432;&#x43e;&#x43f;&#x440;&#x43e;&#x441;&#x43e;&#x43c;. &#x412; &#x43e;&#x442;&#x43b;&#x438;&#x447;&#x438;&#x435; &#x43e;&#x442; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x430; &#x440;&#x435;&#x436;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x441;&#x445;&#x435;&#x43c;, &#x434;&#x440;&#x443;&#x433;&#x438;&#x435; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x44b; &#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x435; &#x434;&#x435;&#x43c;&#x43e;&#x43d;&#x441;&#x442;&#x440;&#x438;&#x440;&#x443;&#x44e;&#x442; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e;&#x441;&#x442;&#x438;, &#x447;&#x435;&#x43c; &#x440;&#x435;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;&#x435; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x435;." ID="ID_1818846899" CREATED="1465678964133" MODIFIED="1465678964133">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x423;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x430; Freeplane applet &#x43d;&#x430; &#x432;&#x430;&#x448; &#x432;&#x435;&#x431;-&#x441;&#x430;&#x439;&#x442;" FOLDED="true" POSITION="left" ID="ID_1179574394" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#407000">
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x438;&#x442;&#x44c; applet &#x43d;&#x430; &#x432;&#x430;&#x448; &#x432;&#x435;&#x431;-&#x441;&#x430;&#x439;&#x442; &#x442;&#x430;&#x43a;, &#x447;&#x442;&#x43e; &#x434;&#x440;&#x443;&#x433;&#x438;&#x435; &#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x435;&#x43b;&#x438; &#x43c;&#x43e;&#x433;&#x43b;&#x438; &#x432;&#x438;&#x434;&#x435;&#x442;&#x44c; &#x432;&#x430;&#x448;&#x438; &#x441;&#x445;&#x435;&#x43c;&#x44b; &#x43c;&#x44b;&#x448;&#x43b;&#x435;&#x43d;&#x438;&#x44f;." ID="ID_531190489" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#000000">
<font NAME="Dialog" SIZE="12"/>
</node>
<node TEXT="&#x421;&#x43a;&#x430;&#x447;&#x430;&#x442;&#x44c; applet, &#x442;.&#x435;. freeplane-&#x43e;&#x431;&#x43e;&#x437;&#x440;&#x435;&#x432;&#x430;&#x442;&#x435;&#x43b;&#x44c;." ID="ID_1773958248" CREATED="1465678964133" MODIFIED="1465678964133" LINK="http://sourceforge.net/project/showfiles.php?group_id=211069"/>
<node TEXT="&#x421;&#x43a;&#x430;&#x447;&#x430;&#x43d;&#x43d;&#x44b;&#x439; &#x430;&#x440;&#x445;&#x438;&#x432; &#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x438;&#x442; freeplanebrowser.jar &#x438; freeplanebrowser.html. &#x421;&#x434;&#x435;&#x43b;&#x430;&#x439;&#x442;&#x435; &#x441;&#x441;&#x43b;&#x44b;&#x43a;&#x443; &#x441;&#x43e; &#x441;&#x432;&#x43e;&#x435;&#x439; &#x441;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;&#x44b; &#x43d;&#x430; freeplanebrowser.html. &#x412;&#x43d;&#x443;&#x442;&#x440;&#x438; freeplanebrowser.html &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x435; &#x43f;&#x443;&#x442;&#x44c; &#x43d;&#x430; &#x43f;&#x443;&#x442;&#x44c; &#x43a; &#x441;&#x432;&#x43e;&#x435;&#x439; &#x441;&#x445;&#x435;&#x43c;&#x435;." ID="ID_1538167866" CREATED="1465678964133" MODIFIED="1465678964133"/>
<node TEXT="Jar &#x444;&#x430;&#x439;&#x43b; &#x430;&#x43f;&#x43f;&#x43b;&#x435;&#x442;&#x430; &#x434;&#x43e;&#x43b;&#x436;&#x435;&#x43d; &#x43d;&#x430;&#x445;&#x43e;&#x434;&#x438;&#x442;&#x441;&#x44f; &#x43d;&#x430; &#x442;&#x43e;&#x43c; &#x436;&#x435; &#x441;&#x435;&#x440;&#x432;&#x435;&#x440;&#x435; &#x447;&#x442;&#x43e; &#x438; &#x441;&#x445;&#x435;&#x43c;&#x430;, &#x438;&#x437;-&#x437;&#x430; &#x43e;&#x441;&#x43e;&#x431;&#x435;&#x43d;&#x43d;&#x43e;&#x441;&#x442;&#x435;&#x439; &#x431;&#x435;&#x437;&#x43e;&#x43f;&#x430;&#x441;&#x43d;&#x43e;&#x441;&#x442;&#x438; &#x432; Java. &#x412;&#x430;&#x43c; &#x43d;&#x430;&#x434;&#x43e; &#x437;&#x430;&#x433;&#x440;&#x443;&#x437;&#x438;&#x442;&#x44c; Freeplane applet jar-&#x444;&#x430;&#x439;&#x43b; &#x438; &#x432;&#x430;&#x448;&#x443; &#x441;&#x445;&#x435;&#x43c;&#x443; &#x43d;&#x430; &#x432;&#x435;&#x431;-&#x441;&#x430;&#x439;&#x442;." ID="ID_731645531" CREATED="1465678964133" MODIFIED="1465678964133"/>
</node>
<node TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x430;&#x43f;&#x43f;&#x43b;&#x435;&#x442;&#x430; Freeplane" FOLDED="true" POSITION="left" ID="ID_1160552792" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x412; &#x430;&#x43f;&#x43f;&#x43b;&#x435;&#x442;&#x435; Freeplane, &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x43f;&#x440;&#x43e;&#x441;&#x43c;&#x430;&#x442;&#x440;&#x438;&#x432;&#x430;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x44b;; &#x432;&#x44b; &#x43d;&#x435; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x443;&#x434;&#x430;&#x43b;&#x435;&#x43d;&#x43d;&#x44b;&#x435; &#x441;&#x445;&#x435;&#x43c;&#x44b;. &#x41a;&#x43b;&#x438;&#x43a;&#x43d;&#x438;&#x442;&#x435; &#x43d;&#x430; &#x443;&#x437;&#x43b;&#x435; &#x447;&#x442;&#x43e;&#x431;&#x44b; &#x441;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c;/&#x440;&#x430;&#x437;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442; &#x435;&#x433;&#x43e; &#x438;&#x43b;&#x438; &#x447;&#x442;&#x43e;&#x431;&#x44b; &#x43f;&#x435;&#x440;&#x435;&#x439;&#x442;&#x438; &#x43f;&#x43e; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x435;. &#x41f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x441;&#x43a;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; &#x444;&#x43e;&#x43d; &#x447;&#x442;&#x43e;&#x431;&#x44b; &#x43f;&#x440;&#x43e;&#x43a;&#x440;&#x443;&#x447;&#x438;&#x432;&#x430;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x443;. &#x414;&#x43b;&#x44f; &#x43f;&#x43e;&#x438;&#x441;&#x43a;&#x430; &#x43f;&#x43e; &#x441;&#x445;&#x435;&#x43c;&#x435; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e;." ID="ID_1946411143" CREATED="1465678964133" MODIFIED="1465678964133">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x418;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x432; &#x438;&#x43d;&#x442;&#x435;&#x440;&#x444;&#x435;&#x439;&#x441;&#x435; &#x441; &#x432;&#x435;&#x440;&#x441;&#x438;&#x438; 0.6.5" FOLDED="true" POSITION="left" ID="ID_1196444740" CREATED="1465678964133" MODIFIED="1465678964133" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x41d;&#x435;&#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x435; &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x438; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x430;&#x442;&#x443;&#x440;&#x44b; &#x431;&#x44b;&#x43b;&#x438; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x44b; &#x442;&#x430;&#x43a;, &#x447;&#x442;&#x43e; &#x441;&#x435;&#x439;&#x447;&#x430;&#x441; &#x43c;&#x44b; &#x43f;&#x43e;&#x43b;&#x430;&#x433;&#x430;&#x435;&#x43c; &#x43e;&#x43d;&#x438; &#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x435; &#x441;&#x43e;&#x43e;&#x442;&#x432;&#x435;&#x442;&#x441;&#x442;&#x432;&#x443;&#x44e;&#x442; &#x43e;&#x431;&#x449;&#x438;&#x43c; &#x441;&#x442;&#x430;&#x43d;&#x442;&#x430;&#x440;&#x442;&#x430;&#x43c; &#x438;&#x43b;&#x438; &#x438;&#x43d;&#x442;&#x443;&#x438;&#x442;&#x438;&#x432;&#x43d;&#x43e;&#x43c;&#x443; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44e;. &#x41d;&#x435;&#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x435; &#x438;&#x437; &#x43d;&#x43e;&#x432;&#x44b;&#x445; &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x435;&#x43a; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x430;&#x442;&#x443;&#x440;&#x44b; &#x438;&#x441;&#x445;&#x43e;&#x434;&#x44f;&#x442; &#x43e;&#x442; &#x43f;&#x440;&#x43e;&#x434;&#x443;&#x43a;&#x442;&#x43e;&#x432; Microsoft. &#x41d;&#x43e;&#x432;&#x44b;&#x435; &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x438; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x448; &#x432;&#x43a;&#x43b;&#x44e;&#x447;&#x430;&#x44f; Enter &#x434;&#x43b;&#x44f; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x430;-&#x431;&#x440;&#x430;&#x442;&#x430;, insert &#x434;&#x43b;&#x44f; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x44f; &#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x43e;&#x432;, F2 &#x434;&#x43b;&#x44f; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; - &#x432;&#x43e;&#x442; &#x432;&#x43b;&#x438;&#x44f;&#x43d;&#x438;&#x435; Microsoft, &#x442;.&#x43a;. &#x43e;&#x447;&#x435;&#x432;&#x438;&#x434;&#x43d;&#x43e; &#x447;&#x442;&#x43e; &#x43d;&#x435;&#x442; &#x43d;&#x438; &#x43e;&#x434;&#x43d;&#x43e;&#x439; &#x438;&#x43d;&#x442;&#x443;&#x438;&#x442;&#x438;&#x432;&#x43d;&#x43e;&#x439; &#x43f;&#x440;&#x438;&#x447;&#x438;&#x43d;&#x44b; &#x43f;&#x43e;&#x43d;&#x438;&#x43c;&#x430;&#x442;&#x44c; &#x43f;&#x43e;&#x434; F2 &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;. &#x41d;&#x43e; &#x442;&#x430;&#x43a; &#x43a;&#x430;&#x43a; &#x432;&#x44b;, &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x435;&#x442;&#x435; &#x438;&#x445; &#x432;&#x43e; &#x43c;&#x43d;&#x43e;&#x433;&#x438;&#x445; &#x43f;&#x440;&#x438;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x44f;&#x445;, &#x432;&#x430;&#x43c; &#x432;&#x435;&#x440;&#x43e;&#x44f;&#x442;&#x43d;&#x43e; &#x442;&#x430;&#x43a; &#x436;&#x435; &#x445;&#x43e;&#x442;&#x435;&#x43b;&#x43e;&#x441;&#x44c; &#x431;&#x44b; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x438;&#x437; &#x438; &#x432; Freeplane." ID="ID_1623765602" CREATED="1465678964133" MODIFIED="1465678964133">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x41d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x438; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x430;&#x442;&#x443;&#x440;&#x44b; &#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x432; &#x43c;&#x435;&#x43d;&#x44e; &#x414;&#x43e;&#x43f;&#x43e;&#x43b;&#x43d;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x438; &gt; &#x423;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x438;." ID="ID_1159347906" CREATED="1465678964133" MODIFIED="1465678964133">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x421;&#x43e;&#x437;&#x434;&#x430;&#x442;&#x435;&#x43b;&#x438;" FOLDED="true" POSITION="left" ID="ID_186779030" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x410;&#x432;&#x442;&#x43e;&#x440;&#x44b;" FOLDED="true" ID="ID_592138982" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#006699">
<node TEXT="Joerg Mueller" FOLDED="true" ID="ID_191734295" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="ponders@t-online.de" ID="ID_682697460" CREATED="1465678964149" MODIFIED="1465678964149" LINK="mailto:ponders@t-online.de" COLOR="#558000">
<font NAME="Dialog" SIZE="10"/>
</node>
<node TEXT="&#x423;&#x43d;&#x438;&#x432;&#x435;&#x440;&#x441;&#x438;&#x442;&#x435;&#x442; &#x424;&#x440;&#x435;&#x439;&#x431;&#x443;&#x440;&#x433;&#x430;, &#x413;&#x435;&#x440;&#x43c;&#x430;&#x43d;&#x438;&#x44f;" ID="ID_1445633760" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Daniel Polansky" ID="ID_931246815" CREATED="1465678964149" MODIFIED="1465678964149" LINK="http://danpolansky.blogspot.com/" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Petr Novak" ID="ID_574118867" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Christian Foltin" ID="ID_64550512" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Dimitri Polivaev" ID="ID_1329333641" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="&#x41f;&#x43e;&#x43c;&#x43e;&#x449;&#x44c; &#x43e;&#x43a;&#x430;&#x437;&#x430;&#x43b;&#x438;" FOLDED="true" ID="ID_1076385974" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Andrew Iggleden" FOLDED="true" ID="ID_1021809876" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x423;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x449;&#x438;&#x43a; &#x434;&#x43b;&#x44f; Windows" ID="ID_1556201968" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Bob Alexander" FOLDED="true" ID="ID_1377648" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x420;&#x443;&#x43a;&#x43e;&#x432;&#x43e;&#x434;&#x441;&#x442;&#x432;&#x43e; &#x43f;&#x43e; Eclipse" ID="ID_1996924529" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="David Butt" FOLDED="true" ID="ID_583760673" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x420;&#x443;&#x43a;&#x43e;&#x432;&#x43e;&#x434;&#x441;&#x442;&#x432;&#x43e; &#x43f;&#x43e; flash" ID="ID_1034653997" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="David Low" FOLDED="true" ID="ID_318141163" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x41f;&#x43e;&#x43b;&#x435;&#x437;&#x435;&#x43d;" ID="ID_1903551591" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
</node>
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434;&#x447;&#x438;&#x43a;&#x438;" FOLDED="true" ID="ID_1263598761" CREATED="1465678964149" MODIFIED="1465678964149" LINK="http://freeplane.sourceforge.net/wiki/index.php/Translation" COLOR="#006699">
<node TEXT="Bob Alexander" FOLDED="true" ID="ID_74973369" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x438;&#x442;&#x430;&#x43b;&#x44c;&#x44f;&#x43d;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1308894171" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Knud Riish&#xf8;jg&#xe5;rd" FOLDED="true" ID="ID_1426820247" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x434;&#x430;&#x442;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1082253869" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Takeshi Kakeda" FOLDED="true" ID="ID_1590753630" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x44f;&#x43f;&#x43e;&#x43d;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1281357366" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Kohichi Aoki" FOLDED="true" ID="ID_1817608731" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x44f;&#x43f;&#x43e;&#x43d;&#x441;&#x43a;&#x438;&#x439;" ID="ID_225573155" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Alex Dukal" FOLDED="true" ID="ID_1229146173" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x438;&#x441;&#x43f;&#x430;&#x43d;&#x441;&#x43a;&#x438;&#x439;" ID="ID_57964093" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Hugo Gayosso" FOLDED="true" ID="ID_598224995" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x438;&#x441;&#x43f;&#x430;&#x43d;&#x441;&#x43a;&#x438;&#x439;" ID="ID_975856953" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Sylvain Gamel" FOLDED="true" ID="ID_1894172609" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x444;&#x440;&#x430;&#x43d;&#x446;&#x443;&#x437;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1554657147" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Koen Roggemans" FOLDED="true" ID="ID_1396793865" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x433;&#x43e;&#x43b;&#x43b;&#x430;&#x43d;&#x434;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1628924468" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Rafal Kraik" FOLDED="true" ID="ID_41440304" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x43f;&#x43e;&#x43b;&#x44c;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1421040621" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Goliath" FOLDED="true" ID="ID_249094428" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x43a;&#x43e;&#x440;&#x435;&#x439;&#x441;&#x43a;&#x438;&#x439;" ID="ID_866736192" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Martin Srebotnjak (nick: Miles a.k.a. filmsi)" FOLDED="true" ID="ID_1985027811" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x441;&#x43b;&#x43e;&#x432;&#x435;&#x43d;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1593007489" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="William Chen" FOLDED="true" ID="ID_624113098" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x43a;&#x438;&#x442;&#x430;&#x439;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1408595541" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Radek &#x160;varc" FOLDED="true" ID="ID_1524008453" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x447;&#x435;&#x448;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1046918222" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Bal&#xe1;zs M&#xe1;rton" FOLDED="true" ID="ID_875521447" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x432;&#x435;&#x43d;&#x433;&#x435;&#x440;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1446506678" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Luis Ferreira " FOLDED="true" ID="ID_1357737450" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x43f;&#x43e;&#x440;&#x442;&#x443;&#x433;&#x430;&#x43b;&#x44c;&#x441;&#x43a;&#x438;&#x439;" ID="ID_268363237" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Velesyuk Maxim" FOLDED="true" ID="ID_1329829385" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434; &#x43d;&#x430; &#x440;&#x443;&#x441;&#x441;&#x43a;&#x438;&#x439;" ID="ID_1974224831" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="&#x421;&#x43f;&#x438;&#x441;&#x43e;&#x43a; &#x43f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434;&#x447;&#x438;&#x43a;&#x43e;&#x432; &#x43c;&#x43e;&#x436;&#x435;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x43d;&#x435; &#x43f;&#x43e;&#x43b;&#x43d;&#x44b;&#x43c;. &#x415;&#x441;&#x43b;&#x438; &#x43c;&#x44b; &#x432;&#x430;&#x441; &#x437;&#x430;&#x431;&#x44b;&#x43b;&#x438;, &#x434;&#x430;&#x439;&#x442;&#x435; &#x43d;&#x430;&#x43c; &#x437;&#x43d;&#x430;&#x442;&#x44c;. &#x412;&#x441;&#x435; &#x43b;&#x44e;&#x434;&#x438; &#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x435; &#x43f;&#x43e;&#x43c;&#x43e;&#x433;&#x43b;&#x438; &#x441; &#x43f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434;&#x43e;&#x43c;, &#x434;&#x430;&#x436;&#x435; &#x43d;&#x435;&#x437;&#x430;&#x432;&#x435;&#x440;&#x448;&#x435;&#x43d;&#x43d;&#x44b;&#x43c;, &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x43f;&#x435;&#x440;&#x435;&#x447;&#x438;&#x441;&#x43b;&#x435;&#x43d;&#x44b; &#x437;&#x434;&#x435;&#x441;&#x44c;." ID="ID_200626286" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node TEXT="&#x41d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + F &#x434;&#x43b;&#x44f; &#x43f;&#x43e;&#x438;&#x441;&#x43a;&#x430;. &#x41d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + G &#x434;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x445;&#x43e;&#x434;&#x44f; &#x43a; &#x441;&#x43b;&#x435;&#x434;&#x443;&#x449;&#x435;&#x43c;&#x443; &#x440;&#x435;&#x437;&#x443;&#x43b;&#x44c;&#x442;&#x430;&#x442;&#x443;. &#x427;&#x442;&#x43e;&#x431;&#x44b; &#x43f;&#x43e;&#x438;&#x441;&#x43a; &#x431;&#x44b;&#x43b; &#x433;&#x43b;&#x43e;&#x431;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x43c;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; ESC &#x43f;&#x435;&#x440;&#x435;&#x434; &#x43d;&#x430;&#x447;&#x430;&#x43b;&#x43e;&#x43c; &#x43f;&#x43e;&#x438;&#x441;&#x43a;&#x430;." POSITION="right" ID="ID_1533479375" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#0033ff"/>
<node TEXT="&#x41d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &#x441;&#x442;&#x440;&#x435;&#x43b;&#x43a;&#x443; &quot;&#x432;&#x43f;&#x440;&#x430;&#x432;&#x43e;&quot; &#x447;&#x442;&#x43e;&#x431;&#x44b; &#x440;&#x430;&#x437;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c; &#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x438;&#x43c;&#x43e;&#x435; &#x443;&#x437;&#x43b;&#x430;." POSITION="right" ID="ID_822633213" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#0033ff"/>
<node TEXT="&#x412;&#x432;&#x435;&#x434;&#x435;&#x43d;&#x438;&#x435;" FOLDED="true" POSITION="right" ID="ID_565117848" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#407000">
<node TEXT="Freeplane &#x43f;&#x440;&#x435;&#x434;&#x43d;&#x430;&#x437;&#x43d;&#x430;&#x447;&#x435;&#x43d;&#x430; &#x434;&#x43b;&#x44f; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x44f; &#x442;&#x430;&#x43a; &#x43d;&#x430;&#x437;&#x44b;&#x432;&#x430;&#x435;&#x43c;&#x44b;&#x445; &quot;&#x441;&#x445;&#x435;&#x43c; &#x43c;&#x44b;&#x448;&#x43b;&#x435;&#x43d;&#x438;&#x44f;&quot;. &#x423;&#x436;&#x435; &#x43c;&#x43d;&#x43e;&#x433;&#x438;&#x435; &#x43b;&#x44e;&#x434;&#x438; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x44e;&#x442; &#x438;&#x445; &#x432;&#x43c;&#x435;&#x441;&#x442;&#x43e; &#x437;&#x430;&#x43f;&#x438;&#x441;&#x43d;&#x44b;&#x445; &#x43a;&#x43d;&#x438;&#x436;&#x435;&#x43a; &#x438;&#x43b;&#x438; &#x43f;&#x435;&#x440;&#x441;&#x43e;&#x43d;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x445; &#x43e;&#x440;&#x433;&#x430;&#x43d;&#x430;&#x439;&#x437;&#x435;&#x440;&#x43e;&#x432;." ID="ID_1572650709" CREATED="1465678964149" MODIFIED="1465678964149"/>
<node TEXT="&#x418;&#x43d;&#x444;&#x43e;&#x440;&#x43c;&#x430;&#x446;&#x438;&#x44f; &#x445;&#x440;&#x430;&#x43d;&#x438;&#x442;&#x441;&#x44f; &#x432; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x43e;&#x432;&#x44b;&#x445; &#x43f;&#x43e;&#x43b;&#x44f;&#x445;, &#x43d;&#x430;&#x437;&#x44b;&#x432;&#x430;&#x435;&#x43c;&#x44b;&#x445; &#x443;&#x437;&#x43b;&#x430;&#x43c;&#x438;. &#x423;&#x437;&#x43b;&#x44b; &#x441;&#x43e;&#x435;&#x434;&#x438;&#x43d;&#x435;&#x43d;&#x44b; &#x432;&#x43c;&#x435;&#x441;&#x442;&#x435; &#x441; &#x43f;&#x43e;&#x43c;&#x43e;&#x449;&#x44c;&#x44e; &#x43a;&#x440;&#x438;&#x432;&#x44b;&#x445; &#x43b;&#x438;&#x43d;&#x438;&#x439; (&#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x438; &#x43f;&#x440;&#x44f;&#x43c;&#x44b;&#x445;, &#x43f;&#x43e;&#x441;&#x43c;&#x43e;&#x442;&#x440;&#x438;&#x442;&#x435; &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x438;), &#x43d;&#x430;&#x437;&#x44b;&#x432;&#x430;&#x435;&#x43c;&#x44b;&#x445; &#x434;&#x443;&#x433;&#x430;&#x43c;&#x438;." ID="ID_1530983402" CREATED="1465678964149" MODIFIED="1465678964149"/>
<node TEXT="&#x42d;&#x442;&#x43e; &#x441;&#x43f;&#x440;&#x430;&#x432;&#x43e;&#x447;&#x43d;&#x438;&#x43a; &#x43f;&#x43e; Freeplane 0.8.0. &#x41d;&#x430;&#x437;&#x43d;&#x430;&#x447;&#x435;&#x43d;&#x438;&#x44f; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x448; &#x438; &#x440;&#x430;&#x441;&#x43f;&#x43e;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x435; &#x43f;&#x443;&#x43d;&#x43a;&#x442;&#x43e;&#x432; &#x43c;&#x435;&#x43d;&#x44e; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x44f;&#x442;&#x44c;&#x441;&#x44f; &#x43e;&#x442; &#x432;&#x435;&#x440;&#x441;&#x438;&#x438; &#x43a; &#x432;&#x435;&#x440;&#x441;&#x438;&#x438;." ID="ID_1075027932" CREATED="1465678964149" MODIFIED="1465678964149"/>
</node>
<node TEXT="&#x414;&#x435;&#x43c;&#x43e;&#x43d;&#x441;&#x442;&#x440;&#x430;&#x446;&#x438;&#x44f; &#x43d;&#x435;&#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x445; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e;&#x441;&#x442;&#x435;&#x439;" FOLDED="true" POSITION="right" ID="ID_797653954" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x412;&#x43d;&#x435;&#x448;&#x43d;&#x438;&#x439; &#x432;&#x438;&#x434;" FOLDED="true" ID="ID_878028367" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x423;&#x437;&#x43b;&#x44b; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x438;&#x43c;&#x435;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43d;&#x44b;&#x435; &#x446;&#x432;&#x435;&#x442;&#x430;." FOLDED="true" ID="ID_142747307" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x41a;&#x440;&#x430;&#x441;&#x43d;&#x44b;&#x439;" ID="ID_947758984" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#ff0000">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x417;&#x435;&#x43b;&#x435;&#x43d;&#x44b;&#x439;" ID="ID_1304440660" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#009900">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x421;&#x438;&#x43d;&#x438;&#x439;" ID="ID_458532999" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#0000cc">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x423; &#x443;&#x437;&#x43b;&#x43e;&#x432; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43d;&#x44b;&#x435; &#x446;&#x432;&#x435;&#x442;&#x430; &#x444;&#x43e;&#x43d;&#x430;" FOLDED="true" ID="ID_51885885" CREATED="1465678964149" MODIFIED="1465678964149">
<node TEXT="&#x422;&#x430;&#x43a;&#x43e;&#x439;" ID="ID_1040587569" CREATED="1465678964149" MODIFIED="1465678964149"/>
<node TEXT="&#x412;&#x43e;&#x442; &#x442;&#x430;&#x43a;&#x43e;&#x439;" ID="ID_1663216640" CREATED="1465678964149" MODIFIED="1465678964149"/>
</node>
<node TEXT="&#x423;&#x437;&#x43b;&#x44b; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x43e;&#x442;&#x43b;&#x438;&#x447;&#x430;&#x442;&#x44c;&#x441;&#x44f; &#x441;&#x442;&#x438;&#x43b;&#x44f;&#x43c;&#x438; &#x448;&#x440;&#x438;&#x444;&#x442;&#x43e;&#x432;" FOLDED="true" ID="ID_251080604" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x416;&#x438;&#x440;&#x43d;&#x44b;&#x439;" ID="ID_512111878" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="Dialog" SIZE="12" BOLD="true"/>
</node>
<node TEXT="&#x41a;&#x443;&#x440;&#x441;&#x438;&#x432;" ID="ID_659954543" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="Dialog" SIZE="12" ITALIC="true"/>
</node>
<node TEXT="&#x416;&#x438;&#x440;&#x43d;&#x44b;&#x439; &#x43a;&#x443;&#x440;&#x441;&#x438;&#x432;" ID="ID_537510898" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="Dialog" SIZE="12" BOLD="true" ITALIC="true"/>
</node>
</node>
<node TEXT="&#x428;&#x440;&#x438;&#x444;&#x442; &#x43c;&#x43e;&#x436;&#x435;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43d;&#x43e;&#x433;&#x43e; &#x440;&#x430;&#x437;&#x43c;&#x435;&#x440;&#x430;" FOLDED="true" ID="ID_1887705642" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x43c;&#x430;&#x43b;&#x435;&#x43d;&#x44c;&#x43a;&#x438;&#x439;" ID="ID_1085295878" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node TEXT="&#x441;&#x440;&#x435;&#x434;&#x43d;&#x438;&#x439;" ID="ID_1634593741" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node TEXT="&#x43f;&#x43e;-&#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x435;" ID="ID_1148570263" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node TEXT="&#x41e;&#x433;&#x440;&#x43e;&#x43c;&#x43d;&#x44b;&#x439;" FOLDED="true" ID="ID_1476494429" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="20"/>
<node TEXT="&#x423;&#x423;&#x425;" ID="ID_797802649" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node TEXT="&#x41c;&#x43e;&#x433;&#x443;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x44b; &#x440;&#x430;&#x437;&#x440;&#x44b;&#x435; &#x448;&#x440;&#x438;&#x444;&#x442;&#x44b;" FOLDED="true" ID="ID_1381044882" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x422;&#x430;&#x43a;&#x43e;&#x439;" ID="ID_345560502" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node TEXT="&#x418;&#x43b;&#x438; &#x442;&#x430;&#x43a;&#x43e;&#x439;" ID="ID_9575699" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="Verdana" SIZE="12"/>
</node>
<node TEXT="&#x418;&#x43b;&#x438; &#x432;&#x43e;&#x442; &#x442;&#x430;&#x43a;&#x43e;&#x439;" ID="ID_658912339" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node TEXT="&#x423;&#x437;&#x43b;&#x44b; &#x43c;&#x43e;&#x433;&#x443; &#x431;&#x44b;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43d;&#x43e;&#x433;&#x43e; &#x441;&#x442;&#x438;&#x43b;&#x44f;" FOLDED="true" ID="ID_155712561" CREATED="1465678964149" MODIFIED="1465678964149">
<node TEXT="&quot;&#x412;&#x435;&#x442;&#x43a;&#x430;&quot;" FOLDED="true" ID="ID_962116603" CREATED="1465678964149" MODIFIED="1465678964149">
<node TEXT="&quot;&#x412;&#x435;&#x442;&#x43a;&#x430;&quot;" ID="ID_1981691324" CREATED="1465678964149" MODIFIED="1465678964149"/>
<node TEXT="&quot;&#x412;&#x435;&#x442;&#x43a;&#x430;&quot;" ID="ID_1297774585" CREATED="1465678964149" MODIFIED="1465678964149"/>
</node>
<node TEXT="&quot;&#x41f;&#x443;&#x437;&#x44b;&#x440;&#x44c;&quot;" FOLDED="true" ID="ID_1442484182" CREATED="1465678964149" MODIFIED="1465678964149" STYLE="bubble">
<node TEXT="&quot;&#x41f;&#x443;&#x437;&#x44b;&#x440;&#x44c;&quot;" ID="ID_788999464" CREATED="1465678964149" MODIFIED="1465678964149" STYLE="bubble"/>
<node TEXT="&quot;&#x41f;&#x443;&#x437;&#x44b;&#x440;&#x44c;&quot;" ID="ID_58813534" CREATED="1465678964149" MODIFIED="1465678964149" STYLE="bubble"/>
</node>
</node>
</node>
<node TEXT="&#x423;&#x437;&#x43b;&#x44b; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x432;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x43d;&#x44b;&#x43c;&#x438;" FOLDED="true" ID="ID_1222705677" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x427;&#x442;&#x43e;-&#x442;&#x43e; &#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x438;&#x442;" FOLDED="true" ID="ID_866561939" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x421;&#x43f;&#x440;&#x44f;&#x442;&#x430;&#x43d;&#x43d;&#x44b;&#x439; &#x443;&#x437;&#x435;&#x43b;" ID="ID_1655212493" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x414;&#x435;&#x440;&#x435;&#x432;&#x43e;" FOLDED="true" ID="ID_340206501" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x443;&#x431;" ID="ID_1156377123" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x411;&#x443;&#x43a;" ID="ID_870580641" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x412;&#x44f;&#x437;" ID="ID_1442645176" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="&#x423;&#x437;&#x43b;&#x44b; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x430;&#x442;&#x44c; &#x434;&#x435;&#x439;&#x441;&#x442;&#x432;&#x443;&#x44e;&#x449;&#x438;&#x435; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x43d;&#x430; ...&#xa0;" FOLDED="true" ID="ID_1250257488" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x412;&#x435;&#x431;-&#x441;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;&#x44b;" FOLDED="true" ID="ID_1354030307" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="http://www.google.com/" ID="ID_1965338046" CREATED="1465678964149" MODIFIED="1465678964149" LINK="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="www.google.com" FOLDED="true" ID="ID_1768670319" CREATED="1465678964149" MODIFIED="1465678964149" LINK="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Freeplane &#x434;&#x443;&#x43c;&#x430;&#x435;&#x442; &#x447;&#x442;&#x43e; &#x44d;&#x442;&#x43e; &#x432;&#x44b;&#x43f;&#x43e;&#x43b;&#x43d;&#x44f;&#x435;&#x43c;&#x430;&#x44f; &#x43f;&#x440;&#x43e;&#x433;&#x440;&#x430;&#x43c;&#x43c;&#x430; :)" ID="ID_1619837232" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node TEXT="&#x41b;&#x43e;&#x43a;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x435; &#x434;&#x438;&#x440;&#x435;&#x43a;&#x442;&#x43e;&#x440;&#x438;&#x438;" FOLDED="true" ID="ID_1812632757" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:/Program Files/" ID="ID_1890875794" CREATED="1465678964149" MODIFIED="1465678964149" LINK="file:/C:/Program%20Files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="/home/" ID="ID_1803158758" CREATED="1465678964149" MODIFIED="1465678964149" LINK="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x43d;&#x44f;&#x435;&#x43c;&#x44b;&#x435; &#x444;&#x430;&#x439;&#x43b;&#x44b;" FOLDED="true" ID="ID_711365469" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:\WINNT\regedit.exe" FOLDED="true" ID="ID_1950937865" CREATED="1465678964149" MODIFIED="1465678964149" LINK="file:/C:/WINNT/regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x412;&#x44b; &#x432;&#x438;&#x434;&#x438;&#x442;&#x435;, &#x447;&#x442;&#x43e; &#x443;&#x437;&#x435;&#x43b; &#x437;&#x430;&#x43f;&#x443;&#x441;&#x43a;&#x430;&#x435;&#x442;&#x441;&#x44f; &#x43f;&#x43e; &#x438;&#x43a;&#x43e;&#x43d;&#x43a;&#x435;." ID="ID_1124731187" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#006600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="&#x41b;&#x44e;&#x431;&#x43e;&#x439; &#x434;&#x43e;&#x43a;&#x443;&#x43c;&#x435;&#x43d;&#x442; &#x43d;&#x430; &#x432;&#x430;&#x448;&#x435;&#x43c; &#x43a;&#x43e;&#x43c;&#x43f;&#x44c;&#x44e;&#x442;&#x435;&#x440;&#x435; &#x438;&#x43b;&#x438; &#x432; &#x432;&#x430;&#x448;&#x435;&#x439; &#x441;&#x435;&#x442;&#x438;" ID="ID_389044953" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x41c;&#x43d;&#x43e;&#x433;&#x43e;&#x441;&#x442;&#x440;&#x43e;&#x447;&#x43d;&#x44b;&#x435; &#x443;&#x437;&#x43b;&#x44b;" FOLDED="true" ID="ID_74301321" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x41c;&#x43d;&#x43e;&#x433;&#x43e;&#x441;&#x442;&#x440;&#x43e;&#x447;&#x43d;&#x44b;&#x435; &#x443;&#x437;&#x43b;&#x44b; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x441;&#x43e;&#x441;&#x442;&#x43e;&#x44f;&#x442;&#x44c; &#x43a;&#x430;&#x43a; &#x438;&#x437; &#x43e;&#x434;&#x43d;&#x43e;&#x433;&#x43e; &#x43f;&#x430;&#x440;&#x430;&#x433;&#x440;&#x430;&#x444;&#x430;, &#x442;&#x430;&#x43a; &#x438;&#x437; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x438;&#x445;. &#x415;&#x441;&#x43b;&#x438; &#x432;&#x44b; &#x441;&#x43e;&#x431;&#x438;&#x440;&#x430;&#x435;&#x442;&#x435;&#x441;&#x44c; &#x441;&#x442;&#x440;&#x43e;&#x438;&#x442;&#x44c; &#x431;&#x430;&#x437;&#x443; &#x437;&#x43d;&#x430;&#x43d;&#x438;&#x439; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x44f; Freeplane, &#x432;&#x430;&#x43c; &#x43d;&#x435;&#x437;&#x430;&#x447;&#x435;&#x43c; &#x438;&#x437;&#x431;&#x435;&#x433;&#x430;&#x442;&#x44c; &#x438;&#x445; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;. &#x412;&#x43c;&#x435;&#x441;&#x442;&#x43e; &#x442;&#x43e;&#x433;&#x43e;, &#x447;&#x442;&#x43e;&#x431;&#x44b; &#x434;&#x435;&#x43b;&#x430;&#x442;&#x44c; &#x437;&#x430;&#x43f;&#x438;&#x441;&#x438; &#x432; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x43e;&#x43c; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x43e;&#x432;&#x43e;&#x43c; &#x444;&#x430;&#x439;&#x43b;&#x435;, &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x441;&#x434;&#x435;&#x43b;&#x430;&#x442;&#x44c; &#x43e;&#x434;&#x438;&#x43d; &#x43d;&#x435;&#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x43e;&#x439; &#x443;&#x437;&#x435;&#x43b; &#x441; &#x43c;&#x43d;&#x43e;&#x436;&#x435;&#x441;&#x442;&#x432;&#x43e;&#x43c; &#x43c;&#x43d;&#x43e;&#x433;&#x43e;&#x441;&#x442;&#x440;&#x43e;&#x447;&#x43d;&#x44b;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;-&#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x43e;&#x432;." ID="ID_611608004" CREATED="1465678964149" MODIFIED="1465678964149"/>
<node TEXT="&quot;&#x41d;&#x430;&#x443;&#x43a;&#x430; - &#x44d;&#x442;&#x43e; &#x444;&#x430;&#x43a;&#x442;&#x44b;; &#x43a;&#x430;&#x43a; &#x434;&#x43e;&#x43c;&#x430; &#x441;&#x434;&#x435;&#x43b;&#x430;&#x43d;&#x44b; &#x438;&#x437; &#x43a;&#x430;&#x43c;&#x43d;&#x44f;, &#x442;&#x430;&#x43a; &#x438; &#x43d;&#x430;&#x443;&#x43a;&#x430; &#x441;&#x43e;&#x441;&#x442;&#x43e;&#x438;&#x442; &#x438;&#x437; &#x444;&#x430;&#x43a;&#x442;&#x43e;&#x432;; &#x43d;&#x43e; &#x43a;&#x443;&#x447;&#x430; &#x43a;&#x430;&#x43c;&#x43d;&#x435;&#x439; &#x44d;&#x442;&#x43e; &#x43d;&#x435; &#x434;&#x43e;&#x43c; &#x438; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x43e; &#x441;&#x43e;&#x431;&#x440;&#x430;&#x43d;&#x438;&#x435; &#x444;&#x430;&#x43a;&#x442;&#x43e;&#x432; &#x43d;&#x435;&#x43b;&#x44c;&#x437;&#x44f; &#x441;&#x447;&#x438;&#x442;&#x430;&#x442;&#x44c; &#x43d;&#x430;&#x443;&#x43a;&#x43e;&#x439;.&quot; --Henri Poincar&#xe9;" ID="ID_1984598732" CREATED="1465678964149" MODIFIED="1465678964149"/>
</node>
<node TEXT="&#x420;&#x430;&#x437;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x435; &#x43c;&#x43d;&#x43e;&#x433;&#x43e;&#x441;&#x442;&#x440;&#x43e;&#x447;&#x43d;&#x44b;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432; &#x43f;&#x443;&#x441;&#x442;&#x44b;&#x43c;&#x438; &#x43b;&#x438;&#x43d;&#x438;&#x44f;&#x43c;&#x438;" FOLDED="true" ID="ID_1279514682" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#669900">
<node TEXT="&#x41b;&#x438;&#x43d;&#x438;&#x44f;,&#xa;&#x438; &#x432;&#x442;&#x43e;&#x440;&#x430;&#x44f;,&#xa;&#xa;&#x438; &#x435;&#x449;&#x435; &#x43e;&#x434;&#x43d;&#x430;,&#xa;&#x43a;&#x430;&#x43a; &#x432;&#x430;&#x43c; &#x44d;&#x442;&#x43e;?" ID="ID_1131351096" CREATED="1465678964149" MODIFIED="1465678964149"/>
</node>
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x44d;&#x43c;&#x443;&#x43b;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x43f;&#x43e;&#x434;&#x43f;&#x438;&#x441;&#x430;&#x43d;&#x43d;&#x44b;&#x435; &#x434;&#x443;&#x433;&#x438;" FOLDED="true" ID="ID_857490845" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#669900">
<node TEXT="&#x414;&#x435;&#x440;&#x435;&#x432;&#x43e;" FOLDED="true" ID="ID_566051439" CREATED="1465678964149" MODIFIED="1465678964149">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x44d;&#x442;&#x43e;" FOLDED="true" ID="ID_755557940" CREATED="1465678964149" MODIFIED="1465678964149" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="&#x414;&#x443;&#x431;" ID="ID_89728045" CREATED="1465678964164" MODIFIED="1465678964164">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x44d;&#x442;&#x43e;" FOLDED="true" ID="ID_458943742" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="&#x411;&#x443;&#x43a;" ID="ID_1190047507" CREATED="1465678964164" MODIFIED="1465678964164">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x44d;&#x442;&#x43e;" FOLDED="true" ID="ID_740778021" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="&#x412;&#x44f;&#x437;" ID="ID_225697908" CREATED="1465678964164" MODIFIED="1465678964164">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="&#x414;&#x435;&#x440;&#x435;&#x432;&#x43e;" FOLDED="true" ID="ID_1639187600" CREATED="1465678964164" MODIFIED="1465678964164">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;&gt;" FOLDED="true" ID="ID_267347715" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="&#x41b;&#x438;&#x441;&#x442;" ID="ID_1597114265" CREATED="1465678964164" MODIFIED="1465678964164">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&lt;&gt;" FOLDED="true" ID="ID_582690594" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="&#x422;&#x440;&#x443;&#x431;&#x430;" ID="ID_1351577062" CREATED="1465678964164" MODIFIED="1465678964164">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="&#x412; &#x443;&#x437;&#x43b;&#x430;&#x445; &#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x43c;&#x43d;&#x43e;&#x436;&#x435;&#x441;&#x442;&#x432;&#x43e; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a;" ID="ID_660182604" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#669900">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node TEXT="&#x410; &#x442;&#x430;&#x43a; &#x436;&#x435; &#x43e;&#x431;&#x43b;&#x430;&#x43a;&#x430;" FOLDED="true" ID="ID_515844599" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<cloud COLOR="#f0f0f0" SHAPE="ARC"/>
<node TEXT="&#x41b;&#x44e;&#x431;&#x44b;&#x445; &#x446;&#x432;&#x435;&#x442;&#x43e;&#x432;" ID="ID_668076102" CREATED="1465678964164" MODIFIED="1465678964164">
<cloud COLOR="#f1ede6" SHAPE="ARC"/>
</node>
</node>
<node TEXT="&#x41c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x43f;&#x43e;&#x43a;&#x430;&#x437;&#x44b;&#x432;&#x430;&#x442;&#x44c; &#x441;&#x432;&#x44f;&#x437;&#x438; &#x433;&#x440;&#x430;&#x444;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438;" FOLDED="true" ID="ID_595215025" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<node TEXT="&#x421;&#x43e;&#x435;&#x434;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;" ID="ID_244990711" CREATED="1465678964164" MODIFIED="1465678964164">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1249400461" STARTINCLINATION="41;0;" ENDINCLINATION="41;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="&#x421; &#x434;&#x440;&#x443;&#x433;&#x438;&#x43c;" ID="_Freeplane_Link_1249400461" CREATED="1465678964164" MODIFIED="1465678964164">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#6600ff" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_880551392" STARTINCLINATION="47;0;" ENDINCLINATION="47;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="&#x414;&#x440;&#x443;&#x433;&#x43e;&#x433;&#x43e; &#x446;&#x432;&#x435;&#x442;&#x430;" ID="_Freeplane_Link_880551392" CREATED="1465678964164" MODIFIED="1465678964164">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1789233193" STARTINCLINATION="82;44;" ENDINCLINATION="82;44;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="&#x414;&#x440;&#x443;&#x433;&#x438;&#x43c; &#x43f;&#x43e;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x435;&#x43c;" ID="_Freeplane_Link_1789233193" CREATED="1465678964164" MODIFIED="1465678964164"/>
</node>
<node TEXT="&#x423;&#x437;&#x43b;&#x44b; &#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x440;&#x430;&#x441;&#x43f;&#x43e;&#x43b;&#x430;&#x433;&#x430;&#x442;&#x44c; &#x441;&#x432;&#x43e;&#x431;&#x43e;&#x434;&#x43d;&#x43e;" FOLDED="true" ID="ID_835070669" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<node TEXT="&#x41e;&#x434;&#x438;&#x43d;" ID="ID_670210287" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x440;&#x443;&#x433;&#x43e;&#x439;" ID="ID_1915318259" CREATED="1465678964164" MODIFIED="1465678964164"/>
</node>
</node>
<node TEXT="&#x421;&#x43e;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x435; &#x438; &#x443;&#x434;&#x430;&#x43b;&#x435;&#x43d;&#x438;&#x439; &#x443;&#x437;&#x43b;&#x43e;&#x432;" FOLDED="true" POSITION="right" ID="ID_880902071" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;-&#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43e;&#x43a;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Insert." ID="ID_1015547225" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x442;&#x44c; &#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x430;, &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x443;&#x44f; &#x443;&#x437;&#x435;&#x43b;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Insert &#x432; &#x43f;&#x440;&#x43e;&#x446;&#x435;&#x441;&#x441;&#x435; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;." ID="ID_1000828002" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;-&#x431;&#x440;&#x430;&#x442; &#x43d;&#x438;&#x436;&#x435;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Enter." ID="ID_700571709" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;-&#x431;&#x440;&#x430;&#x442; &#x432;&#x44b;&#x448;&#x435;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Shift + Enter." ID="ID_1348920854" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x443;&#x434;&#x430;&#x43b;&#x438;&#x442;&#x44c; &#x443;&#x437;&#x435;&#x43b;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; delete." ID="ID_467521223" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &quot;&#x432;&#x44b;&#x440;&#x435;&#x437;&#x430;&#x442;&#x44c;&quot; &#x443;&#x437;&#x435;&#x43b; &#x441; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e;&#x441;&#x442;&#x44c;&#x44e; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x438;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Control + X." ID="ID_530242960" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x418;&#x43b;&#x438; &#x436;&#x435; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e;, &#x43a;&#x43b;&#x438;&#x43a;&#x430;&#x44f; &#x43f;&#x440;&#x430;&#x432;&#x43e;&#x439; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x43e;&#x439; &#x43c;&#x44b;&#x448;&#x438; &#x43d;&#x430; &#x443;&#x437;&#x43b;&#x435;." ID="ID_550117916" CREATED="1465678964164" MODIFIED="1465678964164"/>
</node>
<node TEXT="&#x420;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x430; &#x443;&#x437;&#x43b;&#x430;" FOLDED="true" POSITION="right" ID="ID_1398326501" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; F2, HOME &#x438;&#x43b;&#x438; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x443; END, &#x438;&#x43b;&#x438; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e; &#x420;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c;. &#x414;&#x43b;&#x44f; &#x437;&#x430;&#x432;&#x435;&#x440;&#x448;&#x435;&#x43d;&#x438;&#x44f; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; ENTER." ID="_Freeplane_Link_519923426" CREATED="1465678964164" MODIFIED="1465678964164">
<arrowlink SHAPE="LINE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_519923426" STARTINCLINATION="0;0;" ENDINCLINATION="0;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x437;&#x430;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x442;&#x435;&#x43a;&#x441;&#x442; &#x432; &#x443;&#x437;&#x43b;&#x435; &#x43d;&#x43e;&#x432;&#x44b;&#x43c;, &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x43e; &#x43d;&#x430;&#x447;&#x43d;&#x438;&#x442;&#x435; &#x43f;&#x435;&#x447;&#x430;&#x442;&#x430;&#x442;&#x44c;." ID="ID_915102592" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x44b;&#x437;&#x43e;&#x432;&#x430; &#x43f;&#x43e;&#x43b;&#x43d;&#x43e;&#x446;&#x435;&#x43d;&#x43d;&#x43e;&#x433;&#x43e; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt + Enter." ID="ID_307256306" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x440;&#x430;&#x437;&#x434;&#x435;&#x43b;&#x438;&#x442;&#x44c; &#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x43e;&#x439; &#x443;&#x437;&#x435;&#x43b;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x443; &#x420;&#x430;&#x437;&#x434;&#x435;&#x43b;&#x438;&#x442;&#x44c; &#x432; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;&#x435;, &#x438;&#x43b;&#x438; &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt + S &#x442;&#x430;&#x43a; &#x436;&#x435; &#x432; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;&#x435;." ID="ID_596321956" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x432;&#x43e;&#x434;&#x430; &#x441;&#x442;&#x440;&#x43e;&#x43a;&#x438; &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Control + Enter &#x432; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;&#x435;. &#x421;&#x442;&#x440;&#x43e;&#x43a;&#x443; &#x43d;&#x435;&#x43b;&#x44c;&#x437;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x432;&#x435;&#x441;&#x442;&#x438; &#x432; &#x43e;&#x431;&#x44b;&#x447;&#x43d;&#x43e;&#x43c; &#x440;&#x435;&#x436;&#x438;&#x43c;&#x435; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;." ID="ID_134747969" CREATED="1465678964164" MODIFIED="1465678964164">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1445647544" STARTINCLINATION="118;0;" ENDINCLINATION="118;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;, &#x43a;&#x430;&#x43a; &#x432;&#x441;&#x435;&#x433;&#x434;&#x430;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43f;&#x440;&#x430;&#x432;&#x443;&#x44e; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x443; &#x43c;&#x44b;&#x448;&#x438; &#x438; &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x41a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c;." ID="ID_513177124" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x438; &#x441;&#x43f;&#x435;&#x446;-&#x441;&#x438;&#x43c;&#x432;&#x43e;&#x43b;&#x43e;&#x432; &#x442;&#x438;&#x43f;&#x430; &#xa9;, &#x432;&#x432;&#x435;&#x434;&#x438;&#x442;&#x435; &#x438;&#x445; &#x432; &#x441;&#x432;&#x43e;&#x435;&#x43c; &#x43b;&#x44e;&#x431;&#x438;&#x43c;&#x43e;&#x43c; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x43e;&#x432;&#x43e;&#x43c; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;&#x435;, &#x43d;&#x430;&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440; Emacs, &#x430; &#x437;&#x430;&#x442;&#x435;&#x43c; &#x441;&#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x443;&#x439;&#x442;&#x435; &#x432; Freeplane." ID="ID_1093241795" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x41f;&#x43e;-&#x443;&#x43c;&#x43e;&#x43b;&#x447;&#x430;&#x43d;&#x438;&#x44e;, Enter &#x437;&#x430;&#x43a;&#x430;&#x43d;&#x447;&#x438;&#x432;&#x430;&#x435;&#x442; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x432; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;&#x435;, &#x438; Control + Enter &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x435;&#x442; &#x43d;&#x43e;&#x432;&#x44b;&#x435; &#x441;&#x442;&#x440;&#x43e;&#x43a;&#x438;. &#x415;&#x441;&#x43b;&#x438; &#x443;&#x431;&#x440;&#x430;&#x442;&#x44c; &#x432;&#x43b;&#x430;&#x436;&#x43e;&#x43a; &quot;Enter confirms&quot; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c; &#x432;&#x44b;&#x448;&#x435;&#x443;&#x43f;&#x43e;&#x43c;&#x44f;&#x43d;&#x443;&#x442;&#x44b;&#x435; &#x434;&#x435;&#x439;&#x441;&#x442;&#x432;&#x438;&#x44f;, &#x442;.&#x435;. ENTER &#x432;&#x432;&#x43e;&#x434;&#x438;&#x442; &#x43d;&#x43e;&#x432;&#x443;&#x44e; &#x43b;&#x438;&#x43d;&#x438;&#x44e;, &#x430; CONTROL ENTER &#x437;&#x430;&#x432;&#x435;&#x440;&#x448;&#x430;&#x435;&#x442; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;. &#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x432;&#x43e;&#x441;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x438;&#x442;&#x44c; &#x437;&#x43d;&#x430;&#x447;&#x435;&#x43d;&#x438;&#x435; &#x43f;&#x43e;-&#x443;&#x43c;&#x43e;&#x43b;&#x447;&#x430;&#x43d;&#x438;&#x44e; &#x432; &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x430;&#x445;. &#x41a;&#x440;&#x43e;&#x43c;&#x435; &#x442;&#x43e;&#x433;&#x43e;, &#x437;&#x43d;&#x430;&#x447;&#x435;&#x43d;&#x438;&#x435; &#x441;&#x43e;&#x445;&#x440;&#x430;&#x43d;&#x44f;&#x435;&#x442;&#x441;&#x44f; &#x432; &#x441;&#x435;&#x430;&#x43d;&#x441;&#x435; Freeplane." ID="_Freeplane_Link_1445647544" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="Freeplane &#x43f;&#x43e;&#x43b;&#x43d;&#x43e;&#x441;&#x442;&#x44c;&#x44e; &#x43f;&#x43e;&#x434;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x435;&#x442; &#x44e;&#x43d;&#x438;&#x43a;&#x43e;&#x434;. &#x422;&#x430;&#x43a; &#x447;&#x442;&#x43e; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x43b;&#x44e;&#x431;&#x44b;&#x435; &#x441;&#x43a;&#x440;&#x438;&#x43f;&#x442;&#x44b;, &#x43a;&#x430;&#x43a;&#x438;&#x435; &#x437;&#x430;&#x445;&#x43e;&#x442;&#x438;&#x442;&#x435;." ID="ID_1698217857" CREATED="1465678964164" MODIFIED="1465678964164"/>
</node>
<node TEXT="&#x424;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x443;&#x437;&#x43b;&#x430;" FOLDED="true" POSITION="right" ID="ID_1147184903" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x430; &#x436;&#x438;&#x440;&#x43d;&#x44b;&#x43c;&#x438;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + B." ID="ID_1182930087" CREATED="1465678964164" MODIFIED="1465678964164">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x43a;&#x443;&#x440;&#x438;&#x432;&#x43e;&#x43c;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + I." ID="ID_564454585" CREATED="1465678964164" MODIFIED="1465678964164">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12" ITALIC="false"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x446;&#x432;&#x435;&#x442;&#x430; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt + C." ID="ID_906883481" CREATED="1465678964164" MODIFIED="1465678964164">
<icon BUILTIN="help"/>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x446;&#x432;&#x435;&#x442;&#x430; &#x444;&#x43e;&#x43d;&#x430;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e; &#x424;&#x43e;&#x440;&#x43c;&#x430;&#x442; &gt; &#x424;&#x43e;&#x43d;&#x43e;&#x432;&#x439; &#x446;&#x432;&#x435;&#x442; &#x443;&#x437;&#x43b;&#x430;." ID="ID_1107657877" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x432;&#x435;&#x43b;&#x438;&#x447;&#x435;&#x43d;&#x438;&#x44f; &#x440;&#x430;&#x437;&#x43c;&#x435;&#x440;&#x430; &#x443;&#x437;&#x43b;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Control + &#x43f;&#x43b;&#x44e;&#x441; (&#x43d;&#x435; &#x442;&#x43e;&#x442; &#x43f;&#x43b;&#x44e;&#x441; &#x447;&#x442;&#x43e; &#x43d;&#x430; &#x446;&#x438;&#x444;&#x440;&#x43e;&#x432;&#x43e;&#x439; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x430;&#x442;&#x443;&#x440;&#x435;)." ID="ID_1875572251" CREATED="1465678964164" MODIFIED="1465678964164">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x43c;&#x435;&#x43d;&#x44c;&#x448;&#x435;&#x43d;&#x438;&#x44f; &#x440;&#x430;&#x437;&#x43c;&#x435;&#x440;&#x430; &#x443;&#x437;&#x43b;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Control + &#x43c;&#x438;&#x43d;&#x443;&#x441; (&#x43d;&#x435; &#x43c;&#x438;&#x43d;&#x443;&#x441; &#x446;&#x438;&#x444;&#x440;&#x43e;&#x432;&#x43e;&#x439; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x430;&#x442;&#x443;&#x440;&#x44b;)." ID="ID_1713485846" CREATED="1465678964164" MODIFIED="1465678964164">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x442;&#x438;&#x43f;&#x430; &#x448;&#x440;&#x438;&#x444;&#x442;&#x430;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x441;&#x43f;&#x438;&#x441;&#x43e;&#x43a; &#x432; &#x433;&#x43b;&#x430;&#x432;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e;." ID="ID_265595097" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x430; &#x443;&#x437;&#x43b;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt + C" ID="ID_1551502912" CREATED="1465678964164" MODIFIED="1465678964164">
<icon BUILTIN="help"/>
<font NAME="Aharoni" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt + V." ID="ID_51785204" CREATED="1465678964164" MODIFIED="1465678964164">
<icon BUILTIN="help"/>
<font NAME="Aharoni" SIZE="12"/>
</node>
</node>
<node TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x443;&#x432;&#x435;&#x434;&#x43e;&#x43c;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x445; &#x441;&#x442;&#x438;&#x43b;&#x435;&#x439;" FOLDED="true" POSITION="right" ID="ID_1239157901" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x442;&#x430;&#x43a;&#x43e;&#x433;&#x43e; &#x441;&#x442;&#x438;&#x43b;&#x44f;, &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x421;&#x442;&#x438;&#x43b;&#x44c; &gt; &#x421;&#x442;&#x438;&#x43b;&#x44c; &#x43d;&#x430; &#x432;&#x430;&#x448; &#x432;&#x44b;&#x431;&#x43e;&#x440;. &#x414;&#x43b;&#x44f; &#x443;&#x441;&#x43a;&#x43e;&#x440;&#x435;&#x43d;&#x438;&#x44f; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x441;&#x442;&#x438;&#x43b;&#x435;&#x439;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x433;&#x43e;&#x440;&#x44f;&#x447;&#x438;&#x438; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x448;&#x438;, &#x43a;&#x430;&#x43a; &#x43f;&#x43e;&#x43a;&#x430;&#x437;&#x430;&#x43d;&#x43e; &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e;." ID="ID_1596942382" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x434;&#x43e;&#x431;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x441;&#x43e;&#x431;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x43e;&#x433;&#x43e; &#x441;&#x442;&#x438;&#x43b;&#x44f;, &#x434;&#x43b;&#x44f; &#x43e;&#x43f;&#x44b;&#x442;&#x43d;&#x44b;&#x445; &#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x435;&#x43b;&#x435;&#x439;, &#x43e;&#x442;&#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x443;&#x439;&#x442;&#x435; &#x444;&#x430;&#x439;&#x43b; &quot;patterns.xml&quot; &#x440;&#x430;&#x441;&#x43f;&#x43e;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x43d;&#x44b;&#x439; &#x432; &#x43f;&#x430;&#x43f;&#x43a;&#x435; &quot;.freeplane&quot; &#x432;&#x430;&#x448;&#x435;&#x439; &#x434;&#x43e;&#x43c;&#x430;&#x448;&#x43d;&#x435;&#x439; &#x434;&#x438;&#x440;&#x435;&#x43a;&#x442;&#x43e;&#x440;&#x438;&#x438;." ID="ID_1363352637" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="[This paragraph is outdated.] A remark on the file patterns.xml follows. Physical style applies to node, if there is a &lt;node&gt; tag. It applies to edge, if there is an &lt;edge&gt; tag. &lt;node&gt; tag can have tag as a child. Study the file &quot;patterns.xml&quot; supplied with Freeplane." ID="ID_1083273256" CREATED="1465678964164" MODIFIED="1465678964164"/>
</node>
<node TEXT="&#x41e;&#x431;&#x440;&#x430;&#x43c;&#x43b;&#x435;&#x43d;&#x438;&#x435; &#x443;&#x437;&#x43b;&#x43e;&#x432; &#x43e;&#x431;&#x43b;&#x430;&#x43a;&#x430;&#x43c;&#x438;" FOLDED="true" POSITION="right" ID="ID_193909392" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<node TEXT="&#x41e;&#x431;&#x43b;&#x430;&#x43a;&#x430; &#x445;&#x43e;&#x440;&#x43e;&#x448;&#x438; &#x434;&#x43b;&#x44f; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x43e;&#x431;&#x43b;&#x430;&#x441;&#x442;&#x435;&#x439;. &#x412;&#x44b;&#x434;&#x435;&#x43b;&#x44f;&#x435;&#x442;&#x441;&#x44f; &#x443;&#x437;&#x435;&#x43b; &#x438; &#x432;&#x441;&#x435; &#x435;&#x433;&#x43e; &#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x438;." ID="ID_1960303157" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x43f;&#x43e;&#x44f;&#x432;&#x438;&#x43b;&#x43e;&#x441;&#x44c; &#x43e;&#x431;&#x43b;&#x430;&#x433;&#x43e;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + Shift + B &#x438;&#x43b;&#x438; &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x412;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x430; &gt; &#x41e;&#x431;&#x43b;&#x430;&#x43a;&#x43e;." ID="ID_288691101" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x446;&#x432;&#x435;&#x442;&#x430; &#x43e;&#x431;&#x43b;&#x430;&#x43a;&#x430;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e; &#x424;&#x43e;&#x440;&#x43c;&#x430;&#x442; &gt; &#x426;&#x432;&#x435;&#x442; &#x43e;&#x431;&#x43b;&#x430;&#x43a;&#x430;." ID="ID_1965095088" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x423; &#x43e;&#x431;&#x43b;&#x430;&#x43a;&#x43e;&#x432; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x440;&#x430;&#x437;&#x43b;&#x438;&#x447;&#x43d;&#x44b;&#x435; &#x444;&#x43e;&#x43d;&#x43e;&#x432;&#x44b;&#x435; &#x446;&#x432;&#x435;&#x442;&#x430;, &#x43d;&#x430;&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440; &#x437;&#x435;&#x43b;&#x435;&#x43d;&#x44b;&#x439; ..." FOLDED="true" ID="ID_296227292" CREATED="1465678964164" MODIFIED="1465678964164">
<cloud COLOR="#e1f2e1" SHAPE="ARC"/>
<node TEXT="... &#x438;&#x43b;&#x438; &#x43a;&#x43e;&#x440;&#x438;&#x447;&#x43d;&#x435;&#x432;&#x44b;&#x439;." ID="ID_68557507" CREATED="1465678964164" MODIFIED="1465678964164">
<cloud COLOR="#ede5d5" SHAPE="ARC"/>
</node>
</node>
</node>
<node TEXT="&#x414;&#x43e;&#x431;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x435; &#x433;&#x438;&#x43f;&#x435;&#x440;&#x441;&#x441;&#x44b;&#x43b;&#x43e;&#x43a;" FOLDED="true" POSITION="right" ID="ID_1281219306" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x434;&#x43e;&#x431;&#x430;&#x432;&#x438;&#x442;&#x44c; &#x433;&#x438;&#x43f;&#x435;&#x440;&#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x443;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + K &#x438;&#x43b;&#x438; &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x443;&#x437;&#x43b;&#x430; &#x412;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x430; &gt; &#x421;&#x441;&#x43b;&#x44b;&#x43a;&#x430; (&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43e;&#x432;&#x43e;&#x435; &#x43f;&#x43e;&#x43b;&#x435;)." ID="ID_12522824" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x434;&#x430;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438;, &#x43f;&#x43e;&#x441;&#x43b;&#x435; &#x43d;&#x430;&#x436;&#x430;&#x442;&#x438;&#x44f; Ctrl + K &#x43e;&#x441;&#x442;&#x430;&#x432;&#x44c;&#x442;&#x435; &#x43f;&#x43e;&#x43b;&#x435; &#x43f;&#x443;&#x441;&#x442;&#x44b;&#x43c;." ID="ID_915305392" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x43d;&#x430; e-&#x43c;&#x44d;&#x439;&#x43b; &#x430;&#x434;&#x440;&#x435;&#x441;&#x441;, &#x441;&#x434;&#x435;&#x43b;&#x430;&#x439;&#x442;&#x435; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x443; &#x432;&#x438;&#x434;&#x430;: &#xa;&#xa; mailto:reciever@somemail.com." ID="ID_1422664881" CREATED="1465678964164" MODIFIED="1465678964164">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; e-&#x43c;&#x44d;&#x439;&#x43b; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x441; &#x437;&#x430;&#x434;&#x430;&#x43d;&#x43d;&#x43e;&#x439; &#x442;&#x435;&#x43c;&#x43e;&#x439; &#x43f;&#x438;&#x441;&#x44c;&#x43c;&#x430;, &#x441;&#x434;&#x435;&#x43b;&#x430;&#x439;&#x442;&#x435; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x443; &#x432;&#x438;&#x434;&#x430;: &#xa;&#xa; mailto:reciever@somemail.com?subject=&#x422;&#x435;&#x43c;&#x430; &#x432;&#x430;&#x448;&#x435;&#x433;&#x43e; &#x43f;&#x438;&#x441;&#x44c;&#x43c;&#x430;." ID="ID_350034404" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x421;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x431;&#x44b;&#x442;&#x44c; &#x43d;&#x430; &#x432;&#x435;&#x431;-&#x441;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;&#x44b;, &#x43b;&#x43e;&#x43a;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x435; &#x444;&#x430;&#x439;&#x43b;&#x44b;, &#x438;&#x43b;&#x438; &#x435;-&#x43c;&#x44d;&#x439;&#x43b; &#x430;&#x434;&#x440;&#x435;&#x441;&#x430;." ID="ID_1955910171" CREATED="1465678964164" MODIFIED="1465678964164"/>
</node>
<node TEXT="&#x414;&#x43e;&#x431;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x435; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a;" FOLDED="true" POSITION="right" ID="ID_1135868803" CREATED="1465678964164" MODIFIED="1465678964164" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x423;&#x437;&#x435;&#x43b; &#x43c;&#x43e;&#x436;&#x435;&#x442; &#x438;&#x43c;&#x435;&#x442;&#x44c; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a;.&#xa0;" ID="ID_1356402012" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x434;&#x43e;&#x431;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438; &#x438;&#x43a;&#x43e;&#x43d;&#x43a;&#x438; &#x43a; &#x443;&#x437;&#x43b;&#x435;, &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x443;&#x437;&#x435;&#x43b; &#x438; &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &#x43d;&#x430; &#x43e;&#x434;&#x43d;&#x443; &#x438;&#x437; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a;, &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x43d;&#x44b;&#x445; &#x43d;&#x430; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x438; &#x441;&#x43b;&#x435;&#x432;&#x430;. &#x41f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x430;&#x44f; &#x43a;&#x443;&#x440;&#x441;&#x43e;&#x440; &#x43a; &#x43b;&#x435;&#x432;&#x43e;&#x439; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x438;, &#x437;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; ALT &#x438;&#x43b;&#x438; CONTROL &#x447;&#x442;&#x43e;&#x431;&#x44b; &#x43d;&#x435; &#x43f;&#x43e;&#x442;&#x435;&#x440;&#x44f;&#x442;&#x44c; &#x444;&#x43e;&#x43a;&#x443;&#x441;." ID="ID_983852459" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x434;&#x430;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x43e;&#x434;&#x43d;&#x43e;&#x439; &#x438;&#x43a;&#x43e;&#x43d;&#x43a;&#x438;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &#x43d;&#x430; &#x43a;&#x440;&#x430;&#x441;&#x43d;&#x44b;&#x439; &#x43a;&#x440;&#x435;&#x441;&#x442; &#x43d;&#x430; &#x432;&#x435;&#x440;&#x445;&#x443; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x438; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a;.&#xa0;" ID="ID_128151902" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x434;&#x430;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x432;&#x441;&#x435;&#x445; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &#x43d;&#x430; &quot;&#x43a;&#x43e;&#x440;&#x437;&#x438;&#x43d;&#x443;&quot; &#x43d;&#x430; &#x432;&#x435;&#x440;&#x445;&#x443; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x438; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a;." ID="ID_1099603351" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x434;&#x43e;&#x431;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x43d;&#x43e;&#x432;&#x43e;&#x439; &#x438;&#x43a;&#x43e;&#x43d;&#x43a;&#x438; &#x431;&#x435;&#x437; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x438;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt + I." ID="ID_464243884" CREATED="1465678964164" MODIFIED="1465678964164">
<icon BUILTIN="help"/>
<font NAME="Aharoni" SIZE="12"/>
</node>
<node TEXT="&#x41f;&#x43e;&#x43a;&#x430; &#x43d;&#x435;&#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x441;&#x43e;&#x431;&#x441;&#x442;&#x432;&#x435;&#x43d;&#x43d;&#x44b;&#x435; &#x438;&#x43a;&#x43e;&#x43d;&#x43a;&#x438;; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x432;&#x44b;&#x431;&#x438;&#x440;&#x430;&#x442;&#x44c; &#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x438;&#x437; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a; &#x438;&#x434;&#x443;&#x449;&#x438;&#x445; &#x441; Freeplane." ID="ID_1804280657" CREATED="1465678964164" MODIFIED="1465678964164"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x43f;&#x43e;&#x43a;&#x430;&#x437;&#x430;&#x442;&#x44c; &#x438;&#x43b;&#x438; &#x443;&#x431;&#x440;&#x430;&#x442;&#x44c; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x44c; &#x438;&#x43a;&#x43e;&#x43d;&#x43e;&#x43a;, &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x444;&#x43e;&#x43d;&#x430; (&#x43d;&#x435; &#x443;&#x437;&#x43b;&#x430; &#x438;&#x43b;&#x438; &#x434;&#x443;&#x433;&#x438;) &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x41f;&#x43e;&#x43a;&#x430;&#x437;&#x430;&#x442;&#x44c;/&#x441;&#x43f;&#x440;&#x44f;&#x442;&#x430;&#x442;&#x44c; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x44c; &#x441; &#x43f;&#x438;&#x43a;&#x442;&#x43e;&#x433;&#x440;&#x430;&#x43c;&#x43c;&#x430;&#x43c;&#x438; . &#x422;&#x430;&#x43a; &#x436;&#x435; &#x44d;&#x442;&#x430; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x44c; &#x43d;&#x430;&#x437;&#x44b;&#x432;&#x430;&#x435;&#x442;&#x441;&#x44f; &quot;&#x43b;&#x435;&#x432;&#x43e;&#x439;&quot;." ID="ID_1716983478" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43e;&#x441;&#x442;&#x443;&#x43f;&#x43d;&#x44b; &#x438;&#x43a;&#x43e;&#x43d;&#x43a;&#x438; &#x43d;&#x430;&#x445;&#x43e;&#x434;&#x44f;&#x449;&#x438;&#x435;&#x441;&#x44f; &#x432; &#x44d;&#x442;&#x43e;&#x43c; &#x443;&#x437;&#x43b;&#x435;, &#x438; &#x43c;&#x43d;&#x43e;&#x433;&#x438;&#x435; &#x434;&#x440;&#x443;&#x433;&#x438;&#x435;." ID="ID_1120278361" CREATED="1465678964180" MODIFIED="1465678964180">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="icon_not_found"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node TEXT="&#x414;&#x43e;&#x431;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x435; &#x433;&#x440;&#x430;&#x444;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438;&#x445; &#x441;&#x432;&#x44f;&#x437;&#x435;&#x439;" FOLDED="true" POSITION="right" ID="ID_1498284271" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x44f; &#x441;&#x432;&#x44f;&#x437;&#x438; &#x43c;&#x435;&#x436;&#x434;&#x443; &#x434;&#x432;&#x443;&#x43c;&#x44f; &#x443;&#x437;&#x43b;&#x430;&#x43c;&#x438;, &#x43f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x449;&#x438;&#x442;&#x435; &#x438; &#x43e;&#x442;&#x43f;&#x443;&#x441;&#x442;&#x438;&#x442;&#x435; &#x43e;&#x434;&#x438;&#x43d; &#x443;&#x437;&#x435;&#x43b; &#x43d;&#x430; &#x434;&#x440;&#x443;&#x433;&#x43e;&#x439;, &#x443;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x44f; &#x43e;&#x434;&#x43d;&#x43e;&#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x43d;&#x43e; shift &#x438; control; &#x43e;&#x442;&#x43f;&#x443;&#x441;&#x442;&#x438;&#x442;&#x435; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x443; &#x43c;&#x44b;&#x448;&#x438; &#x434;&#x43e; &#x442;&#x43e;&#x433;&#x43e; &#x43a;&#x430;&#x43a; &#x43e;&#x442;&#x43f;&#x443;&#x441;&#x442;&#x438;&#x442;&#x435; shift &#x438; control." ID="ID_1558180251" CREATED="1465678964180" MODIFIED="1465678964180">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_266716332" STARTINCLINATION="255;0;" ENDINCLINATION="255;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="&#x418;&#x43b;&#x438;, &#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x432;&#x44b;&#x431;&#x440;&#x430;&#x442;&#x44c; 2 &#x443;&#x437;&#x43b;&#x430; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x44f; Ctrl &#x438; &#x43d;&#x430;&#x436;&#x430;&#x432; &quot;&#x414;&#x43e;&#x431;&#x430;&#x432;&#x438;&#x442;&#x44c; &#x441;&#x432;&#x44f;&#x437;&#x44c;&quot; &#x438;&#x437; &#x43f;&#x443;&#x43d;&#x43a;&#x442;&#x438; &quot;&#x412;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x430;&quot; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x433;&#x43e; &#x43c;&#x435;&#x43d;&#x44e; &#x438;&#x43b;&#x438; &#x433;&#x43e;&#x440;&#x44f;&#x447;&#x438;&#x445; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x448; Ctrl+L" ID="ID_338455791" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x446;&#x432;&#x435;&#x442;&#x430; &#x441;&#x432;&#x44f;&#x437;&#x438;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e; &#x441;&#x432;&#x44f;&#x437;&#x438;, &#x43d;&#x430;&#x436;&#x430;&#x432; &#x43f;&#x440;&#x430;&#x432;&#x43e;&#x439; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x43e;&#x439; &#x43c;&#x44b;&#x448;&#x438; &#x43d;&#x430; &#x433;&#x440;&#x430;&#x444;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x43e;&#x439; &#x441;&#x442;&#x440;&#x435;&#x43b;&#x43a;&#x435;." ID="ID_795384904" CREATED="1465678964180" MODIFIED="1465678964180">
<font ITALIC="false"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x43d;&#x430;&#x43f;&#x440;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x441;&#x432;&#x44f;&#x437;&#x438;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x435;&#x435; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e;." ID="ID_800860835" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x434;&#x430;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x441;&#x432;&#x44f;&#x437;&#x438;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x435;&#x435; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e;," ID="ID_487273636" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f; &#x43a; &#x43e;&#x434;&#x43d;&#x43e;&#x43c;&#x443; &#x438;&#x437; &#x441;&#x432;&#x44f;&#x437;&#x430;&#x43d;&#x43d;&#x44b;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x435; &#x43c;&#x435;&#x43d;&#x44e; &#x441;&#x432;&#x44f;&#x437;&#x438;." ID="_Freeplane_Link_266716332" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x43f;&#x43e;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x44f; &#x441;&#x432;&#x44f;&#x437;&#x438;, &#x437;&#x430;&#x445;&#x432;&#x430;&#x442;&#x438;&#x442;&#x435; &#x435;&#x435; &#x43c;&#x44b;&#x448;&#x43a;&#x43e;&#x439; &#x438; &#x434;&#x432;&#x438;&#x433;&#x430;&#x439;&#x442;&#x435;." ID="ID_1591797016" CREATED="1465678964180" MODIFIED="1465678964180">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_266716332" STARTINCLINATION="244;32;" ENDINCLINATION="256;22;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="&#x417;&#x434;&#x435;&#x441;&#x44c; &#x432;&#x44b; &#x432;&#x438;&#x434;&#x438;&#x442;&#x435; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440;&#x44b; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x433;&#x440;&#x430;&#x444;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438;&#x445; &#x441;&#x432;&#x44f;&#x437;&#x435;&#x439;." ID="ID_663803245" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x41d;&#x430;&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440;" FOLDED="true" ID="ID_1330201021" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<node TEXT="&#x421;&#x432;&#x44f;&#x437;&#x44c; &#x441; &#x434;&#x440;&#x443;&#x433;&#x43e;&#x439; &#x447;&#x430;&#x441;&#x442;&#x44c;&#x44e;" ID="_Freeplane_Link_1170112929" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#9999ff" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1492563156" STARTINCLINATION="30;0;" ENDINCLINATION="127;0;" STARTARROW="DEFAULT" ENDARROW="DEFAULT"/>
</node>
<node TEXT="&#x423;&#x437;&#x435;&#x43b; &#x441; &#x43f;&#x43e;&#x434;-&#x443;&#x437;&#x43b;&#x43e;&#x43c;" FOLDED="true" ID="ID_564059070" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<node TEXT="&#x41f;&#x43e;&#x434;-&#x443;&#x437;&#x435;&#x43b;" ID="_Freeplane_Link_1492563156" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x414;&#x440;&#x443;&#x433;&#x430;&#x44f; &#x441;&#x432;&#x44f;&#x437;&#x44c;" ID="ID_1365322687" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1170112929" STARTINCLINATION="61;0;" ENDINCLINATION="61;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
</node>
</node>
<node TEXT="&#x41f;&#x43e;&#x438;&#x441;&#x43a;" FOLDED="true" POSITION="right" ID="ID_1844143957" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43d;&#x430;&#x445;&#x43e;&#x436;&#x434;&#x435;&#x43d;&#x438;&#x44f; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x430; &#x441;&#x440;&#x435;&#x434;&#x438; &#x432;&#x441;&#x435;&#x445; &#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x43e;&#x432; &#x443;&#x437;&#x43b;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + F &#x438;&#x43b;&#x438; &#x432; &#x43c;&#x435;&#x43d;&#x44e; &quot;&#x41f;&#x440;&#x430;&#x432;&#x43a;&#x430;&quot; - &#x418;&#x441;&#x43a;&#x430;&#x442;&#x44c;." ID="ID_1341100620" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x445;&#x43e;&#x434;&#x430; &#x43a; &#x441;&#x43b;&#x435;&#x434;&#x443;&#x449;&#x435;&#x439;&#x439; &#x43d;&#x430;&#x439;&#x434;&#x435;&#x43d;&#x43d;&#x43e;&#x439; &#x441;&#x442;&#x440;&#x43e;&#x43a;&#x435;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + G &#x438;&#x43b;&#x438; &#x432; &#x43c;&#x435;&#x43d;&#x44e; &quot;&#x41f;&#x440;&#x430;&#x432;&#x43a;&#x430;&quot; &#x418;&#x441;&#x43a;&#x430;&#x442;&#x44c; &#x434;&#x430;&#x43b;&#x435;&#x435;." ID="ID_1780355552" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x43e;&#x438;&#x441;&#x43a;&#x430; &#x43f;&#x43e; &#x432;&#x441;&#x435;&#x439; &#x43a;&#x430;&#x440;&#x442;&#x435;, &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x446;&#x435;&#x43d;&#x442;&#x440;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x439; &#x443;&#x437;&#x435;&#x43b;, &#x43d;&#x430;&#x436;&#x430;&#x432; Escape &#x43f;&#x435;&#x440;&#x435;&#x434; &#x43f;&#x43e;&#x438;&#x441;&#x43a;&#x43e;&#x43c;." ID="ID_648221339" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x41f;&#x43e;&#x438;&#x441;&#x43a; &#x440;&#x430;&#x431;&#x43e;&#x442;&#x430;&#x435;&#x442; &#x43f;&#x43e; &#x430;&#x43b;&#x433;&#x43e;&#x440;&#x438;&#x442;&#x43c;&#x443; &#x43f;&#x43e;&#x438;&#x441;&#x43a; &#x432; &#x448;&#x438;&#x440;&#x438;&#x43d;&#x443;. &#x42d;&#x442;&#x43e; &#x441;&#x43e;&#x43e;&#x442;&#x432;&#x435;&#x442;&#x441;&#x442;&#x432;&#x443;&#x435;&#x442; &#x438;&#x434;&#x435;&#x435; - &#x447;&#x435;&#x43c; &#x433;&#x43b;&#x443;&#x431;&#x436;&#x435; &#x443;&#x437;&#x435;&#x43b;, &#x442;&#x435;&#x43c; &#x431;&#x43e;&#x43b;&#x435;&#x435; &#x434;&#x435;&#x442;&#x430;&#x43b;&#x44c;&#x43d;&#x43e; &#x43e;&#x43d;&#xa0;&#xa0;&#x43e;&#x43f;&#x438;&#x441;&#x430;&#x43d;." ID="ID_1682227679" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x41f;&#x43e;&#x43c;&#x43d;&#x438;&#x442;&#x435;, &#x447;&#x442;&#x43e; &#x43f;&#x43e;-&#x443;&#x43c;&#x43e;&#x43b;&#x447;&#x430;&#x43d;&#x438;&#x44e; &#x43f;&#x43e;&#x438;&#x441;&#x43a; &#x438;&#x434;&#x435;&#x442; &#x43d;&#x435; &#x43f;&#x43e; &#x432;&#x441;&#x435;&#x439; &#x43a;&#x430;&#x440;&#x442;&#x435;, &#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x432; &#x443;&#x437;&#x43b;&#x435; &#x438; &#x435;&#x433;&#x43e; &#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x430;&#x445;." ID="ID_1698444380" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x412;&#x44b;&#x431;&#x43e;&#x440; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x438;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;" FOLDED="true" POSITION="right" ID="ID_1924365070" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x438;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x437;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; control &#x438;&#x43b;&#x438; shift, &#x438; &#x43a;&#x43b;&#x438;&#x43a;&#x430;&#x439;&#x442;&#x435; &#x43d;&#x430; &#x443;&#x437;&#x43b;&#x44b;." ID="ID_744687888" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x434;&#x43e;&#x431;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x43e;&#x442;&#x434;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x443;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; control &#x43f;&#x43e;&#x43a;&#x430; &#x43a;&#x43b;&#x438;&#x43a;&#x430;&#x435;&#x442;&#x435; &#x43f;&#x43e; &#x43d;&#x438;&#x43c;." ID="ID_1810607805" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x440;&#x430;&#x434;&#x43e;&#x43c; &#x440;&#x430;&#x441;&#x43f;&#x43e;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x43d;&#x44b;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x443;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; shift &#x438; &#x43a;&#x43b;&#x438;&#x43a;&#x430;&#x439;&#x442;&#x435; &#x43f;&#x43e; &#x43d;&#x438;&#x43c;, &#x438;&#x43b;&#x438; &#x443;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; shift &#x438; &#x43e;&#x431;&#x43e;&#x439;&#x434;&#x438;&#x442;&#x435; &#x443;&#x437;&#x43b;&#x44b; &#x441;&#x442;&#x440;&#x435;&#x43b;&#x43a;&#x430;&#x43c;&#x438; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x430;&#x442;&#x443;&#x440;&#x44b;." ID="ID_495846518" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x44b;&#x431;&#x43e;&#x440;&#x430; &#x432;&#x441;&#x435;&#x433;&#x43e; &#x43f;&#x43e;&#x434;&#x434;&#x435;&#x440;&#x435;&#x432;&#x430;, &#x437;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; AltGr &#x43f;&#x435;&#x440;&#x435;&#x434; &#x432;&#x44b;&#x431;&#x43e;&#x440;&#x43e;&#x43c; &#x443;&#x437;&#x43b;&#x430;, &#x438;&#x43b;&#x438; shift &#x438; &#x43f;&#x440;&#x43e;&#x439;&#x434;&#x438;&#x442;&#x435; &#x441;&#x442;&#x440;&#x435;&#x43b;&#x43a;&#x430;&#x43c;&#x438; &#x43f;&#x443;&#x442;&#x44c; &#x43e;&#x442; &#x443;&#x437;&#x43b;&#x430; &#x434;&#x43e; &#x43d;&#x435;&#x43e;&#x431;&#x445;&#x43e;&#x434;&#x438;&#x43c;&#x43e;&#x433;&#x43e; &#x43f;&#x440;&#x435;&#x434;&#x43a;&#x430;. &#x418;&#x43b;&#x438; &#x43d;&#x430;&#x43a;&#x43e;&#x43d;&#x435;&#x446; Ctrl+Shift+A &#x434;&#x435;&#x43b;&#x430;&#x435;&#x442; &#x442;&#x43e; &#x436;&#x435; &#x441;&#x430;&#x43c;&#x43e;&#x435;." ID="ID_346395848" CREATED="1465678964180" MODIFIED="1465678964180">
<icon BUILTIN="help"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43e;&#x442;&#x43c;&#x435;&#x43d;&#x44b; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x438;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x43a;&#x43b;&#x438;&#x43a;&#x43d;&#x438;&#x442;&#x435; &#x43d;&#x430; &#x444;&#x43e;&#x43d;&#x435; &#x43a;&#x430;&#x440;&#x442;&#x44b; &#x438;&#x43b;&#x438; &#x43d;&#x430; &#x43d;&#x435;&#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x43d;&#x43e;&#x43c; &#x443;&#x437;&#x43b;&#x435;." ID="ID_527970583" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x441;&#x43a;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x435;" FOLDED="true" POSITION="right" ID="ID_993839636" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x430;&#x442;&#x44c; &#x443;&#x437;&#x43b;&#x44b; &#x43f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x441;&#x43a;&#x438;&#x432;&#x430;&#x44f; &#x438;&#x445; &#x43c;&#x44b;&#x448;&#x44c;&#x44e;." ID="ID_1254193603" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x438; &#x443;&#x437;&#x43b;&#x430; &#x43a;&#x430;&#x43a; &#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x430;, &#x434;&#x435;&#x440;&#x436;&#x438;&#x442;&#x435; &#x43a;&#x443;&#x440;&#x441;&#x43e;&#x440; &#x43d;&#x430; &quot;&#x432;&#x44b;&#x445;&#x43e;&#x434;&#x44f;&#x449;&#x435;&#x439;&quot; &#x447;&#x430;&#x441;&#x442;&#x438; &#x443;&#x437;&#x43b;&#x430;, &#x43a;&#x43e;&#x433;&#x434;&#x430; &#x43e;&#x442;&#x43f;&#x443;&#x441;&#x43a;&#x430;&#x435;&#x442;&#x435;." ID="ID_976292274" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x438; &#x443;&#x437;&#x43b;&#x430; &#x43a;&#x430;&#x43a; &#x431;&#x440;&#x430;&#x442;&#x430;, &#x434;&#x435;&#x440;&#x436;&#x438;&#x442;&#x435; &#x43a;&#x443;&#x440;&#x441;&#x43e;&#x440; &#x441;&#x43e; &#x441;&#x442;&#x43e;&#x440;&#x43e;&#x43d;&#x44b; &#x435;&#x433;&#x43e; &#x441;&#x432;&#x44f;&#x437;&#x438; &#x441; &#x43f;&#x440;&#x435;&#x434;&#x44b;&#x434;&#x443;&#x449;&#x438;&#x43c; &#x443;&#x437;&#x43b;&#x43e;&#x43c;, &#x43a;&#x43e;&#x433;&#x434;&#x430; &#x43e;&#x442;&#x43f;&#x443;&#x441;&#x43a;&#x430;&#x435;&#x442;&#x435;." ID="ID_525483403" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x430; &#x43d;&#x435; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x430;, &#x443;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; control &#x43f;&#x440;&#x438; &#x43f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x441;&#x43a;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x438; , &#x438;&#x43b;&#x438; &#x43f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x441;&#x43a;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; &#x441;&#x440;&#x435;&#x434;&#x43d;&#x435;&#x439; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x43e;&#x439; &#x43c;&#x44b;&#x448;&#x438;." ID="ID_784486759" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x441;&#x443;&#x449;&#x435;&#x441;&#x442;&#x432;&#x443;&#x44e;&#x449;&#x435;&#x439; &#x441;&#x445;&#x435;&#x43c;&#x44b;, &#x43f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x449;&#x438;&#x442;&#x435; &#x435;&#x435; &#x444;&#x430;&#x439;&#x43b; &#x43d;&#x430; &#x444;&#x43e;&#x43d; Freeplane; &#x43f;&#x43e;&#x43a;&#x430; &#x44d;&#x442;&#x43e; &#x440;&#x430;&#x431;&#x43e;&#x442;&#x430;&#x435;&#x442; &#x442;&#x43e;&#x43b;&#x44c;&#x43a; &#x432; Microsoft Windows." ID="ID_654958579" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x44f; &#x433;&#x440;&#x430;&#x444;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x43e;&#x439; &#x441;&#x432;&#x44f;&#x437;&#x438;, &#x43f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x441;&#x43a;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; &#x443;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x44f; &#x43f;&#x440;&#x430;&#x432;&#x443;&#x44e; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x443; &#x43c;&#x44b;&#x448;&#x438;." ID="ID_1125959620" CREATED="1465678964180" MODIFIED="1465678964180">
<icon BUILTIN="help"/>
<font NAME="Aharoni" SIZE="12"/>
</node>
<node TEXT="&#x415;&#x441;&#x43b;&#x438; &#x432;&#x44b; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x438;&#x43b;&#x438; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x442;&#x43e; &#x43e;&#x43d;&#x438; &#x432;&#x441;&#x435; &#x431;&#x443;&#x434;&#x443;&#x442; &#x441;&#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x44b;/&#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x44b;." ID="ID_434626436" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x43f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x441;&#x43a;&#x438;&#x432;&#x430;&#x442;&#x44c; &#x434;&#x430;&#x43d;&#x43d;&#x44b;&#x435; &#x438;&#x437; &#x432;&#x43d;&#x435;&#x448;&#x43d;&#x438;&#x445; &#x43f;&#x440;&#x438;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x439;, &#x43d;&#x430;&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440; &#x438;&#x437; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; &#x432; Microsoft Windows, &#x438;&#x43b;&#x438; &#x432;&#x44b;&#x431;&#x440;&#x430;&#x43d;&#x43d;&#x44b;&#x439; &#x442;&#x435;&#x43a;&#x441;&#x442; &#x438;&#x437; Microsoft Internet Explorer." ID="ID_1118630555" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x41a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x438; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x430;" FOLDED="true" POSITION="right" ID="ID_1399170375" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x438; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x442;&#x44c; &#x443;&#x437;&#x43b;&#x44b; &#x432; &#x440;&#x430;&#x437;&#x43d;&#x44b;&#x435; &#x441;&#x445;&#x435;&#x43c;&#x44b;. &#x410; &#x442;&#x430;&#x43a; &#x436;&#x435; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x442;&#x44c; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x43e;&#x439; &#x442;&#x435;&#x43a;&#x441;&#x442; &#x438;&#x43b;&#x438; HTML &#x438;&#x437; &#x434;&#x440;&#x443;&#x433;&#x438;&#x445; &#x43f;&#x440;&#x438;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x439;." ID="ID_319864541" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x415;&#x441;&#x43b;&#x438; &#x432;&#x44b; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x435;&#x442;&#x435; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x43e;&#x439; &#x442;&#x435;&#x43a;&#x441;&#x442;, &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x441;&#x442;&#x440;&#x43e;&#x43a; &#x438;&#x43d;&#x442;&#x435;&#x440;&#x43f;&#x440;&#x435;&#x442;&#x438;&#x440;&#x443;&#x44e;&#x442;&#x441;&#x44f; &#x43a;&#x430;&#x43a; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x441; &#x433;&#x43b;&#x443;&#x431;&#x438;&#x43d;&#x43e;&#x439;, &#x43e;&#x43f;&#x440;&#x435;&#x434;&#x435;&#x43b;&#x44f;&#x435;&#x43c;&#x43e;&#x439; &#x43f;&#x43e; &#x43a;&#x43e;&#x43b;&#x438;&#x447;&#x435;&#x441;&#x442;&#x432;&#x443; &#x432;&#x43f;&#x435;&#x440;&#x435;&#x434;&#x438; &#x441;&#x442;&#x43e;&#x44f;&#x449;&#x438;&#x445; &#x43f;&#x440;&#x43e;&#x431;&#x435;&#x43b;&#x43e;&#x432; &#x432; &#x441;&#x442;&#x440;&#x43e;&#x43a;&#x435;. &#x414;&#x430;&#x43b;&#x435;&#x435; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440;." ID="ID_1882559463" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x435;&#x440;&#x435;&#x432;&#x43e;&#xa;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#x414;&#x443;&#x431;&#xa;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#x412;&#x44f;&#x437;&#xa;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;" FOLDED="true" ID="ID_704146567" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<node TEXT="&#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x435;&#x442;&#x441;&#x44f; &#x43a;&#x430;&#x43a;" FOLDED="true" ID="ID_105147350" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x435;&#x440;&#x435;&#x432;&#x43e;" FOLDED="true" ID="ID_981410752" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x443;&#x431;" ID="ID_234833076" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x412;&#x44f;&#x437;" ID="ID_1734246965" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="&#x415;&#x441;&#x43b;&#x438; &#x432;&#x44b; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x435;&#x442;&#x435; HTML-&#x442;&#x435;&#x43a;&#x441;&#x442;, &#x43e;&#x43d; &#x432;&#x441;&#x442;&#x430;&#x432;&#x438;&#x442;&#x441;&#x44f; &#x43a;&#x430;&#x43a; &#x43e;&#x431;&#x44b;&#x447;&#x43d;&#x44b;&#x439; &#x442;&#x435;&#x43a;&#x441;&#x442;. &#x422;&#x430;&#x43a; &#x436;&#x435;, &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x430;&#x449;&#x438;&#x435;&#x441;&#x44f; &#x432; HTML &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x44e;&#x442;&#x441;&#x44f; &#x43a;&#x430;&#x43a; &#x43f;&#x43e;&#x442;&#x43e;&#x43c;&#x43a;&#x438; &#x44d;&#x442;&#x43e;&#x433;&#x43e; &#x443;&#x437;&#x43b;&#x430;, &#x432; &#x443;&#x437;&#x435;&#x43b; &#x441; &#x43d;&#x430;&#x437;&#x432;&#x430;&#x43d;&#x438;&#x435;&#x43c; &quot;&#x421;&#x441;&#x44b;&#x43b;&#x43a;&#x438;&quot;. &#x414;&#x430;&#x43b;&#x435;&#x435; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440;." ID="ID_938321364" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x41d;&#x430;&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440; &#x43f;&#x43e;&#x441;&#x43b;&#x435; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x438;:" FOLDED="true" ID="ID_1042647240" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x41f;&#x43e;&#x43a;&#x443;&#x43f;&#x43a;&#x438; (120236)" ID="ID_1236393652" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x413;&#x43e;&#x440;&#x43e;&#x434;&#x441;&#x43a;&#x430;&#x44f; &#x436;&#x438;&#x437;&#x43d;&#x44c; (4)" ID="ID_1437644770" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x421;&#x441;&#x44b;&#x43b;&#x43a;&#x438;" FOLDED="true" ID="ID_1426020357" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="Dialog" SIZE="12" BOLD="true"/>
<node TEXT="&#x41f;&#x43e;&#x43a;&#x443;&#x43f;&#x43a;&#x438;" ID="ID_593587995" CREATED="1465678964180" MODIFIED="1465678964180" LINK="http://www.google.ru/Top/World/Russian/%D0%9F%D0%BE%D0%BA%D1%83%D0%BF%D0%BA%D0%B8/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x413;&#x43e;&#x440;&#x43e;&#x434;&#x441;&#x43a;&#x430;&#x44f; &#x436;&#x438;&#x437;&#x43d;&#x44c;" ID="ID_639002268" CREATED="1465678964180" MODIFIED="1465678964180" LINK="http://www.google.ru/Top/World/Russian/%D0%94%D0%BE%D0%BC/%D0%93%D0%BE%D1%80%D0%BE%D0%B4%D1%81%D0%BA%D0%B0%D1%8F_%D0%B6%D0%B8%D0%B7%D0%BD%D1%8C/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="&#x415;&#x441;&#x43b;&#x438; &#x432;&#x44b; &#x432;&#x441;&#x442;&#x430;&#x432;&#x438;&#x442;&#x435; &#x441;&#x43f;&#x438;&#x441;&#x43e;&#x43a; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432;, &#x432;&#x44b;&#x431;&#x440;&#x430;&#x43d;&#x43d;&#x44b;&#x439; &#x432; &#x41f;&#x440;&#x43e;&#x432;&#x43e;&#x434;&#x43d;&#x438;&#x43a;&#x435; &#x432; Microsoft Windows, &#x43e;&#x43d; &#x432;&#x441;&#x442;&#x430;&#x432;&#x438;&#x442;&#x441;&#x44f; &#x43a;&#x430;&#x43a; &#x433;&#x440;&#x443;&#x43f;&#x43f;&#x430; &#x443;&#x437;&#x43b;&#x43e;&#x432;-&#x441;&#x441;&#x44b;&#x43b;&#x43e;&#x43a; &#x43d;&#x430; &#x44d;&#x442;&#x438; &#x444;&#x430;&#x439;&#x43b;&#x44b;." ID="ID_1765131509" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x415;&#x441;&#x43b;&#x438; &#x432;&#x44b; &#x441;&#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x443;&#x435;&#x442;&#x435; &#x432;&#x435;&#x442;&#x432;&#x44c; &#x438;&#x437; Freeplane &#x438; &#x432;&#x441;&#x442;&#x430;&#x432;&#x438;&#x442;&#x435; &#x432; &#x43e;&#x431;&#x44b;&#x447;&#x43d;&#x44b;&#x439; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x43e;&#x432;&#x44b;&#x439; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;, &#x441;&#x442;&#x440;&#x443;&#x43a;&#x442;&#x443;&#x440;&#x430; &#x431;&#x443;&#x434;&#x435;&#x442; &#x43e;&#x442;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x430; &#x432; &#x432;&#x438;&#x434;&#x435; &#x43e;&#x442;&#x441;&#x442;&#x443;&#x43f;&#x43e;&#x432;. &#x413;&#x438;&#x43f;&#x435;&#x440;&#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x431;&#x443;&#x434;&#x443;&#x442; &#x437;&#x430;&#x43a;&#x43b;&#x44e;&#x447;&#x435;&#x43d;&#x44b; &#x432;&#xa0;&#xa0;&lt;&gt; &#x441;&#x43a;&#x43e;&#x431;&#x43a;&#x438;. &#x41f;&#x440;&#x438;&#x43c;&#x435;&#x440; &#x434;&#x430;&#x43b;&#x435;&#x435;." ID="ID_1000469648" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x435;&#x440;&#x435;&#x432;&#x43e;" FOLDED="true" ID="ID_1818027039" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x443;&#x431;" ID="ID_1255463808" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x412;&#x44f;&#x437;" FOLDED="true" ID="ID_1848001572" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="is pasted as" FOLDED="true" ID="ID_1433136242" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x435;&#x440;&#x435;&#x432;&#x43e;&#xa;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#x414;&#x443;&#x431;&#xa;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#x412;&#x44f;&#x437;&#xa;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#x413;&#x443;&#x433;&#x43b; &lt;http://www.google.com/&gt;" ID="ID_1696955848" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="&#x413;&#x443;&#x433;&#x43b;" ID="ID_1403876923" CREATED="1465678964180" MODIFIED="1465678964180" LINK="http://www.google.com/" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x415;&#x441;&#x43b;&#x438; &#x432; Freeplane &#x432;&#x44b; &#x441;&#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x443;&#x435;&#x442;&#x435; &#x432;&#x435;&#x442;&#x432;&#x44c; &#x438; &#x432;&#x441;&#x442;&#x430;&#x432;&#x438;&#x442;&#x435; &#x435;&#x435; &#x432; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;, &#x43f;&#x43e;&#x43d;&#x438;&#x43c;&#x430;&#x44e;&#x449;&#x438;&#x439; &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442; Rich Text, &#x441;&#x43e;&#x445;&#x440;&#x430;&#x43d;&#x44f;&#x442;&#x441;&#x44f; &#x442;&#x430;&#x43a;&#x436;&#x435; &#x438; &#x446;&#x432;&#x435;&#x442;&#x430; &#x438; &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x448;&#x440;&#x438;&#x444;&#x442;&#x430;. &#x413;&#x438;&#x43f;&#x435;&#x440;&#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x431;&#x443;&#x434;&#x443;&#x442; &#x432; &lt;&gt; &#x441;&#x43a;&#x43e;&#x431;&#x43a;&#x430;&#x445;, &#x43a;&#x430;&#x43a; &#x438; &#x432; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x43e;&#x43c; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x435;. &#x420;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;&#x44b; &#x443;&#x43c;&#x435;&#x44e;&#x449;&#x438;&#x435; &#x440;&#x430;&#x431;&#x43e;&#x442;&#x430;&#x442;&#x44c; &#x441; &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x43e;&#x43c; Rich Text : Microsoft Word, Wordpad &#x438;&#x43b;&#x438; Microsoft Outlook, &#x438; &#x43e;&#x447;&#x435;&#x43d;&#x44c; &#x43c;&#x43d;&#x43e;&#x433;&#x438;&#x435; &#x432; &#x432;&#x435;&#x43b;&#x438;&#x43a;&#x43e;&#x43b;&#x435;&#x43f;&#x43d;&#x435;&#x439;&#x448;&#x435;&#x43c; Linux." ID="ID_1537581925" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x430; &#x431;&#x435;&#x437; &#x435;&#x433;&#x43e; &#x437;&#x430;&#x432;&#x438;&#x441;&#x438;&#x43c;&#x43e;&#x441;&#x442;&#x435;&#x439;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Ctrl + Y &#x438;&#x43b;&#x438; &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x41a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x44d;&#x442;&#x43e;&#x442; &#x443;&#x437;&#x435;&#x43b;." ID="ID_243597736" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x435;" FOLDED="true" POSITION="right" ID="ID_157446099" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f; &#x432;&#x44b;&#x434;&#x435;&#x43b;&#x435;&#x43d;&#x438;&#x44f; &#x432;&#x432;&#x435;&#x440;&#x445;, &#x432;&#x43d;&#x438;&#x437;, &#x432;&#x43b;&#x435;&#x432;&#x43e; &#x438;&#x43b;&#x438; &#x432;&#x43f;&#x440;&#x430;&#x432;&#x43e;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x441;&#x442;&#x440;&#x435;&#x43b;&#x43a;&#x438; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x430;&#x442;&#x443;&#x440;&#x44b;." ID="ID_1761308381" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f; &#x43a; &#x432;&#x435;&#x440;&#x445;&#x43d;&#x435;&#x43c;&#x443; &#x443;&#x437;&#x43b;&#x443; &#x442;&#x435;&#x43a;&#x443;&#x449;&#x435;&#x433;&#x43e; &#x43f;&#x43e;&#x434;&#x434;&#x435;&#x440;&#x435;&#x432;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; PageUp." ID="ID_121058942" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f; &#x43a; &#x43d;&#x438;&#x436;&#x43d;&#x435;&#x43c;&#x443; &#x443;&#x437;&#x43b;&#x443; &#x442;&#x435;&#x43a;&#x443;&#x449;&#x435;&#x433;&#x43e; &#x434;&#x435;&#x440;&#x435;&#x432;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; PageDown." ID="ID_1536065862" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f; &#x43a; &#x426;&#x435;&#x43d;&#x442;&#x440;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;&#x43c;&#x443; &#x443;&#x437;&#x43b;&#x443;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Escape." ID="ID_731285289" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x441;&#x432;&#x43e;&#x431;&#x43e;&#x434;&#x43d;&#x43e;&#x433;&#x43e; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x435;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x445;&#x432;&#x430;&#x442;&#x430;&#x439;&#x442;&#x435; &#x438;&#x445; &#x437;&#x430; &#x43d;&#x435;&#x432;&#x438;&#x434;&#x438;&#x43c;&#x443;&#x44e; &#x440;&#x443;&#x447;&#x43a;&#x443; &#x440;&#x430;&#x441;&#x43f;&#x43e;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x43d;&#x443;&#x44e; &#x441;&#x43e; &#x441;&#x442;&#x43e;&#x440;&#x43e;&#x43d;&#x44b; &#x43f;&#x440;&#x438;&#x441;&#x43e;&#x435;&#x434;&#x438;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x430; &#x43a; &#x440;&#x43e;&#x434;&#x438;&#x442;&#x435;&#x43b;&#x44e;, &#x438; &#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x449;&#x430;&#x439;&#x442;&#x435; &#x43a;&#x443;&#x434;&#x430; &#x437;&#x430;&#x445;&#x43e;&#x442;&#x438;&#x442;&#x435;." ID="ID_590276294" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x421;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x438; &#x440;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x435;" FOLDED="true" POSITION="right" ID="ID_1949236452" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x441;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &#x43f;&#x440;&#x43e;&#x431;&#x435;&#x43b;, &#x438;&#x43b;&#x438; &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x421;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c;/&#x420;&#x430;&#x437;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c;." ID="ID_390584406" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x440;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x443;&#x437;&#x43b;&#x430;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &#x43f;&#x440;&#x43e;&#x431;&#x435;&#x43b;, &#x438;&#x43b;&#x438; &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x420;&#x430;&#x437;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c;, &#x438;&#x43b;&#x438; &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &#x441;&#x442;&#x440;&#x435;&#x43b;&#x43a;&#x443; &#x432; &#x43d;&#x430;&#x43f;&#x440;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x438; &#x440;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f;." ID="ID_1820764856" CREATED="1465678964180" MODIFIED="1465678964180">
<icon BUILTIN="help"/>
<font NAME="Aharoni" SIZE="12"/>
</node>
<node TEXT="&#x414;&#x43b;&#x44f; &#x441;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f;/&#x440;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x432;&#x441;&#x435;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x437;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt &#x438; &#x43f;&#x43e;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43b;&#x435;&#x441;&#x43e; &#x43c;&#x44b;&#x448;&#x438;, &#x438;&#x43b;&#x438; &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt + PageUp &#x438;&#x43b;&#x438; Alt + PageDown. &#x411;&#x443;&#x434;&#x44c;&#x442;&#x435; &#x43e;&#x441;&#x442;&#x43e;&#x440;&#x43e;&#x436;&#x43d;&#x44b; &#x441; &#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x438;&#x43c;&#x438; &#x441;&#x445;&#x435;&#x43c;&#x430;&#x43c;&#x438; - &#x44d;&#x442;&#x43e; &#x43c;&#x43e;&#x436;&#x435;&#x442; &#x441;&#x438;&#x43b;&#x44c;&#x43d;&#x43e; &#x441;&#x43a;&#x430;&#x437;&#x430;&#x442;&#x44c;&#x441;&#x44f; &#x43d;&#x430; &#x441;&#x432;&#x43e;&#x431;&#x43e;&#x434;&#x43d;&#x43e;&#x439; &#x43f;&#x430;&#x43c;&#x44f;&#x442;&#x438;." ID="ID_1536191735" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x440;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x432;&#x441;&#x435;&#x433;&#x43e;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x443; &quot;&#x420;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x435;&#x442; &#x432;&#x441;&#x435; &#x443;&#x437;&#x43b;&#x44b;&quot; &#x43d;&#x430; &#x433;&#x43b;&#x430;&#x432;&#x43d;&#x43e;&#x439; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x438;, &#x438;&#x43b;&#x438; &#x432; &#x432;&#x44b;&#x43f;&#x430;&#x434;&#x430;&#x44e;&#x449;&#x435;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x423;&#x437;&#x435;&#x43b; &gt; &#x420;&#x430;&#x437;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c; &#x432;&#x441;&#x435;." ID="ID_1826281148" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x441;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x432;&#x441;&#x435;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; &quot;&#x421;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x435;&#x442; &#x432;&#x44b;&#x431;&#x440;&#x430;&#x43d;&#x43d;&#x44b;&#x435; &#x443;&#x437;&#x43b;&#x44b;&quot; &#x43d;&#x430; &#x433;&#x43b;&#x430;&#x432;&#x43d;&#x43e;&#x439; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x438;, &#x438;&#x43b;&#x438; &#x432;&#x44b;&#x43f;&#x430;&#x434;&#x430;&#x44e;&#x449;&#x435;&#x435; &#x43c;&#x435;&#x43d;&#x44e; &#x423;&#x437;&#x435;&#x43b; &gt; &#x421;&#x432;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c; &#x432;&#x441;&#x435;." ID="ID_1536717992" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x420;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x435;&#x43c;&#x44b;&#x435; &#x443;&#x437;&#x43b;&#x44b; &#x43f;&#x43e;&#x43c;&#x435;&#x447;&#x435;&#x43d;&#x44b; &#x43c;&#x430;&#x43b;&#x435;&#x43d;&#x44c;&#x43a;&#x438;&#x43c; &#x43a;&#x440;&#x443;&#x436;&#x43a;&#x43e;&#x43c; &#x441;&#x43e; &#x441;&#x442;&#x43e;&#x440;&#x43e;&#x43d;&#x44b; &#x440;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f;." ID="ID_1586235683" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x41f;&#x435;&#x440;&#x435;&#x43a;&#x43b;&#x44e;&#x447;&#x435;&#x43d;&#x438;&#x435; &#x441;&#x445;&#x435;&#x43c;" FOLDED="true" POSITION="right" ID="ID_1688158787" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x435;&#x440;&#x435;&#x43a;&#x43b;&#x44e;&#x447;&#x435;&#x43d;&#x438;&#x44f; &#x43a; &#x434;&#x440;&#x443;&#x433;&#x43e;&#x439; &#x43e;&#x442;&#x43a;&#x440;&#x44b;&#x442;&#x43e;&#x439; &#x441;&#x445;&#x435;&#x43c;&#x435;, &#x43a;&#x43b;&#x438;&#x43a;&#x43d;&#x438;&#x442;&#x435; &#x43f;&#x440;&#x430;&#x432;&#x43e;&#x439; &#x43a;&#x43d;&#x43e;&#x43f;&#x43a;&#x43e;&#x439; &#x43c;&#x44b;&#x448;&#x438; &#x43d;&#x430; &#x444;&#x43e;&#x43d;&#x435; &#x438; &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x43d;&#x443;&#x436;&#x43d;&#x443;&#x44e; &#x43a;&#x430;&#x440;&#x442;&#x443; &#x438;&#x437; &#x43c;&#x435;&#x43d;&#x44e;." ID="ID_1926873322" CREATED="1465678964180" MODIFIED="1465678964180">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x41f;&#x440;&#x43e;&#x43a;&#x440;&#x443;&#x442;&#x43a;&#x430; &#x441;&#x445;&#x435;&#x43c;&#x44b;" FOLDED="true" POSITION="right" ID="ID_93513736" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43f;&#x440;&#x43e;&#x43a;&#x440;&#x443;&#x442;&#x43a;&#x438; &#x441;&#x445;&#x435;&#x43c; &#x43f;&#x435;&#x440;&#x435;&#x442;&#x430;&#x441;&#x43a;&#x438;&#x432;&#x430;&#x439;&#x442;&#x435; &#x444;&#x43e;&#x43d;, &#x438;&#x43b;&#x438; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43b;&#x435;&#x441;&#x43e; &#x43c;&#x44b;&#x448;&#x438;. &#x414;&#x43b;&#x44f; &#x433;&#x43e;&#x440;&#x438;&#x440;&#x43e;&#x43d;&#x442;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;&#x439; &#x43f;&#x440;&#x43e;&#x43a;&#x440;&#x443;&#x442;&#x43a;&#x438; &#x441; &#x43f;&#x43e;&#x43c;&#x43e;&#x449;&#x44c;&#x44e; &#x43a;&#x43e;&#x43b;&#x435;&#x441;&#x430; &#x43c;&#x44b;&#x448;&#x438;, &#x437;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; shift &#x438;&#x43b;&#x438; &#x43e;&#x434;&#x43d;&#x443; &#x438;&#x437; &#x43a;&#x43d;&#x43e;&#x43f;&#x43e;&#x43a; &#x43d;&#x430; &#x43c;&#x44b;&#x448;&#x438;." ID="ID_699172659" CREATED="1465678964180" MODIFIED="1465678964180">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x41c;&#x430;&#x441;&#x448;&#x442;&#x430;&#x431;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435;" FOLDED="true" POSITION="right" ID="ID_274077691" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x43c;&#x430;&#x441;&#x448;&#x442;&#x430;&#x431;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43a;&#x43e;&#x43b;&#x435;&#x441;&#x43e; &#x43c;&#x44b;&#x448;&#x438; &#x441; &#x437;&#x430;&#x436;&#x430;&#x442;&#x43e;&#x439; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x448;&#x435;&#x439; control, &#x438;&#x43b;&#x438; &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Alt + &#x412;&#x432;&#x435;&#x440;&#x445; &#x438;&#x43b;&#x438; &#x412;&#x43d;&#x438;&#x437;. &#x418;&#x43b;&#x438; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43c;&#x430;&#x441;&#x448;&#x442;&#x430;&#x431;&#x438;&#x440;&#x443;&#x44e;&#x449;&#x443;&#x44e; &#x448;&#x43a;&#x430;&#x43b;&#x443; &#x43d;&#x430; &#x433;&#x43b;&#x430;&#x432;&#x43d;&#x43e;&#x439; &#x43f;&#x430;&#x43d;&#x435;&#x43b;&#x438;." ID="ID_379843404" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x43e;&#x442;&#x43c;&#x435;&#x43d;&#x44b;" FOLDED="true" POSITION="right" ID="ID_1044185006" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x43e;&#x442;&#x43c;&#x435;&#x43d;&#x44b; &#x43f;&#x440;&#x435;&#x434;&#x44b;&#x434;&#x443;&#x449;&#x435;&#x433;&#x43e; &#x434;&#x435;&#x439;&#x441;&#x442;&#x432;&#x438;&#x44f; &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Control + Z, &#x438;&#x43b;&#x438; &#x432; &#x432;&#x44b;&#x43f;&#x430;&#x434;&#x430;&#x44e;&#x449;&#x435;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x41f;&#x440;&#x430;&#x432;&#x43a;&#x430; &gt; &#x41e;&#x442;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x44c;." ID="ID_525053085" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x43e;&#x441;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43b;&#x435;&#x43d;&#x438;&#x44f; (&#x43e;&#x442;&#x43c;&#x435;&#x43d;&#x430; &#x43e;&#x442;&#x43c;&#x435;&#x43d;&#x44b;), &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Control + Y, &#x438;&#x43b;&#x438; &#x432; &#x432;&#x44b;&#x43f;&#x430;&#x434;&#x430;&#x44e;&#x449;&#x435;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x41f;&#x440;&#x430;&#x432;&#x43a;&#x430; &gt; &#x412;&#x435;&#x440;&#x43d;&#x443;&#x442;&#x44c;." ID="ID_1403577904" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x438; &#x43a;&#x43e;&#x43b;&#x438;&#x447;&#x435;&#x441;&#x442;&#x432;&#x430; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x44b;&#x445; &#x43e;&#x442;&#x43c;&#x435;&#x43d;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43c;&#x435;&#x43d;&#x44e; &#x414;&#x43e;&#x43f;&#x43e;&#x43b;&#x43d;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e; &gt; &#x423;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x438;." ID="ID_529234474" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442; &#x432; HTML" FOLDED="true" POSITION="right" ID="ID_1014046754" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x430; &#x432;&#x435;&#x442;&#x432;&#x438; &#x432; HTML, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; Control + H. &#x415;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x43d;&#x430;&#x44f; HTML &#x441;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;&#x430; &#x43c;&#x43e;&#x436;&#x435;&#x442; &#x441;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x442;&#x44c;/&#x440;&#x430;&#x437;&#x432;&#x43e;&#x440;&#x430;&#x447;&#x438;&#x432;&#x430;&#x442;&#x44c; &#x432;&#x435;&#x442;&#x432;&#x438;, &#x435;&#x441;&#x43b;&#x438; &#x44d;&#x442;&#x43e; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43b;&#x435;&#x43d;&#x43e; &#x432; &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x430;&#x445;." ID="ID_1693244393" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x422;&#x430;&#x43a; &#x436;&#x435; &#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x447;&#x435;&#x440;&#x435;&#x437; &#x43c;&#x435;&#x43d;&#x44e;&#xa0;&#x424;&#x430;&#x439;&#x43b; &gt; &#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x41a;&#x430;&#x43a; XHTML (&#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; Javascript)." ID="ID_597556984" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x441;&#x445;&#x435;&#x43c;&#x44b; &#x441; &#x43f;&#x440;&#x43e;&#x441;&#x43c;&#x43e;&#x442;&#x440;&#x43e;&#x43c; &#x43a;&#x430;&#x440;&#x442;&#x438;&#x43d;&#x43e;&#x43a; &#x432; HTML, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x424;&#x430;&#x439;&#x43b; &gt; &#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x41a;&#x430;&#x43a; XHTML (&#x43d;&#x430;&#x432;&#x438;&#x433;&#x430;&#x446;&#x438;&#x44f; &#x441; &#x43a;&#x430;&#x440;&#x442;&#x438;&#x43d;&#x43a;&#x43e;&#x439;)." ID="ID_894590438" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442; &#x432; &#x440;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x432;&#x43e;&#x435; &#x438;&#x43b;&#x438; &#x432;&#x435;&#x43a;&#x442;&#x43e;&#x440;&#x43d;&#x43e;&#x435; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x435;" FOLDED="true" POSITION="right" ID="ID_922982228" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x430; &#x432; PNG &#x43a;&#x430;&#x440;&#x442;&#x438;&#x43d;&#x43a;&#x443;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x424;&#x430;&#x439;&#x43b; &gt; &#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x41a;&#x430;&#x43a; PNG." ID="ID_1866865992" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x430; &#x432; JPEG &#x43a;&#x430;&#x440;&#x442;&#x438;&#x43d;&#x43a;&#x443;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x424;&#x430;&#x439;&#x43b; &gt; &#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x41a;&#x430;&#x43a; JPEG." ID="ID_1359116012" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x430; &#x432; SVG, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x424;&#x430;&#x439;&#x43b; &gt; &#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x41a;&#x430;&#x43a; SVG. &#x42d;&#x442;&#x430; &#x444;&#x443;&#x43d;&#x43a;&#x446;&#x438;&#x44f; &#x434;&#x43e;&#x441;&#x442;&#x443;&#x43f;&#x43d;&#x430; &#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x435;&#x441;&#x43b;&#x438; &#x443; &#x432;&#x430;&#x441; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43b;&#x435;&#x43d;&#x43e; SVG-&#x434;&#x43e;&#x43f;&#x43e;&#x43b;&#x43d;&#x435;&#x43d;&#x438;&#x435;." ID="ID_527337320" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x432; &#x434;&#x440;&#x443;&#x433;&#x438;&#x435; XML &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x44b;" FOLDED="true" POSITION="right" ID="ID_765689910" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<node TEXT="&#x414;&#x43b;&#x44f; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x430; &#x432; &#x434;&#x440;&#x443;&#x433;&#x43e;&#x439; XML &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442; &#x443; &#x432;&#x430;&#x441; &#x435;&#x441;&#x442;&#x44c; &#x43f;&#x440;&#x435;&#x43e;&#x431;&#x440;&#x430;&#x437;&#x443;&#x44e;&#x449;&#x430;&#x44f; XSLT &#x442;&#x430;&#x431;&#x43b;&#x438;&#x446;&#x430;, &#x432; &#x43c;&#x435;&#x43d;&#x44e; &#x424;&#x430;&#x439;&#x43b; &gt; &#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x427;&#x435;&#x440;&#x435;&#x437; XSLT." ID="ID_1386592343" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x430; &#x432; OpenOffice 1.4 Writer &#x434;&#x43e;&#x43a;&#x443;&#x43c;&#x435;&#x43d;&#x442;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x424;&#x430;&#x439;&#x43b; &gt; &#x42d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x41a;&#x430;&#x43a; OpenOffice Writer Document." ID="ID_528451724" CREATED="1465678964180" MODIFIED="1465678964180"/>
</node>
<node TEXT="&#x418;&#x43c;&#x43f;&#x43e;&#x440;&#x442; &#x441;&#x442;&#x440;&#x443;&#x43a;&#x442;&#x443;&#x440;&#x44b; &#x43a;&#x430;&#x442;&#x430;&#x43b;&#x43e;&#x433;&#x43e;&#x432;" FOLDED="true" POSITION="right" ID="ID_1647202362" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#407000">
<font NAME="Dialog" SIZE="12"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x430; &#x441;&#x442;&#x440;&#x443;&#x43a;&#x442;&#x443;&#x440;&#x44b; &#x43a;&#x430;&#x442;&#x430;&#x43b;&#x43e;&#x433;&#x43e;&#x432;, &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x443;&#x437;&#x43b;&#x430; &#x424;&#x430;&#x439;&#x43b; &gt; &#x418;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x418;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x421;&#x442;&#x440;&#x443;&#x43a;&#x442;&#x443;&#x440;&#x443; &#x43a;&#x430;&#x442;&#x430;&#x43b;&#x43e;&#x433;&#x43e;&#x432;. &#x417;&#x430;&#x442;&#x435;&#x43c; &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x43d;&#x435;&#x43e;&#x431;&#x445;&#x43e;&#x434;&#x438;&#x43c;&#x44b;&#x439; &#x43a;&#x430;&#x442;&#x430;&#x43b;&#x43e;&#x433;, &#x447;&#x44c;&#x44e; &#x441;&#x442;&#x440;&#x443;&#x43a;&#x442;&#x443;&#x440;&#x443; &#x432;&#x44b; &#x445;&#x43e;&#x442;&#x438;&#x442;&#x435; &#x438;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c;. &#x41f;&#x43e;&#x434; &#x441;&#x442;&#x440;&#x443;&#x43a;&#x442;&#x443;&#x440;&#x43e;&#x439; &#x43f;&#x43e;&#x434;&#x440;&#x430;&#x437;&#x443;&#x43c;&#x435;&#x432;&#x430;&#x435;&#x442;&#x441;&#x44f; &#x434;&#x435;&#x440;&#x435;&#x432;&#x43e; &#x432;&#x441;&#x435;&#x445; (&#x43d;&#x435; &#x43d;&#x430;&#x43f;&#x440;&#x44f;&#x43c;&#x443;&#x44e;) &#x43f;&#x43e;&#x434;&#x434;&#x438;&#x440;&#x435;&#x43a;&#x442;&#x43e;&#x440;&#x438;&#x439; &#x441; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x430;&#x43c;&#x438; &#x43d;&#x430; &#x444;&#x430;&#x439;&#x43b;&#x44b; &#x44d;&#x442;&#x438;&#x445; &#x43f;&#x43e;&#x434;&#x434;&#x438;&#x440;&#x435;&#x43a;&#x442;&#x43e;&#x440;&#x438;&#x439;. &#x41d;&#x438;&#x436;&#x435; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440;." ID="ID_105033012" CREATED="1465678964180" MODIFIED="1465678964180"/>
<node TEXT="&#x41d;&#x430;&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440;" FOLDED="true" ID="ID_424846874" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x412;&#x44b;&#x431;&#x440;&#x430;&#x43d;&#x43d;&#x430;&#x44f; &#x434;&#x438;&#x440;&#x435;&#x43a;&#x442;&#x43e;&#x440;&#x438;&#x44f;" FOLDED="true" ID="ID_438469712" CREATED="1465678964180" MODIFIED="1465678964180" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps" ID="ID_1400550099" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%2520Files/Microsoft%2520Office/Office/Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Dbwiz" FOLDED="true" ID="ID_334987346" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/">
<node TEXT="ASSETS.GIF" ID="ID_1574236167" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ASSETS.GIF"/>
<node TEXT="CONTACTS.GIF" ID="ID_170882892" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF"/>
<node TEXT="EVTMGMT.GIF" ID="ID_83688689" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF"/>
<node TEXT="EXPENSES.GIF" ID="ID_363195105" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF"/>
<node TEXT="INVENTRY.GIF" ID="ID_438545983" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF"/>
<node TEXT="LEDGER.GIF" ID="ID_841962110" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/LEDGER.GIF"/>
<node TEXT="ORDPROC.GIF" ID="ID_78251551" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF"/>
<node TEXT="RESOURCE.GIF" ID="ID_1075211998" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF"/>
<node TEXT="SERVICE.GIF" ID="ID_1772058328" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/SERVICE.GIF"/>
<node TEXT="TIMEBILL.GIF" ID="ID_556596407" CREATED="1465678964180" MODIFIED="1465678964180" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF"/>
</node>
<node TEXT="Styles" FOLDED="true" ID="ID_462621782" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/">
<node TEXT="ACBLENDS.GIF" ID="ID_74816487" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLENDS.GIF"/>
<node TEXT="ACBLUPRT.GIF" ID="ID_437989461" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLUPRT.GIF"/>
<node TEXT="ACEXPDTN.GIF" ID="ID_1033984292" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACEXPDTN.GIF"/>
<node TEXT="ACINDSTR.GIF" ID="ID_897349824" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACINDSTR.GIF"/>
<node TEXT="ACRICEPR.GIF" ID="ID_1059332571" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACRICEPR.GIF"/>
<node TEXT="ACSNDSTN.GIF" ID="ID_1025661239" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSNDSTN.GIF"/>
<node TEXT="ACSUMIPT.GIF" ID="ID_1531243641" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSUMIPT.GIF"/>
<node TEXT="GLOBE.WMF" ID="ID_876408471" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF"/>
<node TEXT="STONE.BMP" ID="ID_1390883597" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP"/>
</node>
</node>
</node>
<node TEXT="&#x418;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x437;&#x430;&#x43a;&#x43b;&#x430;&#x434;&#x43e;&#x43a; &#x438;&#x437; Internet Explorer" FOLDED="true" POSITION="right" ID="ID_223016620" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x437;&#x430;&#x43a;&#x43b;&#x430;&#x434;&#x43e;&#x43a; Internet Explorer &#x432; Freeplane, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x424;&#x430;&#x439;&#x43b; &gt; &#x418;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x417;&#x430;&#x43a;&#x43b;&#x430;&#x434;&#x43a;&#x438; &#x438;&#x437; IE. &#x417;&#x430;&#x442;&#x435;&#x43c; &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x434;&#x438;&#x440;&#x435;&#x43a;&#x442;&#x43e;&#x440;&#x438;&#x44e;, &#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x430;&#x449;&#x443;&#x44e; &#x44d;&#x442;&#x438; &#x437;&#x430;&#x43a;&#x43b;&#x430;&#x434;&#x43a;&#x438;. &#x418;&#x43c;&#x44f; &#x434;&#x438;&#x440;&#x435;&#x43a;&#x442;&#x43e;&#x440;&#x438;&#x438; &quot;&#x418;&#x437;&#x431;&#x440;&#x430;&#x43d;&#x43d;&#x43e;&#x435;&quot; &#x438; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x43d;&#x430;&#x439;&#x442;&#x438; &#x435;&#x435; &#x43d;&#x430; &#x434;&#x438;&#x441;&#x43a;&#x435;. &#x412; Windows 2000, &#x43e;&#x43d;&#x430; &#x43d;&#x430;&#x445;&#x43e;&#x434;&#x438;&#x442;&#x441;&#x44f; &#x432; C:\Documents and Settings\&lt;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x435;&#x43b;&#x44c;&gt;\&#x418;&#x437;&#x431;&#x440;&#x430;&#x43d;&#x43d;&#x43e;&#x435;." ID="ID_1669229241" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x41a;&#x43b;&#x44e;&#x447;&#x435;&#x432;&#x44b;&#x435; &#x441;&#x43b;&#x43e;&#x432;&#x430;: Microsoft Internet Explorer, MSIE, MS IE." ID="ID_1550525996" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="&#x418;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x441;&#x445;&#x435;&#x43c; MindManager X5" FOLDED="true" POSITION="right" ID="ID_1133154339" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#407000">
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x438;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x443; &#x438;&#x437; MindManager X5 &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x424;&#x430;&#x439;&#x43b; &gt; &#x418;&#x43c;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &gt; &#x41a;&#x430;&#x440;&#x442;&#x430; &#x434;&#x43b;&#x44f; MindManager X5." ID="ID_1423080550" CREATED="1465678964195" MODIFIED="1465678964195"/>
</node>
<node TEXT="&#x418;&#x43d;&#x442;&#x435;&#x433;&#x440;&#x430;&#x446;&#x438;&#x44f; &#x441; Word &#x438;&#x43b;&#x438; Outlook" FOLDED="true" POSITION="right" ID="ID_1343231908" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x44b; &#x438;&#x43b;&#x438; &#x432;&#x435;&#x442;&#x432;&#x438; &#x432; Microsoft Word, Wordpad &#x438;&#x43b;&#x438; Outlook. &#x412;&#x43e;&#x431;&#x449;&#x435;, &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x442;&#x44c; &#x438;&#x445; &#x432; &#x43b;&#x44e;&#x431;&#x43e;&#x435; &#x43f;&#x440;&#x438;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x435;, &#x443;&#x43c;&#x435;&#x44e;&#x449;&#x435;&#x435; &#x440;&#x430;&#x431;&#x43e;&#x442;&#x430;&#x442;&#x44c; &#x441; &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x43e;&#x43c; Rich Text. &#x424;&#x43e;&#x440;&#x43c;&#x430;&#x442; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x430; &#x438; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x442;&#x430;&#x43a; &#x436;&#x435; &#x441;&#x43e;&#x445;&#x440;&#x430;&#x43d;&#x44f;&#x44e;&#x442;&#x441;&#x44f;." ID="ID_596063748" CREATED="1465678964195" MODIFIED="1465678964195">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x41d;&#x430;&#x436;&#x430;&#x442;&#x438;&#x435; &#x43d;&#x430; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x435; (mailto:don.bonton@supermail.com) &#x43e;&#x442;&#x43a;&#x440;&#x43e;&#x435;&#x442; Outlook &#x434;&#x43b;&#x44f; &#x43d;&#x430;&#x43f;&#x438;&#x441;&#x430;&#x43d;&#x438;&#x44f; &#x43d;&#x43e;&#x432;&#x43e;&#x433;&#x43e; &#x43f;&#x438;&#x441;&#x44c;&#x43c;&#x430;, &#x435;&#x441;&#x43b;&#x438; &#x432; Windows &#x43d;&#x435; &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43b;&#x435;&#x43d;&#x43e; &#x43f;&#x43e;-&#x434;&#x440;&#x443;&#x433;&#x43e;&#x43c;&#x443;." ID="ID_1848123271" CREATED="1465678964195" MODIFIED="1465678964195" LINK="mailto:don.bonton@supermail.com">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x443;&#x43a;&#x430;&#x437;&#x44b;&#x432;&#x430;&#x442;&#x44c; &#x422;&#x435;&#x43c;&#x443; &#x43f;&#x438;&#x441;&#x44c;&#x43c;&#x430; &#x432; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x435;." ID="ID_313789469" CREATED="1465678964195" MODIFIED="1465678964195" LINK="mailto:don.bonton@supermail.com?subject=Last%20phone%20call"/>
<node TEXT="&#x422;&#x430;&#x43a; &#x436;&#x435; &#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x44b; &#x432; Microsoft Word, &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x443;&#x44f; &#x432;&#x43d;&#x430;&#x447;&#x430;&#x43b;&#x435; &#x432; HTML, &#x430; &#x437;&#x430;&#x442;&#x435;&#x43c; &#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x443;&#x44f; HTML &#x438; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x44f; &#x432; Word." ID="ID_27742894" CREATED="1465678964195" MODIFIED="1465678964195"/>
</node>
<node TEXT="&#x41d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x438;" FOLDED="true" POSITION="right" ID="ID_1635526328" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x44f; &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x435;&#x43a;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x414;&#x43e;&#x43f;&#x43e;&#x43b;&#x43d;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e; &gt; &#x423;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x438;. &#x411;&#x43e;&#x43b;&#x44c;&#x448;&#x438;&#x43d;&#x441;&#x442;&#x432;&#x43e; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x438;&#x439; &#x431;&#x443;&#x434;&#x443;&#x442; &#x43f;&#x440;&#x438;&#x43c;&#x435;&#x43d;&#x435;&#x43d;&#x44b; &#x442;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x43f;&#x43e;&#x441;&#x43b;&#x435; &#x43f;&#x435;&#x440;&#x435;&#x437;&#x430;&#x43f;&#x443;&#x441;&#x43a;&#x430; Freeplane." ID="ID_778041678" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x41d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x438; &#x432;&#x43a;&#x43b;&#x44e;&#x447;&#x430;&#x44e;&#x442; &#x432; &#x441;&#x435;&#x431;&#x44f; &#x43d;&#x430;&#x437;&#x43d;&#x430;&#x447;&#x435;&#x43d;&#x438;&#x435; &#x43a;&#x43e;&#x43c;&#x431;&#x438;&#x43d;&#x430;&#x446;&#x438;&#x439; &#x43a;&#x43b;&#x430;&#x432;&#x438;&#x448;&#x44c;, &#x43a;&#x440;&#x43e;&#x43c;&#x435; &#x442;&#x43e;&#x433;&#x43e; &#x434;&#x43b;&#x44f; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438; &#x432; HTML, &#x441;&#x43f;&#x43e;&#x441;&#x43e;&#x431; &#x432;&#x44b;&#x431;&#x43e;&#x440;&#x430; &#x443;&#x437;&#x43b;&#x43e;&#x432; &#x43c;&#x44b;&#x448;&#x44c;&#x44e;, &#x442;&#x438;&#x43f; &#x441;&#x433;&#x43b;&#x430;&#x436;&#x438;&#x432;&#x430;&#x43d;&#x438;&#x44f;, &#x438; &#x43c;&#x43d;&#x43e;&#x433;&#x43e;&#x435; &#x434;&#x440;&#x443;&#x433;&#x43e;&#x435;." ID="ID_722659673" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x41a;&#x43b;&#x44e;&#x447;&#x435;&#x432;&#x44b;&#x435; &#x441;&#x43b;&#x43e;&#x432;&#x430;: &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x439;&#x43a;&#x430;." ID="ID_300630522" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="&#x41f;&#x435;&#x447;&#x430;&#x442;&#x44c;" FOLDED="true" POSITION="right" ID="ID_1728532684" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x43a;&#x430;&#x43a; &#x440;&#x430;&#x441;&#x43f;&#x435;&#x447;&#x430;&#x442;&#x430;&#x442;&#x44c; &#x432;&#x441;&#x44e; &#x441;&#x445;&#x435;&#x43c;&#x443; &#x43d;&#x430; &#x43e;&#x434;&#x43d;&#x43e;&#x43c; &#x43b;&#x438;&#x441;&#x442;&#x435;, &#x442;&#x430;&#x43a; &#x438; &#x43d;&#x430; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x438;&#x445; &#x43b;&#x438;&#x441;&#x442;&#x430;&#x445; &#x431;&#x443;&#x43c;&#x430;&#x433;&#x438;. &#x42d;&#x442;&#x43e; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x43d;&#x430;&#x441;&#x442;&#x440;&#x43e;&#x438;&#x442;&#x44c; &#x432; &#x43c;&#x435;&#x43d;&#x44e;: &#x424;&#x430;&#x439;&#x43b; &gt; &#x41f;&#x430;&#x440;&#x430;&#x43c;&#x435;&#x442;&#x440;&#x44b; &#x421;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;&#x44b; &gt; ... ." ID="ID_1404046793" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x43b;&#x443;&#x447;&#x448;&#x435;&#x433;&#x43e; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x43f;&#x440;&#x43e;&#x441;&#x442;&#x440;&#x430;&#x43d;&#x441;&#x442;&#x432;&#x430;, &#x443;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x438;&#x442;&#x435; &#x43c;&#x430;&#x441;&#x448;&#x442;&#x430;&#x431; &#x432; &#x41f;&#x430;&#x440;&#x430;&#x43c;&#x435;&#x442;&#x440;&#x430;&#x445; &#x421;&#x442;&#x440;&#x430;&#x43d;&#x438;&#x446;&#x44b;." ID="ID_1309888466" CREATED="1465678964195" MODIFIED="1465678964195">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x41d;&#x435; &#x43e;&#x431;&#x44f;&#x437;&#x430;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x43f;&#x440;&#x435;&#x434;&#x43f;&#x440;&#x43e;&#x441;&#x43c;&#x43e;&#x442;&#x440; &#x441;&#x445;&#x435;&#x43c;&#x44b; &#x43f;&#x435;&#x440;&#x435;&#x434; &#x43f;&#x435;&#x447;&#x430;&#x442;&#x44c;&#x44e;. &#x415;&#x441;&#x43b;&#x438; &#x443; &#x432;&#x430;&#x441; postscript-&#x43f;&#x440;&#x438;&#x43d;&#x442;&#x435;&#x440; &#x438;&#x43b;&#x438; &#x43e;&#x431;&#x44b;&#x447;&#x43d;&#x44b;&#x439; postsript-&#x434;&#x440;&#x430;&#x439;&#x432;&#x435;&#x440;, &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x440;&#x430;&#x441;&#x43f;&#x435;&#x447;&#x430;&#x442;&#x430;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x443; &#x432; &#x444;&#x430;&#x439;&#x43b; &#x438; &#x43f;&#x43e;&#x441;&#x43c;&#x43e;&#x442;&#x440;&#x435;&#x442;&#x44c; postscript-&#x444;&#x430;&#x439;&#x43b; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x44f; Ghostview &#x438;&#x43b;&#x438; &#x43f;&#x43e;&#x434;&#x43e;&#x431;&#x43d;&#x443;&#x44e; &#x43f;&#x440;&#x43e;&#x433;&#x440;&#x430;&#x43c;&#x43c;&#x443;. &#x415;&#x441;&#x43b;&#x438; &#x432;&#x44b; &#x43f;&#x43e;&#x43f;&#x44b;&#x442;&#x430;&#x435;&#x442;&#x435;&#x441;&#x44c; &#x440;&#x430;&#x441;&#x43f;&#x435;&#x447;&#x430;&#x442;&#x430;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x443; &#x43d;&#x430; &#x43f;&#x440;&#x438;&#x43d;&#x442;&#x435;&#x440;&#x435;, &#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x439; &#x43d;&#x435; &#x43f;&#x43e;&#x434;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x435;&#x442; postscript, &#x440;&#x435;&#x437;&#x443;&#x43b;&#x44c;&#x442;&#x438;&#x440;&#x443;&#x44e;&#x449;&#x438;&#x439; &#x444;&#x430;&#x439;&#x43b; &#x43d;&#x435; &#x431;&#x443;&#x434;&#x435;&#x442; postscript-&#x434;&#x43e;&#x43a;&#x443;&#x43c;&#x435;&#x43d;&#x442;&#x43e;&#x43c;, &#x430; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e; &#x431;&#x443;&#x434;&#x435;&#x442; PCL, &#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x439; &#x434;&#x43b;&#x44f; &#x432;&#x430;&#x441; &#x431;&#x435;&#x441;&#x43f;&#x43e;&#x43b;&#x435;&#x437;&#x435;&#x43d;." ID="ID_1408996119" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x422;&#x430;&#x43a; &#x436;&#x435; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x440;&#x430;&#x441;&#x43f;&#x435;&#x447;&#x430;&#x442;&#x430;&#x442;&#x44c; &#x447;&#x435;&#x440;&#x435;&#x437; &#x432;&#x430;&#x448; &#x431;&#x440;&#x430;&#x443;&#x437;&#x435;&#x440; &#x43f;&#x43e;&#x441;&#x43b;&#x435; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x430; &#x441;&#x445;&#x435;&#x43c;&#x44b; &#x432; HTML, &#x438;&#x43b;&#x438; &#x447;&#x435;&#x440;&#x435;&#x437; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x43e;&#x432;&#x44b;&#x439; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440;, &#x441;&#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x432; &#x432; &#x43d;&#x435;&#x433;&#x43e; &#x441;&#x445;&#x435;&#x43c;&#x443;. &#x422;&#x430;&#x43a; &#x436;&#x435; &#x432;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x441;&#x445;&#x435;&#x43c;&#x443; &#x432; HTML &#x441; &#x437;&#x430;&#x433;&#x43e;&#x43b;&#x43e;&#x432;&#x43a;&#x430;&#x43c;&#x438;, &#x441;&#x43a;&#x43e;&#x43f;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x440;&#x435;&#x437;&#x443;&#x43b;&#x44c;&#x442;&#x430;&#x442; &#x432; &#x43b;&#x44e;&#x431;&#x438;&#x43c;&#x44b;&#x439; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x43e;&#x432;&#x44b;&#x439; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x43e;&#x440; &#x438; &#x440;&#x430;&#x441;&#x43f;&#x435;&#x447;&#x430;&#x442;&#x430;&#x442;&#x44c; &#x43e;&#x442;&#x442;&#x443;&#x434;&#x430;. &#x422;&#x430;&#x43a; &#x432;&#x44b; &#x441;&#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x435;&#x449;&#x435; &#x438; &#x438;&#x437;&#x43c;&#x435;&#x43d;&#x44f;&#x442;&#x44c; &#x441;&#x442;&#x438;&#x43b;&#x438; &#x442;&#x435;&#x43a;&#x441;&#x442;&#x430;." ID="ID_665468361" CREATED="1465678964195" MODIFIED="1465678964195">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x430; Rich Text &#x43a;&#x430;&#x43a; HTML" FOLDED="true" POSITION="right" ID="ID_998601629" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#407000">
<node TEXT="&#x423;&#x437;&#x43b;&#x44b;, &#x43d;&#x430;&#x447;&#x438;&#x43d;&#x430;&#x44e;&#x449;&#x438;&#x435;&#x441;&#x44f; &#x441; &lt;html&gt; &#x43e;&#x431;&#x440;&#x430;&#x431;&#x430;&#x442;&#x44b;&#x432;&#x430;&#x44e;&#x442;&#x441;&#x44f; &#x43a;&#x430;&#x43a; &#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x430;&#x449;&#x438;&#x435; HTML-&#x43a;&#x43e;&#x434;. &#x42d;&#x442;&#x43e; &#x43e;&#x447;&#x435;&#x43d;&#x44c; &#x43f;&#x43e;&#x43b;&#x435;&#x437;&#x43d;&#x43e; &#x434;&#x43b;&#x44f; &#x441;&#x43e;&#x437;&#x434;&#x430;&#x43d;&#x438;&#x44f; &#x441;&#x43f;&#x435;&#x446;&#x438;&#x430;&#x43b;&#x438;&#x437;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x43d;&#x44b;&#x445; &#x443;&#x437;&#x43b;&#x43e;&#x432;. &#x41f;&#x440;&#x438;&#x43c;&#x435;&#x440;&#x44b; &#x434;&#x430;&#x43b;&#x435;&#x435;." ID="ID_1643366152" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;h3&gt;&#xa;      &amp;#1055;&amp;#1088;&amp;#1080;&amp;#1084;&amp;#1077;&amp;#1088; HTML&#xa;    &lt;/h3&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      &amp;#1042;&amp;#1086;&amp;#1090; &amp;#1089;&amp;#1087;&amp;#1080;&amp;#1089;&amp;#1086;&amp;#1082; &amp;#1086;&amp;#1073;&amp;#1098;&amp;#1077;&amp;#1082;&amp;#1090;&amp;#1086;&amp;#1074;:&#xa;    &lt;/p&gt;&#xa;    &lt;ul type=&quot;disc&quot;&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;        &amp;#1054;&amp;#1073;&amp;#1098;&amp;#1077;&amp;#1082;&amp;#1090; &amp;#1086;&amp;#1076;&amp;#1080;&amp;#1085;&#xa;      &lt;/li&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;        &amp;#1054;&amp;#1073;&amp;#1098;&amp;#1077;&amp;#1082;&amp;#1090; &amp;#1076;&amp;#1074;&amp;#1072;&#xa;      &lt;/li&gt;&#xa;    &lt;/ul&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      &amp;#1040; &amp;#1090;&amp;#1091;&amp;#1090; &amp;#1091; &amp;#1085;&amp;#1072;&amp;#1089; &lt;b&gt;&amp;#1078;&amp;#1080;&amp;#1088;&amp;#1085;&amp;#1099;&amp;#1081; &amp;#1096;&amp;#1088;&amp;#1080;&amp;#1092;&amp;#1090;&lt;/b&gt;&amp;#160;&amp;#1080;&amp;#1083;&amp;#1080; &lt;i&gt;&amp;#1085;&amp;#1072;&amp;#1082;&amp;#1083;&amp;#1086;&amp;#1085;&amp;#1085;&amp;#1099;&amp;#1081;&lt;/i&gt;. &lt;u&gt;&amp;#1055;&amp;#1086;&amp;#1076;&amp;#1095;&amp;#1077;&amp;#1088;&amp;#1082;&amp;#1085;&amp;#1091;&amp;#1090;&amp;#1099;&amp;#1081;&lt;/u&gt;&amp;#160; &amp;#1072; &amp;#1090;&amp;#1072;&amp;#1082; &amp;#1078;&amp;#1077; &lt;strike&gt;&amp;#1079;&amp;#1072;&amp;#1095;&amp;#1077;&amp;#1088;&amp;#1082;&amp;#1085;&amp;#1091;&amp;#1090;&amp;#1099;&amp;#1081;&lt;/strike&gt;. &amp;#1040; &amp;#1084;&amp;#1086;&amp;#1078;&amp;#1085;&amp;#1086; &amp;#1080;&amp;#1089;&amp;#1087;&amp;#1086;&amp;#1083;&amp;#1100;&amp;#1079;&amp;#1086;&amp;#1074;&amp;#1072;&amp;#1090;&amp;#1100; &amp;#1090;&amp;#1072;&amp;#1073;&amp;#1083;&amp;#1080;&amp;#1094;&amp;#1099;:&#xa;    &lt;/p&gt;&#xa;    &lt;table border=&quot;1&quot; style=&quot;border: none&quot; class=&quot;msonormaltable&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot;&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;padding-top: .75pt; padding-left: .75pt; padding-right: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            &amp;#1071;&amp;#1095;&amp;#1077;&amp;#1081;&amp;#1082;&amp;#1072;1&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border-left: none; padding-top: .75pt; padding-left: .75pt; padding-right: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            &amp;#1071;&amp;#1095;&amp;#1077;&amp;#1081;&amp;#1082;&amp;#1072;2&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;padding-top: .75pt; border-top: none; padding-left: .75pt; padding-right: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            &amp;#1071;&amp;#1095;&amp;#1077;&amp;#1081;&amp;#1082;&amp;#1072;3&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border-bottom: solid windowtext 1.0pt; border-left: none; padding-top: .75pt; border-top: none; padding-left: .75pt; border-right: solid windowtext 1.0pt; padding-right: .75pt; padding-bottom: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            &amp;#1071;&amp;#1095;&amp;#1077;&amp;#1081;&amp;#1082;&amp;#1072;4.&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;    &lt;/table&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      &amp;#160;&amp;#1058;&amp;#1072;&amp;#1082; &amp;#1078;&amp;#1077; &amp;#1084;&amp;#1086;&amp;#1078;&amp;#1085;&amp;#1086; &amp;#1080;&amp;#1089;&amp;#1087;&amp;#1086;&amp;#1083;&amp;#1100;&amp;#1079;&amp;#1086;&amp;#1074;&amp;#1072;&amp;#1090;&amp;#1100; &lt;font color=&quot;#ff0099&quot;&gt;&amp;#1088;&amp;#1072;&amp;#1079;&amp;#1083;&amp;#1080;&amp;#1095;&amp;#1085;&amp;#1099;&amp;#1077;&lt;/font&gt;&amp;#160; &lt;font color=&quot;#999900&quot;&gt;&amp;#1094;&amp;#1074;&amp;#1077;&amp;#1090;&amp;#1072;&lt;/font&gt;&amp;#160; &lt;font color=&quot;#336600&quot;&gt;&amp;#1090;&amp;#1077;&amp;#1082;&amp;#1089;&amp;#1090;&amp;#1072;&lt;/font&gt;.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1805321159" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x41f;&#x440;&#x438; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x438; &#x443;&#x437;&#x43b;&#x43e;&#x432; &#x438; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x439; &#x432; &#x442;&#x435;&#x43a;&#x441;&#x442; &#x438;&#x43b;&#x438; RTF &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;, &#x43d;&#x435;&#x43b;&#x44c;&#x437;&#x44f; &#x441;&#x43e;&#x445;&#x440;&#x430;&#x43d;&#x438;&#x442;&#x44c; HTML-&#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x430;&#x43d;&#x438;&#x435;. &#x41d;&#x43e; &#x432;&#x441;&#x435; &#x436;&#x435;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; HTML &#x43e;&#x447;&#x435;&#x43d;&#x44c; &#x443;&#x434;&#x43e;&#x431;&#x43d;&#x43e; &#x434;&#x43b;&#x44f; &#x43f;&#x443;&#x431;&#x43b;&#x438;&#x43a;&#x430;&#x446;&#x438;&#x439; &#x432; &#x441;&#x435;&#x442;&#x438;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x44f; Freeplane&apos;s Applet." ID="ID_197071158" CREATED="1465678964195" MODIFIED="1465678964195">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x439; &#x432; &#x443;&#x437;&#x43b;&#x430;&#x445;" FOLDED="true" POSITION="right" ID="ID_767738462" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x438; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x44f; &#x432; Freeplane, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; ALT + SHIFT + K, &#x438;&#x43b;&#x438; &#x432; &#x43a;&#x43e;&#x43d;&#x442;&#x435;&#x43a;&#x441;&#x442;&#x43d;&#x43e;&#x43c; &#x43c;&#x435;&#x43d;&#x44e; &#x443;&#x437;&#x43b;&#x430; &#x412;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x430; &gt; &#x418;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x435;. &#x41f;&#x440;&#x438; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x435; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x44f; &#x432;&#x435;&#x441;&#x44c; &#x442;&#x435;&#x43a;&#x441;&#x442; &#x43d;&#x430;&#x445;&#x43e;&#x434;&#x44f;&#x449;&#x438;&#x439;&#x441;&#x44f; &#x432; &#x443;&#x437;&#x43b;&#x435; &#x43f;&#x440;&#x43e;&#x43f;&#x430;&#x434;&#x435;&#x442;. &#x418;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x44f; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x435;&#x43d;&#x43d;&#x44b;&#x435; &#x442;&#x430;&#x43a;&#x438;&#x43c; &#x441;&#x43f;&#x43e;&#x441;&#x43e;&#x431;&#x43e;&#x43c; &#x432; &#x43f;&#x43e;&#x441;&#x43b;&#x435;&#x434;&#x441;&#x442;&#x432;&#x438;&#x438; &#x43d;&#x435; &#x43a;&#x43e;&#x440;&#x440;&#x435;&#x43a;&#x442;&#x43d;&#x43e; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x44e;&#x442;&#x441;&#x44f; &#x432; &#x434;&#x440;&#x443;&#x433;&#x438;&#x435; &#x43f;&#x440;&#x438;&#x43b;&#x43e;&#x436;&#x435;&#x43d;&#x438;&#x44f; &#x438;&#x437;&#xa0;&#xa0;Freeplane &#x438; &#x43c;&#x43e;&#x433;&#x443;&#x442; &#x43d;&#x435;&#x432;&#x435;&#x440;&#x43d;&#x43e; &#x44d;&#x43a;&#x441;&#x43f;&#x43e;&#x440;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c;&#x441;&#x44f; &#x432; HTML. &#x418;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x44f; &#x432; Freeplane &#x43f;&#x43e;&#x43a;&#x430; &#x435;&#x449;&#x435; &#x43f;&#x440;&#x43e;&#x431;&#x43d;&#x430;&#x44f; &#x432;&#x43e;&#x437;&#x43c;&#x43e;&#x436;&#x43d;&#x43e;&#x441;&#x442;&#x44c;." ID="ID_983939308" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x41f;&#x43e;&#x434;&#x434;&#x435;&#x440;&#x436;&#x438;&#x432;&#x430;&#x435;&#x43c;&#x44b;&#x435; &#x444;&#x43e;&#x440;&#x43c;&#x430;&#x442;&#x44b; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x439;: PNG, JPEG &#x438; GIF." ID="ID_228253145" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x414;&#x43b;&#x44f; &#x442;&#x43e;&#x433;&#x43e;, &#x447;&#x442;&#x43e;&#x431;&#x44b; &#x43d;&#x430; &#x43c;&#x435;&#x441;&#x442;&#x435; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x43d;&#x430; &#x444;&#x430;&#x439;&#x43b; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x44f; &#x43f;&#x43e;&#x44f;&#x432;&#x438;&#x43b;&#x43e;&#x441;&#x44c; &#x44d;&#x442;&#x43e; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x435;, &#x43d;&#x430;&#x436;&#x43c;&#x438;&#x442;&#x435; ALT + SHIFT + K. &#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x441;&#x434;&#x435;&#x43b;&#x430;&#x442;&#x44c; &#x44d;&#x442;&#x43e; &#x438; &#x441; &#x43c;&#x43d;&#x43e;&#x436;&#x435;&#x441;&#x442;&#x432;&#x43e;&#x43c; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x439; &#x432; Freeplane, &#x432;&#x44b;&#x431;&#x435;&#x440;&#x438;&#x442;&#x435; &#x438;&#x445; &#x43a;&#x430;&#x43a; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x443;&#x437;&#x43b;&#x43e;&#x432;, &#x438; &#x437;&#x430;&#x43c;&#x435;&#x43d;&#x438;&#x442;&#x435; &#x43d;&#x430; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x44f;, &#x43d;&#x430;&#x436;&#x430;&#x432; ALT + SHIFT + K." ID="ID_1786538410" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x415;&#x441;&#x442;&#x44c; &#x442;&#x430;&#x43a; &#x436;&#x435; &#x431;&#x43e;&#x43b;&#x435;&#x435; &#x441;&#x43b;&#x43e;&#x436;&#x43d;&#x44b;&#x439; &#x438; &#x43d;&#x435; &#x43e;&#x447;&#x435;&#x43d;&#x44c; &#x434;&#x440;&#x443;&#x436;&#x435;&#x43b;&#x44e;&#x431;&#x43d;&#x44b;&#x439; &#x441;&#x43f;&#x43e;&#x441;&#x43e;&#x431; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43a;&#x438; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x439;. &#x41c;&#x43e;&#x436;&#x43d;&#x43e; &#x432;&#x43a;&#x43b;&#x44e;&#x447;&#x430;&#x442;&#x44c; HTML-&#x43a;&#x43e;&#x434; &#x432; &#x443;&#x437;&#x43b;&#x44b;. &#x41d;&#x430;&#x447;&#x43d;&#x438;&#x442;&#x435; &#x441;&#x43e;&#x434;&#x435;&#x440;&#x436;&#x430;&#x43d;&#x438;&#x435; &#x443;&#x437;&#x43b;&#x430; &#x442;&#x435;&#x433;&#x43e;&#x43c; &lt;html&gt;. &#x422;&#x430;&#x43a;&#x438;&#x43c; &#x43e;&#x431;&#x440;&#x430;&#x437;&#x43e;&#x43c; &#x432;&#x44b; &#x442;&#x430;&#x43a;&#x436;&#x435; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x432;&#x441;&#x442;&#x430;&#x432;&#x43b;&#x44f;&#x442;&#x44c; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x44f; &#x432; &#x443;&#x437;&#x43b;&#x44b;." ID="ID_652814150" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#000000">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x41d;&#x430;&#x43f;&#x440;&#x438;&#x43c;&#x435;&#x440;:&#xa;&#xa0;&#xa0;&lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;&#xa;&#xa0;&#xa0;&lt;html&gt;&lt;img src=&quot;file://C:/Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;" ID="ID_1280228397" CREATED="1465678964195" MODIFIED="1465678964195">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x412;&#x44b; &#x43c;&#x43e;&#x436;&#x435;&#x442;&#x435; &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x43e;&#x442;&#x43d;&#x43e;&#x441;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x44b;&#x435; &#x441;&#x441;&#x44b;&#x43b;&#x43a;&#x438; &#x43d;&#x430; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x44f;." ID="ID_589868865" CREATED="1465678964195" MODIFIED="1465678964195">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&#x41f;&#x440;&#x438;&#x43c;&#x435;&#x440; &#x438;&#x437;&#x43e;&#x431;&#x440;&#x430;&#x436;&#x435;&#x43d;&#x438;&#x439;, &#x440;&#x430;&#x431;&#x43e;&#x442;&#x430;&#x44e;&#x449;&#x438;&#x439; &#x432; &#x43d;&#x435;&#x43a;&#x43e;&#x442;&#x43e;&#x440;&#x44b;&#x445; Windows &#x441;&#x438;&#x441;&#x442;&#x435;&#x43c;&#x430;&#x445;" FOLDED="true" ID="ID_74102619" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#996600">
<font NAME="SansSerif" SIZE="12" BOLD="true"/>
<node TEXT="" ID="ID_884410160" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="" ID="ID_1944046862" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="" FOLDED="true" ID="ID_215361400" CREATED="1465678964195" MODIFIED="1465678964195">
<node TEXT="" ID="ID_677559880" CREATED="1465678964195" MODIFIED="1465678964195"/>
</node>
<node TEXT="" FOLDED="true" ID="ID_1388835604" CREATED="1465678964195" MODIFIED="1465678964195">
<node TEXT="" FOLDED="true" ID="ID_1229848914" CREATED="1465678964195" MODIFIED="1465678964195">
<node TEXT="" ID="ID_1434526097" CREATED="1465678964195" MODIFIED="1465678964195"/>
</node>
</node>
<node TEXT="GLOBE.WMF" ID="ID_1184290937" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF"/>
<node TEXT="STONE.BMP" ID="ID_669329949" CREATED="1465678964195" MODIFIED="1465678964195" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP"/>
</node>
</node>
<node TEXT="&#x418;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x435; &#x442;&#x435;&#x441;&#x442;&#x43e;&#x432;&#x43e;&#x433;&#x43e; &#x431;&#x43b;&#x43e;&#x43a;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432;" FOLDED="true" POSITION="right" ID="ID_196430163" CREATED="1465678964195" MODIFIED="1465678964195" COLOR="#407000">
<node TEXT="&#x422;&#x435;&#x43a;&#x443;&#x449;&#x430;&#x44f; &#x432;&#x435;&#x440;&#x441;&#x438;&#x44f; Freeplane &#x438;&#x43c;&#x435;&#x435;&#x442; &#x44d;&#x43a;&#x441;&#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x442;&#x430;&#x43b;&#x44c;&#x43d;&#x443;&#x44e; &#x43e;&#x43f;&#x446;&#x438;&#x44e; &#x431;&#x43b;&#x43e;&#x43a;&#x438;&#x440;&#x43e;&#x432;&#x43a;&#x438; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432;, &#x43f;&#x43e;-&#x443;&#x43c;&#x43e;&#x43b;&#x447;&#x430;&#x43d;&#x438;&#x44e; &#x43e;&#x442;&#x43a;&#x43b;&#x44e;&#x447;&#x435;&#x43d;&#x43d;&#x443;&#x44e;. &#x422;&#x435;&#x43a;&#x443;&#x449;&#x430;&#x44f; &#x440;&#x435;&#x430;&#x43b;&#x438;&#x437;&#x430;&#x446;&#x438;&#x44f; &#x43d;&#x435; &#x43f;&#x440;&#x435;&#x434;&#x43e;&#x442;&#x432;&#x440;&#x430;&#x449;&#x430;&#x435;&#x442; &#x43e;&#x431;&#x440;&#x430;&#x449;&#x435;&#x43d;&#x438;&#x44f; &#x43a; &#x444;&#x430;&#x439;&#x43b;&#x430;&#x43c; &#x438;&#x434;&#x435;&#x430;&#x43b;&#x44c;&#x43d;&#x43e;, &#x43d;&#x43e; &#x44d;&#x442;&#x43e;&#x433;&#x43e; &#x434;&#x43e;&#x43b;&#x436;&#x43d;&#x43e; &#x431;&#x44b;&#x442;&#x44c; &#x434;&#x43e;&#x441;&#x442;&#x430;&#x442;&#x43e;&#x447;&#x43d;&#x43e; &#x434;&#x43b;&#x44f; &#x431;&#x43e;&#x43b;&#x44c;&#x448;&#x438;&#x43d;&#x441;&#x442;&#x432;&#x430; &#x43f;&#x440;&#x430;&#x43a;&#x442;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438;&#x445; &#x437;&#x430;&#x434;&#x430;&#x447;." ID="ID_254674138" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x411;&#x43b;&#x43e;&#x43a;&#x438;&#x440;&#x43e;&#x432;&#x43a;&#x430; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; &#x433;&#x430;&#x440;&#x430;&#x43d;&#x442;&#x438;&#x440;&#x443;&#x435;&#x442; &#x447;&#x442;&#x43e; &#x43d;&#x435;&#x441;&#x43a;&#x43e;&#x43b;&#x44c;&#x43a;&#x43e; &#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x43e;&#x432;&#x430;&#x442;&#x435;&#x43b;&#x435;&#x439; &#x43d;&#x435; &#x441;&#x43c;&#x43e;&#x433;&#x443;&#x442; &#x43e;&#x434;&#x43d;&#x43e;&#x432;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x43d;&#x43e; &#x440;&#x435;&#x434;&#x430;&#x43a;&#x442;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x43e;&#x434;&#x43d;&#x443; &#x438; &#x442;&#x443; &#x436;&#x435; &#x441;&#x445;&#x435;&#x43c;&#x443;, &#x43f;&#x440;&#x435;&#x434;&#x43e;&#x442;&#x432;&#x440;&#x430;&#x449;&#x430;&#x44f; &#x441;&#x43b;&#x443;&#x447;&#x430;&#x439;&#x43d;&#x43e;&#x435; &#x43f;&#x435;&#x440;&#x435;&#x437;&#x430;&#x43f;&#x438;&#x441;&#x44b;&#x432;&#x430;&#x435;&#x43d;&#x438;&#x435; &#x438;&#x43d;&#x444;&#x43e;&#x440;&#x43c;&#x430;&#x446;&#x438;&#x438; &#x434;&#x440;&#x443;&#x433;-&#x434;&#x440;&#x443;&#x433;&#x430;." ID="ID_891214430" CREATED="1465678964195" MODIFIED="1465678964195"/>
<node TEXT="&#x427;&#x442;&#x43e;&#x431;&#x44b; &#x432;&#x43a;&#x43b;&#x44e;&#x447;&#x438;&#x442;&#x44c; &#x44d;&#x43a;&#x441;&#x43f;&#x435;&#x440;&#x435;&#x43c;&#x435;&#x43d;&#x442;&#x430;&#x43b;&#x44c;&#x43d;&#x443;&#x44e; &#x43e;&#x43f;&#x446;&#x438;&#x44f; &#x431;&#x43b;&#x43e;&#x43a;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432;, &#x438;&#x441;&#x43f;&#x43e;&#x43b;&#x44c;&#x437;&#x443;&#x439;&#x442;&#x435; &#x43c;&#x435;&#x43d;&#x44e; &#x414;&#x43e;&#x43f;&#x43e;&#x43b;&#x43d;&#x438;&#x442;&#x435;&#x43b;&#x44c;&#x43d;&#x43e; &gt; &#x423;&#x441;&#x442;&#x430;&#x43d;&#x43e;&#x432;&#x43a;&#x438;." ID="ID_1797120873" CREATED="1465678964195" MODIFIED="1465678964195"/>
</node>
</node>
</map>
