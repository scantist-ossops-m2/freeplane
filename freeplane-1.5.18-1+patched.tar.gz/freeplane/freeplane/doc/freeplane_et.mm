<map version="freeplane 1.5.9">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body width=&quot;&quot;&gt;&#xa;    &lt;p align=&quot;center&quot;&gt;&#xa;      Freeplane&lt;br &gt;&lt;small&gt;- vabade m&amp;#245;tete kaardistamise tarkvara -&lt;/small&gt;&amp;#160;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" FOLDED="false" ID="ID_251547339" CREATED="1124560950701" MODIFIED="1216187545281" COLOR="#993300">
<font NAME="Dialog" SIZE="18" BOLD="true"/>
<hook NAME="MapStyle">
    <properties fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt" TEXT_SHORTENED="true">
<font SIZE="24"/>
<richcontent TYPE="DETAILS" LOCALIZED_HTML="styles_background_html"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="default" COLOR="#000000" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0.0 pt" FORMAT="NO_FORMAT" TEXT_ALIGN="CENTER" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font NAME="Arial" SIZE="9" BOLD="true" ITALIC="false"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details">
<font SIZE="11"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#000000" BACKGROUND_COLOR="#ffffff">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
<edge COLOR="#0000cc"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" UNIFORM_SHAPE="true" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font SIZE="24" ITALIC="true"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2">
<edge COLOR="#ff0033"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3">
<edge COLOR="#009933"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4">
<edge COLOR="#3333ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5">
<edge COLOR="#ff6600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6">
<edge COLOR="#cc00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7">
<edge COLOR="#ffbf00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8">
<edge COLOR="#00ff99"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9">
<edge COLOR="#0099ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10">
<edge COLOR="#996600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12">
<edge COLOR="#cc0066"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13">
<edge COLOR="#33ff00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14">
<edge COLOR="#ff9999"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15">
<edge COLOR="#0000cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16">
<edge COLOR="#cccc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17">
<edge COLOR="#0099cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18">
<edge COLOR="#006600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19">
<edge COLOR="#ff00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20">
<edge COLOR="#00cc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21">
<edge COLOR="#0066cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22">
<edge COLOR="#00ffff"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="Freeplane-i koduleht" POSITION="left" ID="ID_228039332" CREATED="1124560950701" MODIFIED="1216250158741" LINK="http://freeplane.sourceforge.net/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Kiirklahvikombinatsioonid" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1091417446" CREATED="1124560950701" MODIFIED="1216258652672" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Failik&amp;#228;sud:&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      ***********&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Uus kaart CTRL+N&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Ava kaart CTRL+O&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Salvesta kaart CTRL+S&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Salvesta kaart kui CTRL+SHIFT+S&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Tr&amp;#252;ki CTRL+P&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Sulge CTRL+W&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      V&amp;#228;lju CTRL+Q&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Eelmine kaart ALT+SHIFT+nool vasakule&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      J&amp;#228;rgmine kaart ALT+SHIFT+nool paremale&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Ekspordi HTML-ina CTRL+E&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Ekspordi haru HTML-ina CTRL+H&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Ekspordi haru uude MM-faili ALT+SHIFT+A&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Ava esimene fail ajaloost CTRL+SHIFT+W&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Muutmise k&amp;#228;sud:&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      ***************&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Otsi CTRL+F&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Otsi j&amp;#228;rgmine CTRL+G&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      L&amp;#245;ika CTRL+X&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Vali k&amp;#245;ik CTRL+A&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Vali haru CTRL+SHIFT+A&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Kopeeri CTRL+C&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Kopeeri &amp;#252;ksik CTRL+Y&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Aseta CTRL+V&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      V&amp;#245;ta tagasi CTRL+Z&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Tee uuesti CTRL+Y&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Suurenda ALT+nool alla&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      V&amp;#228;henda ALT + nool &amp;#252;les&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lmede vormindamise k&amp;#228;sud:&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      ***************************&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Kaldkiri CTRL+I&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Rasvane kiri CTRL+B&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Allajoonitud kiri CTRL+U&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Pilv &amp;#252;mber s&amp;#245;lme CTRL+SHIFT+B&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme v&amp;#228;rvi muutmine ALT+C&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme v&amp;#228;rvi segamine ALT+B&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme serva v&amp;#228;rvi muutmine ALT+E&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Suurenda s&amp;#245;lme kirjakuju suurust CTRL+L&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      V&amp;#228;henda s&amp;#245;lme kirjakuju suurust CTRL+M&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Suurenda s&amp;#245;lmede haru kirjakuju suurust CTRL+SHIFT+L&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      V&amp;#228;henda s&amp;#245;lmede haru kirjakuju suurust CTRL+SHIFT+M&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lmede navigeerimise k&amp;#228;sud:&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      ****************************&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Mine juurs&amp;#245;lme juurde ESCAPE&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Liigu &amp;#252;les nooleklahv &amp;#252;les&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Liigu alla nooleklahv alla&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Liigu vasakule nooleklahv vasakule&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Liigu paremale nooleklahv paremale&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Ava internetiviide CTRL+ENTER&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      V&amp;#228;henda ALT+NOOL &amp;#220;LES&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Suurenda ALT+NOOL ALLA&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Uue s&amp;#245;lme k&amp;#228;sud:&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      ****************&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Uus s&amp;#245;lm peas&amp;#245;lme k&amp;#252;lge ENTER&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Uus s&amp;#245;lm olemasoleva alla INSERT&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Uus s&amp;#245;lm olemasoleva ette SHIFT+ENTER&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme muutmise k&amp;#228;sud:&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      *********************&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Muuda valitud s&amp;#245;lme F2&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Muuda h&amp;#252;pikaknas koos lisav&amp;#245;imalustega ALT+ENTER&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      &amp;#220;henda s&amp;#245;lmed CTRL+J&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      L&amp;#252;lita s&amp;#245;lmede voltimist T&amp;#220;HIK&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      L&amp;#252;lita alams&amp;#245;lmede voltimist CTRL+T&amp;#220;HIK&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Lisa viide lehitsemisakna kaudu CTRL+SHIFT+K&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Lisa viide k&amp;#228;sitsi aadressi sisestades CTRL+K&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Lisa pilt lehitsemisakna kaudu ALT+K&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Liiguta s&amp;#245;lme &amp;#252;lespoole CTRL+nooleklahv &amp;#252;les&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Liiguta s&amp;#245;lme allapoole CTRL+nooleklahv alla&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Liiguta s&amp;#245;lme vasakule CTRL+nooleklahv vasakule&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Liiguta s&amp;#245;lme paremale CTRL+nooleklahv paremale&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Kustuta s&amp;#245;lm DELETE&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_908986002" CREATED="1124560950701" MODIFIED="1216258628092">
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node TEXT="Paigaldamine" FOLDED="true" POSITION="left" ID="_Freeplane_Link_904501221" CREATED="1124560950701" MODIFIED="1216201160402" COLOR="#006633">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Viited" FOLDED="true" ID="_Freeplane_Link_1911559485" CREATED="1124560950701" MODIFIED="1216200835990" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Laadi alla Java Runtime Environment (v&#xe4;hemalt JRE1.4 v&#xf5;i uuem)" ID="ID_568439776" CREATED="1124560950701" MODIFIED="1216187545266" LINK="http://java.sun.com/javase/downloads/index.jsp">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Laadi alla programm Freeplane" ID="_Freeplane_Link_1612101865" CREATED="1124560950701" MODIFIED="1216187545266" LINK="http://freeplane.sourceforge.net/wiki/index.php/Download#Download">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Freeplane-i paigaldamiseks MS Windows-is paigalda esmalt Sun-i Java Runtime Environment (JRE) ning seej&amp;#228;rel Freeplane kasutades &amp;quot;installer&amp;quot; versiooni.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_139664576" CREATED="1124560950701" MODIFIED="1216187545266">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Freeplane-i paigaldamiseks Linuxis, paigalda esmalt Sun-i Java Runtime Environment (JRE) ning siis peale lahtipakkimist k&amp;#228;ivita Freeplane failist freeplane.sh&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1380352758" CREATED="1124560950701" MODIFIED="1216187545266">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      MS Windows-is ning Mac OS X-s v&amp;#245;ib Freeplane-i k&amp;#228;ivitamiseks teha ka topeltkl&amp;#245;ps failil freeplane.jar, mis asub kataloogis lib.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1808511462" CREATED="1124560950701" MODIFIED="1216187545266">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Failide lehitsemine arvutist" FOLDED="true" POSITION="left" ID="_Freeplane_Link_353522063" CREATED="1124560950701" MODIFIED="1216201160403" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Failide lehitsemiseks oma arvutist l&#xfc;litu &#xfc;mber failire&#x17e;iimile, valides rippmen&#xfc;&#xfc;st Kaardid &gt; Fail." ID="ID_649040499" CREATED="1124560950701" MODIFIED="1216187545265">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Sa lehitsed failipuud nagu see oleks m&#xf5;ttekaart." ID="ID_1036346569" CREATED="1124560950701" MODIFIED="1216187545265">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Kataloogi m&#xe4;&#xe4;ramiseks keskele k&#xf5;ige suuremaks s&#xf5;lmeks, vali s&#xf5;lme h&#xfc;pikmen&#xfc;&#xfc;st Keskele." ID="ID_1489978112" CREATED="1124560950701" MODIFIED="1216187545265">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Faili vaatamiseks, muutmiseks v&#xf5;i k&#xe4;ivitamiseks j&#xe4;rgi s&#xf5;lmes olevat viidet." ID="ID_1505912742" CREATED="1124560950701" MODIFIED="1216187545265">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Faili re&amp;#382;iim ei ole hetkel eriti kasutusel. See on demonstratsioon, et andmete importimine puukujuliseks struktuuriks mujalt allikast kui m&amp;#245;ttekaart, on lihtne. Ei ole &amp;#252;htki t&amp;#245;endit, et inimesed reaalselt ka seda re&amp;#382;iimi kasutaksid.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_279880616" CREATED="1124560950701" MODIFIED="1216187545265">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="M&#xf5;ttekaartide lehitsemine" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1530607683" CREATED="1124560950701" MODIFIED="1216250753465" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      M&amp;#245;ttekaartide lehitsemiseks (mitte muutmiseks) l&amp;#252;litu lehitsemise re&amp;#382;iimi, valides rippmen&amp;#252;&amp;#252;st Kaardid &amp;gt; Lehitse. Kuniks ei kasutata Freeplane-i appletit, on see funktsioon kasutu.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_904930134" CREATED="1124560950701" MODIFIED="1216187545264">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Eraldi lehitsemiste re&amp;#382;iimide omamine on tehniline k&amp;#252;simus. Lehitsemine on ainus asi, mida Freeplane-i appletis kodulehel teha saab. &amp;#220;ldiselt ei kasutata lehitsemise re&amp;#382;iimi Freeplane-is.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_747061558" CREATED="1124560950701" MODIFIED="1216187545264">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Erinevad re&#x17e;iimid" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1136088046" CREATED="1124560950701" MODIFIED="1216201160404" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kuigi Freeplane on algselt m&amp;#245;eldud m&amp;#245;ttekaartide redigeerimiseks, on see siiski loodud ka arvestades teisi v&amp;#245;imalikke andmeallikaid. Spetsiifilise andmeallika k&amp;#228;ttesaadavaks tegemisel peab programmeerija tekitama niinimetatud re&amp;#382;iimi selle konkreetse andmeallika jaoks. Faili re&amp;#382;iim on &amp;#252;heks selliseks n&amp;#228;iteks. Me ei tea, et &amp;#252;htki teist re&amp;#382;iimi oleks v&amp;#228;lja arendatud. Ei ole p&amp;#228;ris selge, kas keegi seda &amp;#252;ldse kasutab kuid ta on siin olemas uurimiseks kui keegi seda soovib.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1713057526" CREATED="1124560950701" MODIFIED="1216187545264">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      On veel olemas skeemide kood, mis on peaaegu valmis ja v&amp;#245;imaldab muuta programmide skeeme. J&amp;#228;llegi - kasutuse vajalikkus on selgusetu. Vastupidiselt m&amp;#245;ttekaardi re&amp;#382;iimile on teised re&amp;#382;iimid rohkem demonstratsiooniks, mida k&amp;#245;ike on v&amp;#245;imalik Freeplane-i abil teha.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_700085988" CREATED="1124560950701" MODIFIED="1216187545264">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Freeplane-i appleti paigaldamine kodulehele" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1525986009" CREATED="1124560950701" MODIFIED="1216201160404" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Sa v&#xf5;id paigaldada appleti oma veebilehele nii, et teised kasutajad saavad lehitseda Sinu m&#xf5;ttekaarte." ID="ID_833832653" CREATED="1124560950701" MODIFIED="1216187545263" COLOR="#000000">
<font NAME="Dialog" SIZE="12"/>
</node>
<node TEXT="Laadi applet alla - selle nimi on freeplane-browser." ID="ID_506676757" CREATED="1124560950701" MODIFIED="1216187545263" LINK="http://sourceforge.net/project/showfiles.php?group_id=211069" COLOR="#338800">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Allalaaditud arhiiv sisaldab faile freeplanebrowser.jar ja freeplanebrowser.html. Oma kodulehel loo viide failile freeplanebrowser.html ja selle faili sees muuda vastav viide selliselt, et see viitaks Sinu m&amp;#245;ttekaardi failile.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_19242684" CREATED="1124560950701" MODIFIED="1216187545263">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Appleti *.jar fail peab asuma samas serveris kus ka m&amp;#245;ttekaart ise ja seda java turvalisuse p&amp;#228;rast. Sa pead laadima nii Freeplane-i appleti *.jar faili kui ka oma m&amp;#245;ttekaardi oma kodulehele.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1604975759" CREATED="1124560950701" MODIFIED="1216187545263">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Freeplane appleti kasutamine" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1083756111" CREATED="1124560950701" MODIFIED="1216201160404" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Freeplane-i appletis saad Sa kasutada vaid lehitsemise re&amp;#382;iimi; Sa ei saa muuta serveris asuvaid m&amp;#245;ttekaarte. Kl&amp;#245;psa s&amp;#245;lmel, et l&amp;#252;litada &amp;#252;mber voltimisre&amp;#382;iimi v&amp;#245;i j&amp;#228;rgneda veebiviitele. Haara ja lohista tausta, et liigutada m&amp;#245;ttekaarti. Otsimiseks kasuta m&amp;#245;ttekaardi kiirmen&amp;#252;&amp;#252;d.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_514864900" CREATED="1124560950701" MODIFIED="1216187545262">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Kasutajaliidese muudatused alates versioonist 0.6.5" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1976458022" CREATED="1124560950701" MODIFIED="1216201160405" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      M&amp;#245;ned klaviatuuriseaded on uuesti m&amp;#228;&amp;#228;ratud, et oleks kasutusel ka mujal programmides levinud intuitiivsed klahvikombinatsioonid. M&amp;#245;ned uued kiirklahvid p&amp;#228;rinevad Microsofti toodetest. Uued kiirklahvid sisaldavad ka n&amp;#228;iteks ENTER-i abil uue m&amp;#245;tte lisamine peas&amp;#245;lmele, INSERT-klahvi abil m&amp;#245;tte lisamine olemasoleva m&amp;#245;tte alla, F2 s&amp;#245;lme sisu muutmiseks - siin ongi Microsofti m&amp;#245;ju kuna tegelikult ei ole mingit p&amp;#245;hjust omada F2 kiirklahvi s&amp;#245;lme sisu muutmiseks. Kuid kui oled neid kiirklahve teistes programmides kasutanud, soovid neid ka Freeplane-i.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_717349033" CREATED="1124560950701" MODIFIED="1216187545262">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Klaviatuuri seadeid saab muuta rippmen&#xfc;&#xfc;st T&#xf6;&#xf6;riistad &gt; Eelistused." ID="_Freeplane_Link_1179893656" CREATED="1124560950701" MODIFIED="1216187545262">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="T&#xe4;nud" FOLDED="true" POSITION="left" ID="_Freeplane_Link_784043927" CREATED="1124560950701" MODIFIED="1216272432955" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Autorid" ID="Freeplane_Link_415458128" CREATED="1124560950701" MODIFIED="1216272329963" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Joerg Mueller" FOLDED="true" ID="_Freeplane_Link_1896457660" CREATED="1124560950701" MODIFIED="1216187545261" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="ponders@t-online.de" ID="ID_1354886892" CREATED="1124560950701" MODIFIED="1216187545261" LINK="mailto:ponders@t-online.de" COLOR="#558000">
<font NAME="Dialog" SIZE="10"/>
</node>
<node TEXT="Freiburgi &#xdc;likool, Saksamaa" ID="ID_1757468410" CREATED="1124560950701" MODIFIED="1216187545261" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Daniel Polansky" ID="_Freeplane_Link_984984595" CREATED="1124560950701" MODIFIED="1216272339951" LINK="http://danpolansky.blogspot.com/" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Petr Novak" ID="_Freeplane_Link_459203293" CREATED="1124560950701" MODIFIED="1216187545261" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Christian Foltin" ID="_Freeplane_Link_875814410" CREATED="1124560950701" MODIFIED="1216272344134" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Dimitri Polivaev" ID="_Freeplane_Link_1415293905" CREATED="1124560950701" MODIFIED="1216187545261" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="V&#xe4;iksemad panustajad" FOLDED="true" ID="Freeplane_Link_816166020" CREATED="1124560950701" MODIFIED="1216272427853" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Andrew Iggleden" ID="ID_1613097663" CREATED="1124560950701" MODIFIED="1216272349630" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Windows-i paigaldaja" ID="ID_1149301468" CREATED="1124560950701" MODIFIED="1216187545261" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Bob Alexander" ID="Freeplane_Link_1096673251" CREATED="1124560950701" MODIFIED="1216272351336" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Eclipse &#xf5;petus" ID="ID_617977736" CREATED="1124560950701" MODIFIED="1216187545261" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="David Butt" ID="Freeplane_Link_1024053399" CREATED="1124560950701" MODIFIED="1216272352345" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Flash-i &#xf5;petus" ID="ID_49661074" CREATED="1124560950701" MODIFIED="1216187545261" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="David Low" ID="ID_1167712813" CREATED="1124560950701" MODIFIED="1216272353298" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Abitekstid" ID="ID_356164606" CREATED="1124560950701" MODIFIED="1216187545261" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
</node>
<node TEXT="T&#xf5;lkijad" FOLDED="true" ID="Freeplane_Link_360501151" CREATED="1124560950701" MODIFIED="1216272426323" LINK="http://freeplane.sourceforge.net/wiki/index.php/Translation" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Edmund Laugasson" ID="ID_180090574" CREATED="1124561374999" MODIFIED="1216272357942" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Eesti keele t&#xf5;lge" ID="ID_537083851" CREATED="1124561377702" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Bob Alexander" ID="Freeplane_Link_807977431" CREATED="1124560950701" MODIFIED="1216272359692" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Itaalia keele t&#xf5;lge" ID="ID_1392047072" CREATED="1124560950701" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Knud Riish&#xf8;jg&#xe5;rd" ID="Freeplane_Link_1853214917" CREATED="1124560950701" MODIFIED="1216272361218" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Taani keele t&#xf5;lge" ID="ID_572926838" CREATED="1124560950701" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Takeshi Kakeda" ID="Freeplane_Link_1676529317" CREATED="1124560950701" MODIFIED="1216272362282" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Jaapani keele t&#xf5;lge" ID="ID_763739856" CREATED="1124560950701" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Kohichi Aoki" ID="Freeplane_Link_1172193026" CREATED="1124562983644" MODIFIED="1216272363189" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Jaapani keele t&#xf5;lge" ID="ID_919845662" CREATED="1124560950701" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Alex Dukal" ID="ID_1810700717" CREATED="1124560950701" MODIFIED="1216272364055" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Hispaania keele t&#xf5;lge" ID="ID_1990388249" CREATED="1124560950701" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Hugo Gayosso" ID="Freeplane_Link_757563697" CREATED="1124562998159" MODIFIED="1216272364816" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Hispaania keele t&#xf5;lge" ID="Freeplane_Link_1783275246" CREATED="1124560950701" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Sylvain Gamel" ID="Freeplane_Link_929540960" CREATED="1124560950701" MODIFIED="1216272365516" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Prantsuse keele t&#xf5;lge" ID="ID_665552197" CREATED="1124560950701" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Koen Roggemans" ID="Freeplane_Link_946171164" CREATED="1124561242082" MODIFIED="1216272366270" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Hollandi keele t&#xf5;lge" ID="Freeplane_Link_1819881845" CREATED="1124561245957" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Rafal Kraik" ID="Freeplane_Link_235962981" CREATED="1124561374999" MODIFIED="1216272366953" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Poola keele t&#xf5;lge" ID="Freeplane_Link_459079511" CREATED="1124561377702" MODIFIED="1216187545260" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Goliath" ID="Freeplane_Link_653284985" CREATED="1124561969717" MODIFIED="1216272367703" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Korea keele t&#xf5;lge" ID="Freeplane_Link_1387213811" CREATED="1124561438294" MODIFIED="1216187545259" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Martin Srebotnjak (h&#xfc;&#xfc;dnimi: Miles a.k.a. filmsi)" ID="Freeplane_Link_35211963" CREATED="1124561753254" MODIFIED="1216272369174" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Sloveenia keele t&#xf5;lge" ID="Freeplane_Link_835144271" CREATED="1124561491886" MODIFIED="1216187545258" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="William Chen" ID="Freeplane_Link_1008886206" CREATED="1124561814721" MODIFIED="1216272380101" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Hiina keele t&#xf5;lge" ID="Freeplane_Link_1960552629" CREATED="1124561497308" MODIFIED="1216187545258" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Radek &#x160;varc" ID="Freeplane_Link_1650138043" CREATED="1124561823877" MODIFIED="1216272379451" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="T&#x161;ehhi keele t&#xf5;lge" ID="Freeplane_Link_768227373" CREATED="1124561515761" MODIFIED="1216187545257" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Bal&#xe1;zs M&#xe1;rton" ID="Freeplane_Link_901975324" CREATED="1124562250475" MODIFIED="1216272380882" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Ungari keele t&#xf5;lge" ID="Freeplane_Link_557911120" CREATED="1124562252585" MODIFIED="1216187545257" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Luis Ferreira " ID="Freeplane_Link_290351026" CREATED="1124562948942" MODIFIED="1216272381633" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Portugali keele t&#xf5;lge" ID="Freeplane_Link_6081004" CREATED="1124562956332" MODIFIED="1216187545257" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      T&amp;#245;lkijate nimekiri ei pruugi olla l&amp;#245;plik. Kui me oleme Sind unustanud - palun anna sellest meile teada! K&amp;#245;ik inimesed, kes on isegi poolikuid t&amp;#245;lkeid edastanud, on siin nimekirjas toodud.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="Freeplane_Link_23652566" CREATED="1124563066204" MODIFIED="1216187545257" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Otsimiseks vajuta CTRL + F. J&amp;#228;rgmise otsimiseks vajuta CTRL + G. Et muuta otsing globaalseks, vajuta ESC enne otsimise alustamist.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" POSITION="right" ID="ID_296319773" CREATED="1124560950701" MODIFIED="1216187545251" COLOR="#0033ff">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Vajuta parempoolset nooleklahvi, et avada (lahti voltida) tekstikast." POSITION="right" ID="ID_1243305843" CREATED="1124560950701" MODIFIED="1216187545242" COLOR="#0033ff">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Tutvustus" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1596161299" CREATED="1124560950701" MODIFIED="1216201160406" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Freeplane v&amp;#245;imaldab luua niinimetatud m&amp;#245;ttekaarte. Samas kasutavad paljud inimesed seda kui m&amp;#228;rkmikku v&amp;#245;i lihtsalt isikliku info haldamiseks.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1477669657" CREATED="1124560950701" MODIFIED="1216187545242">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Infot hoitakse tekstikastides, mida nimetatakse s&amp;#245;lmedeks. S&amp;#245;lmed on omavahel &amp;#252;henduses, kasutades jooni.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1859704500" CREATED="1124560950701" MODIFIED="1216187545242">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      See on Freeplane 0.9.0 dokumentatsioon. Kiirklahvid ja funktsioonide asukohad men&amp;#252;&amp;#252;des v&amp;#245;ivad tulevikus muutuda.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_163671273" CREATED="1124560950701" MODIFIED="1216187545242">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="M&#xf5;nede v&#xf5;imaluste demonstratsioon" FOLDED="true" POSITION="right" ID="_Freeplane_Link_706084071" CREATED="1124560950701" MODIFIED="1216201160408" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="V&#xe4;limus" FOLDED="true" ID="_Freeplane_Link_735193624" CREATED="1124560950701" MODIFIED="1216200835993" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="S&#xf5;lmed v&#xf5;ivad olla erinevat v&#xe4;rvi." FOLDED="true" ID="ID_887863172" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Punane" ID="ID_1474945370" CREATED="1124560950701" MODIFIED="1216187545241" COLOR="#ff0000">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Roheline" ID="ID_1005177880" CREATED="1124560950701" MODIFIED="1216187545241" COLOR="#009900">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Sinine" ID="ID_304992602" CREATED="1124560950701" MODIFIED="1216187545241" COLOR="#0000cc">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="S&#xf5;lmedel v&#xf5;ivad olla erinevad taustav&#xe4;rvid" FOLDED="true" ID="_" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="N&#xe4;iteks selline" ID="_Freeplane_Link_1358611533" CREATED="1124560950701" MODIFIED="1216187545241" BACKGROUND_COLOR="#77a86f"/>
<node TEXT="Ja veel ka selline" ID="_Freeplane_Link_1317973766" CREATED="1124560950701" MODIFIED="1216187545241" BACKGROUND_COLOR="#d3d9f4"/>
</node>
<node TEXT="S&#xf5;lmedel v&#xf5;ivad olla erinevad fontide stiilid" FOLDED="true" ID="ID_754589044" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Rasvane kiri" ID="ID_1966890106" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="Dialog" SIZE="12" BOLD="true"/>
</node>
<node TEXT="Kaldkiri" ID="ID_1134315926" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="Dialog" SIZE="12" ITALIC="true"/>
</node>
<node TEXT="Rasvane ja kaldkiri" ID="ID_1038960675" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="Dialog" SIZE="12" BOLD="true" ITALIC="true"/>
</node>
</node>
<node TEXT="S&#xf5;lmede fondid v&#xf5;ivad olla erinevate suurustega" FOLDED="true" ID="ID_357603252" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="V&#xe4;ike" ID="ID_1612985143" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node TEXT="Normaalne" ID="ID_99178057" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node TEXT="Suurem" ID="ID_421241675" CREATED="1124560950701" MODIFIED="1216187545241">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node TEXT="Suur" FOLDED="true" ID="ID_590940671" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="20"/>
<node TEXT="OOh" ID="ID_223617365" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node TEXT="Erinevaid fonte saab kasutada" FOLDED="true" ID="ID_1960916074" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Selline" ID="ID_1360641359" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node TEXT="V&#xf5;i see" ID="_Freeplane_Link_1568731425" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="Verdana" SIZE="12"/>
</node>
<node TEXT="V&#xf5;i hoopis see" ID="ID_539001457" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node TEXT="Erinevaid s&#xf5;lmede stiile saab kasutada" FOLDED="true" ID="_Freeplane_Link_1193071041" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Kahvel" FOLDED="true" ID="_Freeplane_Link_1979277285" CREATED="1124560950701" MODIFIED="1216187545240">
<node TEXT="Kahvel" ID="_Freeplane_Link_89124429" CREATED="1124560950701" MODIFIED="1216187545240"/>
<node TEXT="Kahvel" ID="_Freeplane_Link_173850525" CREATED="1124560950701" MODIFIED="1216187545240"/>
</node>
<node TEXT="Mullitatud" FOLDED="true" ID="_Freeplane_Link_1001811541" CREATED="1124560950701" MODIFIED="1216187545240" STYLE="bubble">
<node TEXT="Mullitatud" ID="_Freeplane_Link_1677737286" CREATED="1124560950701" MODIFIED="1216187545240" STYLE="bubble"/>
<node TEXT="Mullitatud" ID="_Freeplane_Link_978246353" CREATED="1124560950701" MODIFIED="1216187545240" STYLE="bubble"/>
</node>
</node>
</node>
<node TEXT="S&#xf5;lmi saab kokku/lahti voltida" FOLDED="true" ID="ID_738265772" CREATED="1124560950701" MODIFIED="1216200835993" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="S&#xf5;lm" FOLDED="true" ID="_Freeplane_Link_307016912" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Peidetud" ID="ID_295225504" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Puu" FOLDED="true" ID="_Freeplane_Link_1488567837" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Tamm" ID="ID_734334377" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="P&#xf6;&#xf6;k" ID="ID_1388126257" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Jalakas" ID="ID_292365900" CREATED="1124560950701" MODIFIED="1216187545240">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="S&#xf5;lmed v&#xf5;ivad sisaldada j&#xe4;rgitavaid viiteid ... " FOLDED="true" ID="ID_1596510922" CREATED="1124560950701" MODIFIED="1216200835994" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Veebilehtedele" FOLDED="true" ID="ID_1913017247" CREATED="1124560950701" MODIFIED="1216187545239" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="http://www.google.ee/" ID="ID_350611440" CREATED="1124560950701" MODIFIED="1216187545239" LINK="http://www.google.ee/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="www.google.ee" FOLDED="true" ID="ID_646857774" CREATED="1124560950701" MODIFIED="1216187545239" LINK="www.google.ee">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Freeplane arvab, et see on k&#xe4;ivitatav fail :)" ID="ID_1117649418" CREATED="1124560950701" MODIFIED="1216187545239" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node TEXT="Kohalikele kaustadele" FOLDED="true" ID="ID_715165450" CREATED="1124560950701" MODIFIED="1216187545239" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:/Program Files/" ID="ID_469314055" CREATED="1124560950701" MODIFIED="1216187545239" LINK="file:/C:/Program%20Files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="/home/" ID="ID_534319083" CREATED="1124560950701" MODIFIED="1216187545239" LINK="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="K&#xe4;ivitatavatele failidele" FOLDED="true" ID="ID_1939211284" CREATED="1124560950701" MODIFIED="1216187545239" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:\WINNT\regedit.exe" FOLDED="true" ID="ID_1645120569" CREATED="1124560950701" MODIFIED="1216187545239" LINK="file:/C:/WINNT/regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Siit on n&#xe4;ha, et s&#xf5;lmel on k&#xe4;ivitatava faili ikoon ees." ID="ID_1388267403" CREATED="1124560950701" MODIFIED="1216187545239" COLOR="#006600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Suvaline dokument Sinu arvutis v&#xf5;i Sinu ettev&#xf5;tte v&#xf5;rgus" ID="ID_1573618660" CREATED="1124560950717" MODIFIED="1216187545239">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Mitmerealised s&#xf5;lmed" FOLDED="true" ID="_Freeplane_Link_839677176" CREATED="1124560950717" MODIFIED="1216200835994" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Sa v&amp;#245;id n&amp;#228;ha mitmerealisi s&amp;#245;lmi eraldi tekstil&amp;#245;iguna v&amp;#245;i mitme tekstil&amp;#245;iguna. Kui oled ehitamas teadmista baasi Freeplane-i abil, siis ilmselt ei saa l&amp;#245;ikude kasutamist v&amp;#228;ltida. Selle asemel, et omada lihtsalt tavalist tekstifaili m&amp;#228;rkmetega, v&amp;#245;id Sa hoopis omada s&amp;#245;lmedest koosnevat jada, mis on omavahel &amp;#252;hendatud ja saab j&amp;#228;rk-j&amp;#228;rgult lahti harutada.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1423568963" CREATED="1124560950717" MODIFIED="1216187545239">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &amp;quot;Teadus on fakt; just nagu majad tehakse kividest, nii ka teadus koosneb faktidest; kuid kivihunnik ei ole veel maja ja faktikogum ei pruugi veel teadus olla.&amp;quot; --Henri Poincar&amp;#233;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1686184172" CREATED="1124560950717" MODIFIED="1216187545239">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="L&#xfc;hikeserealised s&#xf5;lmed koos uute ridadega" FOLDED="true" ID="ID_1384103247" CREATED="1124560950717" MODIFIED="1216200835994" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Rida,&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      ja teinegi,&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      ja veel &amp;#252;ks rida,&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      mida arvad sellest?&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1957797574" CREATED="1124560950717" MODIFIED="1216187545239">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Sa v&#xf5;id emuleerida sildistatud jooni" FOLDED="true" ID="ID_1747782018" CREATED="1124560950717" MODIFIED="1216200835994" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Puu" FOLDED="true" ID="ID_1812254377" CREATED="1124560950717" MODIFIED="1216187545239">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="on" FOLDED="true" ID="ID_1357589453" CREATED="1124560950717" MODIFIED="1216200828922" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Tamm" ID="ID_1843885197" CREATED="1124560950717" MODIFIED="1216187545239">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="on" FOLDED="true" ID="ID_1175801663" CREATED="1124560950717" MODIFIED="1216200828922" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="P&#xf6;&#xf6;k" ID="ID_956172504" CREATED="1124560950717" MODIFIED="1216187545239">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="on" FOLDED="true" ID="ID_647529529" CREATED="1124560950717" MODIFIED="1216200828922" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Jalakas" ID="ID_1045593899" CREATED="1124560950717" MODIFIED="1216187545239">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Puu" FOLDED="true" ID="ID_1721974835" CREATED="1124560950717" MODIFIED="1216187545238">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;&gt;" FOLDED="true" ID="ID_300230898" CREATED="1124560950717" MODIFIED="1216187545238" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Leht" ID="ID_1149978961" CREATED="1124560950717" MODIFIED="1216187545238">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&lt;&gt;" FOLDED="true" ID="ID_329904317" CREATED="1124560950717" MODIFIED="1216187545238" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="T&#xfc;vi" ID="ID_1518758203" CREATED="1124560950717" MODIFIED="1216187545238">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="Sa v&#xf5;id ikoone lisada s&#xf5;lmedesse" ID="ID_46511860" CREATED="1124560950717" MODIFIED="1216187545238" COLOR="#669900">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Sa v&#xf5;id teha pilvi" FOLDED="true" ID="_Freeplane_Link_318937820" CREATED="1124560950717" MODIFIED="1216200835996" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<cloud COLOR="#f0f0f0" SHAPE="ARC"/>
<node TEXT="Endavalitud v&#xe4;rvidega" ID="ID_1236643816" CREATED="1124560950717" MODIFIED="1216187545238">
<cloud COLOR="#f1ede6" SHAPE="ARC"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Sa v&#xf5;id teha graafilisi viiteid" FOLDED="true" ID="_Freeplane_Link_1750585847" CREATED="1124560950717" MODIFIED="1216200835996" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#xdc;hendada s&#xf5;lme" ID="_Freeplane_Link_1212380407" CREATED="1124560950717" MODIFIED="1216187545238">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1249400461" STARTINCLINATION="41;0;" ENDINCLINATION="41;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Teisega" ID="_Freeplane_Link_1249400461" CREATED="1124560950717" MODIFIED="1216187545238">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#6600ff" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_880551392" STARTINCLINATION="47;0;" ENDINCLINATION="47;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Erinevates v&#xe4;rvides" ID="_Freeplane_Link_880551392" CREATED="1124560950717" MODIFIED="1216187545238">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1789233193" STARTINCLINATION="82;44;" ENDINCLINATION="82;44;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Ja erineva kujuga" ID="_Freeplane_Link_1789233193" CREATED="1124560950717" MODIFIED="1216187545238">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="S&#xf5;lmi saab vabalt &#xfc;mber paigutada" FOLDED="true" ID="_Freeplane_Link_127668276" CREATED="1124560950717" MODIFIED="1216200835996" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&#xdc;ks" ID="_Freeplane_Link_894936766" CREATED="1124560950717" MODIFIED="1216187545238">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Teine" ID="_Freeplane_Link_1942481455" CREATED="1124560950717" MODIFIED="1216187545237">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="S&#xf5;lmede loomine ja kustutamine" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1709752669" CREATED="1124560950717" MODIFIED="1216201160409" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Alams&#xf5;lme tekitamiseks aktiivse s&#xf5;lme alla vajuta INSERT." ID="ID_1080456719" CREATED="1124560950717" MODIFIED="1216187545237">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Et luua uut alams&amp;#245;lme samal ajal kui muudetakse teist s&amp;#245;lme, vajuta muutmise ajal INSERT.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_745599378" CREATED="1124560950717" MODIFIED="1216187545237">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      1. taseme alams&amp;#245;lme loomiseks peas&amp;#245;lme alla vajuta ENTER.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1624846736" CREATED="1124560950717" MODIFIED="1216187545236">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      1. taseme alams&amp;#245;lme loomiseks peas&amp;#245;lme alla aktiivse s&amp;#245;lme kohale, vajuta SHIFT + ENTER.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_987299998" CREATED="1124560950717" MODIFIED="1216187545234">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="S&#xf5;lme kustutamiseks vajuta DELETE" ID="ID_461300770" CREATED="1124560950717" MODIFIED="1216187545234">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Aktiivse s&amp;#245;lme l&amp;#245;ikamiseks vajuta CTRL + X&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1332647159" CREATED="1124560950717" MODIFIED="1216187545234">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      K&amp;#245;iki tegevusi saab teha ka hiire paremklahvi alt avanevat men&amp;#252;&amp;#252;d kasutades.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_308911082" CREATED="1124560950717" MODIFIED="1216187545234">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="S&#xf5;lme teksti muutmine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1700974092" CREATED="1124560950717" MODIFIED="1216201160410" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme muutmiseks vajuta F2, HOME v&amp;#245;i END klahvi, v&amp;#245;i s&amp;#245;lme kiirmen&amp;#252;&amp;#252;s vali Redigeeri s&amp;#245;lme. S&amp;#245;lme redigeerimise l&amp;#245;petamiseks, vajuta ENTER nupule.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_519923426" CREATED="1124560950717" MODIFIED="1216187545234">
<arrowlink SHAPE="LINE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_519923426" STARTINCLINATION="0;0;" ENDINCLINATION="0;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lmes oleva teksti asendamiseks uuega lihtsalt alusta tippimist.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_522935321" CREATED="1124560950717" MODIFIED="1216187545233">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Et sundida l&amp;#252;hikese sisuga s&amp;#245;lme muutmist avanema eraldi h&amp;#252;pikaknas, vajuta ALT + ENTER.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_645044942" CREATED="1124560950717" MODIFIED="1216187545233">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Pika sisuga s&amp;#245;lme poolitamiseks kasuta nuppu Poolita s&amp;#245;lme redaktori akna allosas v&amp;#245;i vajuta ALT + S.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_683234865" CREATED="1124560950717" MODIFIED="1216187545233">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Uue rea lisamiseks s&amp;#245;lme redigeerimise aknas, vajuta CTRL + ENTER. Kui s&amp;#245;lme redigeeritakse kohapeal ilma redaktori aknata siis uue rea lisamine ei ole v&amp;#245;imalik.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1426930299" CREATED="1124560950717" MODIFIED="1216187545233">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1445647544" STARTINCLINATION="118;0;" ENDINCLINATION="118;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Et kopeerida valikut l&amp;#245;ikepuhvrisse samal ajal kui toimub s&amp;#245;lme teksti muutmine eraldi aknas, vajuta hiire paremklahvi ning vali sealt Kopeeri.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_496995972" CREATED="1124560950717" MODIFIED="1216187545233">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Et lisada eris&amp;#252;mboleid nagu n&amp;#228;iteks &amp;#169;, lisa see k&amp;#245;igepealt oma lemmiktekstiredaktoris nagu n&amp;#228;iteks OpenOffice.org Writer v&amp;#245;i MS Word, ja siis kopeeri see Freeplane-i.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_372247337" CREATED="1124560950717" MODIFIED="1216187545233">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Vaikimisi ENTER l&amp;#245;petab s&amp;#245;lme redigeerimise ja CTRL+ENTER lisab uue rea. M&amp;#228;rkeruudu &amp;quot;Enter kinnitab&amp;quot; m&amp;#228;rkimise eemaldamisega saad Sa muuta eeltoodud klahvikombinatsioonide m&amp;#245;ju vastupidiseks, n&amp;#228;iteks ENTER lisab uue rea ja CTRL+ENTER l&amp;#245;petab redigeerimise. Sa v&amp;#245;id muuta vaikimisi v&amp;#228;&amp;#228;rtust sellel m&amp;#228;rkeruudul eelistustest. Veelgi enam - selle m&amp;#228;rkeruudu v&amp;#228;&amp;#228;rtus salvestatakse ja hakkab kehtima ka siis kui Freeplane-i vahepeal ei sulge.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1445647544" CREATED="1124560950717" MODIFIED="1216187545233">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Freeplane toetab t&amp;#228;ielikult unicode-i. Seet&amp;#245;ttu v&amp;#245;id kasutada skripte oma suva j&amp;#228;rgi.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1377326758" CREATED="1124560950717" MODIFIED="1216187545233">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="S&#xf5;lme kujundamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1660149394" CREATED="1124560950717" MODIFIED="1216201160410" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="S&#xf5;lme teksti rasvaseks muutmiseks vajuta CTRL + B." ID="ID_1886238915" CREATED="1124560950717" MODIFIED="1216187545232">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="S&#xf5;lme teksti kaldu muutmiseks vajuta CTRL + I." ID="ID_999781422" CREATED="1124560950717" MODIFIED="1216187545232">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="S&#xf5;lme teksti v&#xe4;rvi muutmiseks vajuta Alt + C." ID="ID_939014888" CREATED="1124560950717" MODIFIED="1216187545232">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme taustav&amp;#228;rvi muutmiseks vali s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st Vormindus -&amp;gt; S&amp;#245;lme taustav&amp;#228;rv&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1116928608" CREATED="1124560950717" MODIFIED="1216187545232">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme kirja suuruse suurendamiseks vajuta CTRL + &lt;font size=&quot;4&quot;&gt;+ &lt;/font&gt;&lt;font size=&quot;3&quot;&gt;(mitte see + numbriklahvide juurest)&lt;/font&gt;.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1517052690" CREATED="1124560950717" MODIFIED="1216187545232">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme kirja v&amp;#228;hendamiseks vajuta CTRL + &lt;font size=&quot;4&quot;&gt;-&lt;/font&gt; (mitte see - numbriklahvide juurest).&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1300105414" CREATED="1124560950717" MODIFIED="1216187545232">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kirjakuju muutmiseks vali vastav v&amp;#228;li peamisel t&amp;#246;&amp;#246;riistaribal.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1712083026" CREATED="1124560950717" MODIFIED="1216187545232">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme vorminduse kopeerimiseks vajuta Alt + C&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_488438696" CREATED="1124560950717" MODIFIED="1216187545232">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Kujunduse asetamiseks To paste formats onto a node, press Alt + V." ID="ID_1757575811" CREATED="1124560950717" MODIFIED="1216187545232">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="F&#xfc;&#xfc;siliste stiilide kasutamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_526328879" CREATED="1124560950717" MODIFIED="1216201160411" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      F&amp;#252;&amp;#252;silise stiili lisamiseks vali s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st F&amp;#252;&amp;#252;siline stiil -&amp;gt;Stiil Sinu valikul. F&amp;#252;&amp;#252;siliste stiilide lisamise kiirendamiseks kasuta klaviatuuri kiirklahve nagu on sealsamas kiirmen&amp;#252;&amp;#252;s hiire parema klahvi all n&amp;#228;idatud.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_529939824" CREATED="1124560950717" MODIFIED="1216187545231">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Oma f&amp;#252;&amp;#252;silise stiili lisamine eeldab, et oled tehnilise p&amp;#228;devusega kasutaja. Muuda neid faile &amp;quot;patterns.xml&amp;quot; failis, mis asub kataloogis &amp;quot;.freeplane&amp;quot; Sinu kodukataloogis.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_472935372" CREATED="1124560950717" MODIFIED="1216187545231">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      [See tekst on aegunud.] M&amp;#228;rkused failist patterns.xml j&amp;#228;rgnevad. F&amp;#252;&amp;#252;siline stiil kehtestub s&amp;#245;lmedele kui seal on &amp;lt;edge&amp;gt; m&amp;#228;rgend. &amp;lt;node&amp;gt; m&amp;#228;rgend v&amp;#245;ib omada alamm&amp;#228;rgeneid. Uuri faili &amp;quot;patterns.xml&amp;quot;, mis on Freeplane-iga kaasa pandud.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="Freeplane_Link_1514218661" CREATED="1124560950717" MODIFIED="1216187545231">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="S&#xf5;lmede esilet&#xf5;stmine pilvedega" FOLDED="true" POSITION="right" ID="Freeplane_Link_1697687428" CREATED="1124560950717" MODIFIED="1216201160411" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Pilvi kasutatakse mingi ala esilet&amp;#245;stmiseks. Esile t&amp;#245;stetakse nii s&amp;#245;lm kui ka k&amp;#245;ik selle all olevad s&amp;#245;lmed.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1187980137" CREATED="1124560950717" MODIFIED="1216187545231">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Pilve lisamiseks vajuta CTRL + SHIFT + B v&amp;#245;i vali s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st Lisamine -&amp;gt; Pilv.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1656028711" CREATED="1124560950717" MODIFIED="1216187545231">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme v&amp;#228;rvi muutmiseks vali s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st Vormindus -&amp;gt; Pilve v&amp;#228;rv.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1229313572" CREATED="1124560950717" MODIFIED="1216187545230">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Pilvedel v&amp;#245;ib olla erinevaid taustav&amp;#228;rve, nt roheline ...&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" FOLDED="true" ID="ID_1967714751" CREATED="1124560950717" MODIFIED="1216200835997">
<cloud COLOR="#e1f2e1" SHAPE="ARC"/>
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="... v&#xf5;i pruun." ID="ID_480742681" CREATED="1124560950717" MODIFIED="1216187545230">
<cloud COLOR="#ede5d5" SHAPE="ARC"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="H&#xfc;perviidete lisamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_203858515" CREATED="1124560950717" MODIFIED="1216201160412" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      H&amp;#252;perviite lisamiseks s&amp;#245;lmele vajuta CTRL + K v&amp;#245;i vali s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st Lisamine -&amp;gt; H&amp;#252;perviide.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1905021887" CREATED="1124560950717" MODIFIED="1216187545230">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      H&amp;#252;perviite eemaldamiseks kustuta h&amp;#252;perviide p&amp;#228;rast CTRL + K vajutamist avanevast h&amp;#252;pikaknast.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1725364546" CREATED="1124560950717" MODIFIED="1216187545230">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Viite tegemiseks e-postiaadressile m&amp;#228;&amp;#228;ra h&amp;#252;perviite tekstiks n&amp;#228;iteks &lt;i&gt;mailto:eesnimi.perenimi@mail&lt;/i&gt;.ee&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1115329778" CREATED="1124560950717" MODIFIED="1216187545230">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Koos kirjateemaga e-postiaadressile viite tegemiseks m&amp;#228;&amp;#228;ra h&amp;#252;perviite sisuks &lt;i&gt;mailto:eesnimi.perenimi@mail&lt;/i&gt;.&lt;i&gt;ee?subject=Viimane telefonik&amp;#245;ne&lt;/i&gt;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1492211565" CREATED="1124560950717" MODIFIED="1216187545230">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      H&amp;#252;perviiteid saab panna viitama veebilehtedele, kohalikele failidele v&amp;#245;i e-postiaadressidele.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_75591401" CREATED="1124560950717" MODIFIED="1216187545229">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Ikoonide lisamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1044397139" CREATED="1124560950717" MODIFIED="1216201160413" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT=" S&#xf5;lmes v&#xf5;ib olla mitu ikooni. " ID="ID_530415806" CREATED="1124560950717" MODIFIED="1216187545227">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Ikooni lisamiseks s&amp;#245;lme, vali s&amp;#245;lm ja kl&amp;#245;psa &amp;#252;hel ikoonidest vasakul t&amp;#246;&amp;#246;riistaribal. Hiirekursori liigutamisel vasakul asuvale t&amp;#246;&amp;#246;riistaribale, hoia all ALT- v&amp;#245;i CTRL-klahvi, et Sa ei kaotaks fookust.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_552368878" CREATED="1124560950717" MODIFIED="1216187545227">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &amp;#220;he ikooni eemaldamiseks vajuta punast risti vasakpoolse t&amp;#246;&amp;#246;riistariba &amp;#252;laosas.&amp;#160;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1584241525" CREATED="1124560950717" MODIFIED="1216187545227">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      K&amp;#245;ikide ikoonide korraga eemaldamiseks vajuta pr&amp;#252;gikasti kujutavat ikooni vasakpoolse t&amp;#246;&amp;#246;riistariba &amp;#252;laosas.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_741996931" CREATED="1124560950717" MODIFIED="1216187545226">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Uue ikooni s&amp;#245;lme lisamiseks klaviatuuri abil vajuta ALT + I.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1106300423" CREATED="1124560950717" MODIFIED="1216187545226">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Oma ikoonide kasutamise v&amp;#245;imalus puudub; Sa saad valida ikoone &amp;#252;ksnes Freeplane-iga kaasatulevate ikoonide hulgast.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_5062099" CREATED="1124560950717" MODIFIED="1216187545226">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Ikoonide t&amp;#246;&amp;#246;riistariba peitmiseks v&amp;#245;i n&amp;#228;itamiseks vasakul t&amp;#246;&amp;#246;riistaribal, vali taustal hiire kiirmen&amp;#252;&amp;#252;st L&amp;#252;lita vasakut t&amp;#246;&amp;#246;riistariba. Ikoonide t&amp;#246;&amp;#246;riistariba kutsutakse seal: Teine t&amp;#246;&amp;#246;riistariba.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_492956634" CREATED="1124560950717" MODIFIED="1216187545226">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kui ikoonid on lisatud nagu siin s&amp;#245;lmel siis need pannakse kaasa ja enamgi veel.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_228388619" CREATED="1124560950717" MODIFIED="1216187545226">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Graafiliste viidete lisamine" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1996597932" CREATED="1124560950717" MODIFIED="1216201160413" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Graafiliste viidete tegemiseks kahe s&amp;#245;lme vahel haara &amp;#252;hest s&amp;#245;lmest ja kukuta see teisele s&amp;#245;lmele, samal ajal SHIFT + CTRL klahve korraga all hoides. Vabasta hiireklahv ennem klaviatuuri klahve.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_706501552" CREATED="1124560950717" MODIFIED="1216187545225">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#b0b0b0" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_266716332" STARTINCLINATION="250;-7;" ENDINCLINATION="289;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Teine v&amp;#245;imalus - m&amp;#228;rgi CTRL-klahvi all hoides kaks s&amp;#245;lme ja vajuta CTRL + L&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1666507871" CREATED="1124560950717" MODIFIED="1216187545225">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Graafilise viite v&amp;#228;rvi muutmiseks kasuta hiire kiirmen&amp;#252;&amp;#252;d, mis avaneb hiire paremklahvi alt kui sellel graafilisel viitel kl&amp;#245;psata.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_208378337" CREATED="1124560950717" MODIFIED="1216187545225">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Joone nooleotse muutmiseks kasuta taas kiirmen&amp;#252;&amp;#252;d (hiire paremklahviga kl&amp;#245;ps graafilisel viitel).&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1484370636" CREATED="1124560950717" MODIFIED="1216187545225">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Graafilise viite kustutamiseks kasuta graafilise viite kiirmen&amp;#252;&amp;#252;d (hiire paremklahvi alt vali: Kustuta graafiline viide).&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1015136152" CREATED="1124560950717" MODIFIED="1216187545225">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Et kiiresti liikuda (fokusseerida vaade) graafilise viite algus- v&amp;#245;i l&amp;#245;pp-punkti, kasuta selle viite kiirmen&amp;#252;&amp;#252;d.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_266716332" CREATED="1124560950717" MODIFIED="1216187545225">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Graafilise viite liigutamiseks ja asendi muutmiseks, haara hiire vasaku klahviga sellest kinni ja muuda noole asendit.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1015289745" CREATED="1124560950717" MODIFIED="1216187545225">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_266716332" STARTINCLINATION="244;32;" ENDINCLINATION="256;22;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Allj&#xe4;rgnevalt graafiliste viidete n&#xe4;ited." ID="ID_315327090" CREATED="1124560950717" MODIFIED="1216187545225">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="N&#xe4;idis" FOLDED="true" ID="ID_444873207" CREATED="1124560950717" MODIFIED="1216200835997" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Viide teisele osale" ID="_Freeplane_Link_1170112929" CREATED="1124560950717" MODIFIED="1216187545225" COLOR="#996600">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#9999ff" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1492563156" STARTINCLINATION="154;-6;" ENDINCLINATION="154;-5;" STARTARROW="DEFAULT" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lm koos kokkuvolditud alams&amp;#245;lmega&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" FOLDED="true" ID="ID_210427206" CREATED="1124560950717" MODIFIED="1216187545225" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Alams&#xf5;lm" ID="_Freeplane_Link_1492563156" CREATED="1124560950717" MODIFIED="1216187545224"/>
</node>
<node TEXT="Teine viide" ID="_Freeplane_Link_1370577235" CREATED="1124560950717" MODIFIED="1216187545224" COLOR="#996600">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#b0b0b0" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1170112929" STARTINCLINATION="28;1;" ENDINCLINATION="126;16;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Otsimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_423038022" CREATED="1124560950717" MODIFIED="1216201160414" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Teksti otsimiseks s&amp;#245;lmest ja selle all olevatest s&amp;#245;lmedest, vajuta CTRL + F v&amp;#245;i rippmen&amp;#252;&amp;#252;st vali Redigeerimine -&amp;gt; Otsi.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_729626319" CREATED="1124560950717" MODIFIED="1216187545224">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      J&amp;#228;rgmise vastavuse otsimiseks sama otsingus&amp;#245;naga, vajuta CTRL + G v&amp;#245;i rippmen&amp;#252;&amp;#252;st vali Redigeerimine -&amp;gt; Otsi j&amp;#228;rgmine.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1108790262" CREATED="1124560950717" MODIFIED="1216187545224">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kogu kaardi ulatuses globaalse otsingu sooritamiseks tuleb eelnevalt ESC-klahvi abil peas&amp;#245;lm aktiveerida ehk siis kaart algasendisse viia..&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1842831668" CREATED="1124560950717" MODIFIED="1216187545223">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Otsingu laius s&amp;#245;ltub sisestatud otsingus&amp;#245;nast(-dest). See vastab ideele, et mida s&amp;#252;gavam on s&amp;#245;lm, seda parem on detail, mis on s&amp;#245;lmes kirjeldatud.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1918000612" CREATED="1124560950717" MODIFIED="1216187545223">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Pea meeles, et mitte kogu kaarti ei otsita l&amp;#228;bi vaid ainult konkreetne s&amp;#245;lm ja selle all olevad s&amp;#245;lmed.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1054705788" CREATED="1124560950717" MODIFIED="1216187545223">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Mitme s&#xf5;lme valimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_653540280" CREATED="1124560950717" MODIFIED="1216201160415" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Mitme s&amp;#245;lme korraga valimiseks hoia hiire vasaku klahviga kl&amp;#245;psamise ajal all kas CTRL- v&amp;#245;i SHIFT-klahvi.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1989692981" CREATED="1124560950717" MODIFIED="1216187545217">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Juba valitud s&amp;#245;lmele alams&amp;#245;lme lisamiseks, hoia hiire vasaku klahviga kl&amp;#245;psamise ajal all CTRL-klahvi.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_139767984" CREATED="1124560950717" MODIFIED="1216187545197">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      J&amp;#228;rjestikku mitme s&amp;#245;lme valimiseks hoia hiire vasaku klahviga kl&amp;#245;psimise ajal v&amp;#245;i siis nooleklahvide abil liikudes all SHIFT klahvi.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_108535754" CREATED="1124560950717" MODIFIED="1216187545173">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kogu s&amp;#245;lmepuu valimiseks vajuta CTRL + SHIFT + A v&amp;#245;i hoia all SHIFT-klahvi kui nooleklahviga s&amp;#245;lmepuus allapoole liigud.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1610175580" CREATED="1124560950717" MODIFIED="1216187545146">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Mitme s&amp;#245;lme m&amp;#228;rkimise eemaldamiseks kl&amp;#245;psa kaardi taustal v&amp;#245;i valimata s&amp;#245;lmel.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1616941396" CREATED="1124560950717" MODIFIED="1216187545118">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      K&amp;#245;ikide n&amp;#228;htavate (ehk siis kogu kaardil olevate) s&amp;#245;lmede m&amp;#228;rkimiseks vali CTRL + A v&amp;#245;i rippmen&amp;#252;&amp;#252;st Redigeerimine -&amp;gt; Vali k&amp;#245;ik n&amp;#228;htav.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_227748526" CREATED="1124560950717" MODIFIED="1216187545096">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Haaramine ja lohistamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1024903226" CREATED="1124560950717" MODIFIED="1216201160415" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Sa saad s&amp;#245;lmi liigutada kui hiire vasaku klahviga neist kinni haarad ja uues kohas lahti lased.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_250792124" CREATED="1124560950717" MODIFIED="1216189240840">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme liigutamiseks tuleb hiire vasaku klahviga haarata kinni selle ees olevast s&amp;#245;&amp;#245;rist, mis ilmub sinna hiirekursori liigutamisel.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1720133090" CREATED="1124560950717" MODIFIED="1216189839238">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme viimiseks otse peas&amp;#245;lme alla, haara lihtsalt hiire vasaku klahviga s&amp;#245;lmest kinni ja lohista peas&amp;#245;lme kohale.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1326060747" CREATED="1124560950717" MODIFIED="1216189990967">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme kopeerimiseks (mitte liigutamiseks), hoia all CTRL-klahvi kui lohistad v&amp;#245;i lohista hiire keskmist klahvi all hoides.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_1994214827" CREATED="1124560950717" MODIFIED="1216190054560">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Olemasoleva kaardi muutmiseks, lohista ja kukuta see Freeplane-i taustale. See t&amp;#246;&amp;#246;tab v&amp;#228;hemalt MS Windowsi operatsioonis&amp;#252;steemis.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_489432369" CREATED="1124560950717" MODIFIED="1216190811579">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Graafilise viite loomiseks hoia all CTRL + SHIFT klahve ja siis haara ja kukuta &amp;#252;ks s&amp;#245;lm teise peale.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_503769565" CREATED="1124560950717" MODIFIED="1216190863653">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kui mitu s&amp;#245;lme on valitud siis neid k&amp;#245;iki liigutatakse v&amp;#245;i kopeeritakse.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1640826119" CREATED="1124560950717" MODIFIED="1216190918888">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Sa v&amp;#245;id kukutada infot v&amp;#228;listest rakendustest, n&amp;#228;iteks faile MS Windowsi operatsioonis&amp;#252;steemis, v&amp;#245;i m&amp;#228;rgitud tekstijuppe MS Internet Explorerist.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1894344956" CREATED="1124560950717" MODIFIED="1216190990203">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Kopeerimine ja asetamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_958781924" CREATED="1124560950717" MODIFIED="1216201212458" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Sa saad kopeerida ja asetada (mitut) s&amp;#245;lme erinevate m&amp;#245;ttekaartide vahel. Lisaks saad asetada tavalist teksti v&amp;#245;i HTML-i teistest programmidest.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_577944755" CREATED="1124560950717" MODIFIED="1216191126681">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kui asetad tavalist teksti siis eraldi ridadel olev tekst asetatakse eraldi s&amp;#245;lmedena koos nende s&amp;#252;gavustega, mis m&amp;#228;&amp;#228;ratakse kindlaks teksti m&amp;#228;rkide arvuga. Allpool ka m&amp;#245;ned n&amp;#228;ited.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_257303524" CREATED="1124560950717" MODIFIED="1216191297451">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Puu&lt;br &gt;&amp;#160;&amp;#160;&amp;#160;&amp;#160;&amp;#160;Tamm&lt;br &gt;&amp;#160;&amp;#160;&amp;#160;&amp;#160;&amp;#160;P&amp;#246;&amp;#246;k&lt;br &gt;&amp;#160;&amp;#160;&amp;#160;&amp;#160;&amp;#160;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" FOLDED="true" ID="ID_931741001" CREATED="1124560950717" MODIFIED="1216200835998" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="asetatakse kui" FOLDED="true" ID="ID_1174875076" CREATED="1124560950717" MODIFIED="1216191388934">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Puu" FOLDED="true" ID="ID_630727847" CREATED="1124560950717" MODIFIED="1216191387928" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Tamm" ID="ID_10517981" CREATED="1124560950717" MODIFIED="1216191366645" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="P&#xf6;&#xf6;k" ID="ID_1473809424" CREATED="1124560950717" MODIFIED="1216191371256" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kui asetad HTML-i siis asetatakse see kui paljas tekst. Lisaks asetatakse HTML-is olnud viited alams&amp;#245;lmedena. Allpool ka m&amp;#245;ned n&amp;#228;ited.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1117632907" CREATED="1124560950717" MODIFIED="1216191656046">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="N&#xe4;idistulemus p&#xe4;rast asetamist:" FOLDED="true" ID="ID_1182968610" CREATED="1124560950717" MODIFIED="1216200835998">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Ostmine (120236)" ID="ID_1854872512" CREATED="1124560950717" MODIFIED="1216195174178">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Linnaelu (19)" ID="ID_1197617245" CREATED="1124560950717" MODIFIED="1216195181063">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Viited" FOLDED="true" ID="ID_1425509419" CREATED="1124560950717" MODIFIED="1216197300613">
<font NAME="Dialog" SIZE="12" BOLD="true"/>
<node TEXT="Ostmine" ID="ID_1869102188" CREATED="1124560950717" MODIFIED="1216195187114" LINK="http://directory.google.com/Top/Shopping/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Linnaelu" ID="ID_1972970821" CREATED="1124560950717" MODIFIED="1216195192339" LINK="http://directory.google.com/Top/Home/Urban_Living/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kui asetad failide nimekirja MS Explorerist MS Windowsis siis see asetatakse viidetena neile failidele.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_479429594" CREATED="1124560950717" MODIFIED="1216195518969">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kui Sa kopeerid Freeplane-is s&amp;#245;lmede haru ja asetad selle lihtsasse tekstiredaktorisse siis s&amp;#245;lmede puu struktuuri n&amp;#228;idatakse taanetega. H&amp;#252;perviited paigutatakse &amp;lt;&amp;gt; sulgude vahele vahele. Allpool ka m&amp;#245;ned n&amp;#228;ited.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1680490246" CREATED="1124560950717" MODIFIED="1216195773963">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Puu" FOLDED="true" ID="ID_1454908790" CREATED="1124560950717" MODIFIED="1216200835998" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Tamm" ID="ID_633110419" CREATED="1124560950717" MODIFIED="1216195798447" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="P&#xf6;&#xf6;k" FOLDED="true" ID="ID_838560951" CREATED="1124560950717" MODIFIED="1216200829358" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="asetatakse kui" FOLDED="true" ID="ID_1676658451" CREATED="1124560950717" MODIFIED="1216197295548">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Puu&lt;br &gt;&amp;#160;&amp;#160;&amp;#160;&amp;#160;&amp;#160;Tamm&lt;br &gt;&amp;#160;&amp;#160;&amp;#160;&amp;#160;&amp;#160;P&amp;#246;&amp;#246;k&lt;br &gt;&amp;#160;&amp;#160;&amp;#160;&amp;#160;&amp;#160;Google &amp;lt;http://www.google.ee/&amp;gt;&lt;br &gt;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1486548715" CREATED="1124560950732" MODIFIED="1216195827676" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Google" ID="ID_1324389903" CREATED="1124560950732" MODIFIED="1216195837675" LINK="http://www.google.ee/" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kui Freeplane-is kopeerida s&amp;#245;lmede haru ja asetada see redaktorisse, mis m&amp;#245;istab rikkalikku teksti vormindust siis see vormindus koos teksti v&amp;#228;rvi ja kirjakujuga asetatakse samuti. H&amp;#252;perviited asetatakse &amp;lt;&amp;gt; sulgudesse kui tavaline tekst. Redaktorid, mis m&amp;#245;istavad rikkalikku teksti vormindamist: MS Word, MS Wordpad or MS Outlook, v&amp;#245;i m&amp;#245;ned kaartidega tekstiredaktorid Linuxis.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1898109526" CREATED="1124560950732" MODIFIED="1216196259445">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme kopeerimiseks ilma alams&amp;#245;lmedeta, vajuta CTRL + Y v&amp;#245;i s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st kasuta valikut Kopeeri &amp;#252;ksik.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1853517240" CREATED="1124560950732" MODIFIED="1216197263566">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Liigutamine" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1540212684" CREATED="1124560950732" MODIFIED="1216201160416" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Tekstikursori liigutamiseks &amp;#252;les, alla, vasakule v&amp;#245;i paremale; kasuta nooleklahve.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1635291337" CREATED="1124560950732" MODIFIED="1216200459000">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Hetkel eesoleva s&amp;#245;lmede haru algusesse liikumiseks vajuta PageUp klahvile.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1763373897" CREATED="1124560950732" MODIFIED="1216200543444">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Hetkel eesoleva s&amp;#245;lmede haru l&amp;#245;ppu liikumiseks vajuta PageDown klahvile.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1810026836" CREATED="1124560950732" MODIFIED="1216200571377">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Keskele peas&amp;#245;lme juurde liikumiseks vajuta ESC-klahvile.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1423109092" CREATED="1124560950732" MODIFIED="1216200609283">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme vabaks paigutamiseks kaardil lohista seda tema n&amp;#228;htamatust s&amp;#245;&amp;#245;rist (asub s&amp;#245;lme ees ja ilmub n&amp;#228;htavale kui hiir selle kohale viia) kinni haarates.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="_Freeplane_Link_97763226" CREATED="1124560950732" MODIFIED="1216200695317">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="S&#xf5;lmede kokku- ja lahtivoltimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_4727471" CREATED="1124560950732" MODIFIED="1216201537122" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme kokkuvoltimiseks vajuta t&amp;#252;hikuklahvi v&amp;#245;i s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st vali: L&amp;#252;lita voltimist &amp;#252;mber.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_993136713" CREATED="1124560950732" MODIFIED="1216200802609">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lme lahtivoltimiseks vajuta t&amp;#252;hikuklahvi v&amp;#245;i s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st vali: L&amp;#252;lita voltimist &amp;#252;mber.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_635085497" CREATED="1124560950732" MODIFIED="1216200820736">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Tasemete kokku/lahti voltimiseks hoia alla ALT-klahvi ja samal ajal keri hiireratast, v&amp;#245;i vajuta ALT+PageUp v&amp;#245;i ka ALT + PageDown. Suurte ja mahukate kaartide puhul on soovitav seda omadust ettevaatlikult kasutada kuna siin v&amp;#245;ib tekkida probleeme (nt m&amp;#228;lu j&amp;#228;&amp;#228;b v&amp;#228;heks).&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1966037322" CREATED="1124560950732" MODIFIED="1216201147632">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      K&amp;#245;ikide s&amp;#245;lmede korraga lahtivoltimiseks vajuta halli plussm&amp;#228;rgiga nuppu t&amp;#246;&amp;#246;riistaribal v&amp;#245;i kasuta rippmen&amp;#252;&amp;#252;d Liikumine -&amp;gt; Voldi k&amp;#245;ik lahti.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_780574400" CREATED="1124560950732" MODIFIED="1216201322323">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      K&amp;#245;ikide s&amp;#245;lmede korraga kokkuvoltimiseks vajuta halli miinusm&amp;#228;rgiga nuppu t&amp;#246;&amp;#246;riistaribal v&amp;#245;i kasuta rippmen&amp;#252;&amp;#252;d Liikumine -&amp;gt; Voldi k&amp;#245;ik kokku.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_150591996" CREATED="1124560950732" MODIFIED="1216201375516">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kokkuvolditud s&amp;#245;lm on t&amp;#228;histatud v&amp;#228;ikese ringiga selle alumise parema nurga juures.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1059424946" CREATED="1124560950732" MODIFIED="1216201528954">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="M&#xf5;ttekaartide kerimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_467411537" CREATED="1124560950732" MODIFIED="1216201656349" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kaardi kerimiseks lohista seda hiire vasaku klahviga taustast kinni v&amp;#245;ttes v&amp;#245;i lihtsalt hiire ratast kerides. Horisontaalselt hiire rattaga kerimiseks hoia samaegselt all SHIFT-klahvi v&amp;#245;i m&amp;#245;nda hiire klahvi.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_109928081" CREATED="1124560950732" MODIFIED="1216201653254">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Suurendamine/v&#xe4;hendamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_913137192" CREATED="1124560950732" MODIFIED="1216201877888" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Suurenduse muutmiseks hoia samaaegselt all CTRL-klahvi ning keri hiireratast, v&amp;#245;i hoia samaaegselt all ALT-klahvi ning kasuta &amp;#252;les (v&amp;#228;hendab) / alla (suurendab) nooleklahve. &amp;#220;he v&amp;#245;imalusena v&amp;#245;ib kasutada ka suurenduse t&amp;#246;&amp;#246;riista peamisel t&amp;#246;&amp;#246;riistaribal.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_385482752" CREATED="1124560950732" MODIFIED="1216201869456">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Tegevuste tagasiv&#xf5;tmine ja taastamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1318678369" CREATED="1124560950732" MODIFIED="1216202018927" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Tegevuse tagasiv&amp;#245;tmiseks vajuta CTRL + Z v&amp;#245;i kasuta rippmen&amp;#252;&amp;#252;d Redigeerimine -&amp;gt; V&amp;#245;ta tagasi.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_45554617" CREATED="1124560950732" MODIFIED="1216201918241">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Tegevuse uuestitegemiseks vajuta CTRL + Y v&amp;#245;i vali rippmen&amp;#252;&amp;#252;st Redigeerimine -&amp;gt; Tee uuesti.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_725481570" CREATED="1124560950732" MODIFIED="1216201956499">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Tagasiv&amp;#245;tmise sammude arvu seadistamiseks kasuta rippmen&amp;#252;&amp;#252;d T&amp;#246;&amp;#246;riistad -&amp;gt; Eelistused.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1106402597" CREATED="1124560950732" MODIFIED="1216202013857">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Eksportimine HTML-i" FOLDED="true" POSITION="right" ID="Freeplane_Link_22510332" CREATED="1124560950732" MODIFIED="1216202445145" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lmede haru HTML-i eksportimiseks vajuta CTRL + H. Eksporditud HTML-leht v&amp;#245;ib toetada ka voltimise funktsionaalsust s&amp;#245;ltuvalt sellest, mis oli m&amp;#228;&amp;#228;ratud programmi eelistustes.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1878904964" CREATED="1124560950732" MODIFIED="1216202111782">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Et kasutada teist eksportimise funktsiooni, kasuta rippmen&amp;#252;&amp;#252; valikut Ekspordi -&amp;gt; Kui XHTML (Javascript-i versioon).&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_62201964" CREATED="1124560950732" MODIFIED="1216202205806">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Et eksportida koos &amp;#252;levaatliku pildiga HTML-i, kasuta rippmen&amp;#252;&amp;#252;st valikut Ekspordi -&amp;gt; Kui HTML (kl&amp;#245;psatav kaart, pildiversioon).&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_83386080" CREATED="1124560950732" MODIFIED="1216202417810">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Eksportimine raster- v&#xf5;i vektorgraafiliseks pildiks" FOLDED="true" POSITION="right" ID="Freeplane_Link_1908686168" CREATED="1124560950732" MODIFIED="1216202912603" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kaardi eksportimiseks PNG-pildiks, kasuta rippmen&amp;#252;&amp;#252; valikut Fail -&amp;gt; Ekspordi -&amp;gt; Kui PNG&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1072927157" CREATED="1124560950732" MODIFIED="1216202492752">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Kaardi eksportimiseks JPG-pildiks, kasuta rippmen&#xfc;&#xfc; valikut Fail -&gt; Ekspordi -&gt; Kui JPEG" ID="ID_491092630" CREATED="1124560950732" MODIFIED="1216202523501">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kaardi eksportimiseks SVG-pildiks, kasuta rippmen&amp;#252;&amp;#252; valikut Fail -&amp;gt; Ekspordi -&amp;gt; Kui SVG&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      See funktsioon on saadaval vaid siis kui oled paigaldanud SVG-pistikprogrammi.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_161038476" CREATED="1124560950732" MODIFIED="1216202721190">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Teistesse XML-vormingutesse eksportimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_329770204" CREATED="1124560950732" MODIFIED="1216203705284" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kaardi eksportimiseks teise XML-p&amp;#245;hisesse vormingusse, mille jaoks on eraldi XSLT vorm olemas, kasuta rippmen&amp;#252;&amp;#252; valikut Fail -&amp;gt; Ekspordi -&amp;gt; Kasutades XSLT-d&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1487291576" CREATED="1124560950732" MODIFIED="1216203273703">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kaardi eksportimiseks OpenOffice.org Writer-i dokumendiks kasuta rippmen&amp;#252;&amp;#252;st valikut Fail -&amp;gt; Ekspordi -&amp;gt; OpenOffice.org Writer-i dokument.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_306816886" CREATED="1124560950732" MODIFIED="1216203610047">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Kataloogi struktuuri importimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1841136119" CREATED="1124560950732" MODIFIED="1216217093567" COLOR="#407000">
<font NAME="Dialog" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kataloogide struktuuri importimiseks vali rippmen&amp;#252;&amp;#252;st Fail -&amp;gt; Impordi -&amp;gt; Kataloogide struktuur&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Siis k&amp;#252;sitakse kataloogi, mille struktuuri soovitakse importida. Kataloogistruktuuri all m&amp;#245;eldakse kataloogidest ja nende sees olevatest alamkataloogidest ning failidest koosnevat puud. Allpool on toodud ka n&amp;#228;idis.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1167782124" CREATED="1216211946553" MODIFIED="1216217050308"/>
<node TEXT="N&#xe4;idis" FOLDED="true" ID="ID_1586593732" CREATED="1124560950732" MODIFIED="1216217084661" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Valitud kataloog" FOLDED="true" ID="ID_946625728" CREATED="1124560950732" MODIFIED="1216217082479" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps" ID="ID_474941936" CREATED="1124560950732" MODIFIED="1216187545041" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Dbwiz" FOLDED="true" ID="ID_1954366926" CREATED="1124560950732" MODIFIED="1216217073101" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="ASSETS.GIF" ID="ID_950167286" CREATED="1124560950732" MODIFIED="1216187545041" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ASSETS.GIF"/>
<node TEXT="CONTACTS.GIF" ID="ID_800426055" CREATED="1124560950732" MODIFIED="1216187545041" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF"/>
<node TEXT="EVTMGMT.GIF" ID="ID_1258787730" CREATED="1124560950732" MODIFIED="1216187545041" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF"/>
<node TEXT="EXPENSES.GIF" ID="ID_1788007193" CREATED="1124560950732" MODIFIED="1216187545041" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF"/>
<node TEXT="INVENTRY.GIF" ID="ID_721190495" CREATED="1124560950732" MODIFIED="1216187545041" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF"/>
<node TEXT="LEDGER.GIF" ID="ID_38242249" CREATED="1124560950732" MODIFIED="1216187545041" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/LEDGER.GIF"/>
<node TEXT="ORDPROC.GIF" ID="ID_1108543275" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF"/>
<node TEXT="RESOURCE.GIF" ID="ID_1051785223" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF"/>
<node TEXT="SERVICE.GIF" ID="ID_413667716" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/SERVICE.GIF"/>
<node TEXT="TIMEBILL.GIF" ID="ID_294983675" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF"/>
</node>
<node TEXT="Stiilid" FOLDED="true" ID="ID_706370356" CREATED="1124560950732" MODIFIED="1216217072054" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="ACBLENDS.GIF" ID="ID_1010772548" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLENDS.GIF"/>
<node TEXT="ACBLUPRT.GIF" ID="ID_1767567712" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLUPRT.GIF"/>
<node TEXT="ACEXPDTN.GIF" ID="ID_62852524" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACEXPDTN.GIF"/>
<node TEXT="ACINDSTR.GIF" ID="ID_1590095220" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACINDSTR.GIF"/>
<node TEXT="ACRICEPR.GIF" ID="ID_476038182" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACRICEPR.GIF"/>
<node TEXT="ACSNDSTN.GIF" ID="ID_1855878202" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSNDSTN.GIF"/>
<node TEXT="ACSUMIPT.GIF" ID="ID_763481040" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSUMIPT.GIF"/>
<node TEXT="GLOBE.WMF" ID="ID_1894968636" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF"/>
<node TEXT="STONE.BMP" ID="ID_910938684" CREATED="1124560950732" MODIFIED="1216187545040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP"/>
</node>
</node>
</node>
<node TEXT="MS Internet Explorer-i j&#xe4;rjehoidjate importimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_269203785" CREATED="1124560950732" MODIFIED="1216217579976" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      MS Internet Explorer-i j&amp;#228;rjehoidjate importimiseks Freeplane-i valida rippmen&amp;#252;&amp;#252;st Fail -&amp;gt; Impordi -&amp;gt; MS Internet Explorer-i j&amp;#228;rjehoidjad. Siis k&amp;#252;sitakse otsiteekonda, kuhu j&amp;#228;rjehoidjad on salvestatud. Kataloog nimega &amp;quot;J&amp;#228;rjehoidjad&amp;quot; (ingl.k. &apos;Favorites&apos;) asub inglisekeelse MS Windows 2000/XP puhul C:\Documents and Settings\&amp;lt;kasutajanimi&amp;gt;\Favorites&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="Freeplane_Link_260446736" CREATED="1124560950732" MODIFIED="1216217403619">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="M&#xe4;rks&#xf5;nad: Microsoft Internet Explorer, MS Internet Explorer MSIE, MS IE." ID="ID_332563589" CREATED="1124560950732" MODIFIED="1216217570092" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="MindManager X5 m&#xf5;ttekaardi importimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1709974530" CREATED="1124560950732" MODIFIED="1216217672715" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      MindManager X5 m&amp;#245;ttekaardi importimiseks valida rippmen&amp;#252;&amp;#252;st Fail -&amp;gt; Impordi -&amp;gt; MindManager X5 kaart&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1753949120" CREATED="1124560950732" MODIFIED="1216217660535">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="MS Word-i v&#xf5;i MS Outlook-iga integreerimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_913645795" CREATED="1124560950732" MODIFIED="1216218225233" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Sa saad asetada kaarte v&amp;#245;i selle osi MS Word-i, MS Wordpad-i v&amp;#245;i MS Outlook-i kirjadesse. &amp;#220;ldiselt saab neid asetada suvalisse programmi, mis saab aru rikkast teksti vormindamisest. Teksti vormindus ja viited v&amp;#245;etakse samuti asetamisel kaasa.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1037098567" CREATED="1124560950732" MODIFIED="1216217849442">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Kl&amp;#245;psates e-posti viitel (n&amp;#228;iteks &lt;i&gt;mailto:eesnimi.perenimi@mail.ee&lt;/i&gt;) avatakse vaikimisi e-postiprogramm uue kirjaga MS Windows-is.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_599307523" CREATED="1124560950732" MODIFIED="1216218092775" LINK="mailto:don.bonton@supermail.com">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="E-posti viites saab kasutada teema etteandmist." ID="ID_912458776" CREATED="1124560950732" MODIFIED="1216217984233" LINK="mailto:don.bonton@supermail.com?subject=Last%20phone%20call">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Teine v&amp;#245;imalus on m&amp;#245;ttekaart asetada MS Word-i, seda eelnevalt HTML-i v&amp;#228;lja eksportides ja siis omakorda HTML-versiooni kopeerides-asetades MS Word-i.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1653504142" CREATED="1124560950732" MODIFIED="1216218218990">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Eelistuste seadistamine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1822195277" CREATED="1124560950732" MODIFIED="1216220330553" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Eelistuste redigeerimiseks ava T&amp;#246;&amp;#246;riistad -&amp;gt; Eelistused. Enamus eelistuste muudatused j&amp;#245;ustuvad Freeplane-i uuestik&amp;#228;ivitamisel.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1947073053" CREATED="1124560950732" MODIFIED="1216218284690">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Eelistuste abil saab seadistada: kiirklahvid, HTML-i eksportimise seaded, viis kuidas s&amp;#245;lmede valimine hiirega k&amp;#228;itub, kirjakujude ja servade ning joonte pehmendamine (ingl.k. &apos;antialiasing&apos;), jne.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1428285526" CREATED="1124560950732" MODIFIED="1216220284584">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="V&#xf5;tmes&#xf5;nad: muutmine, eelistused, seadistused" ID="ID_1747353627" CREATED="1124560950732" MODIFIED="1216220324300" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Printimine" FOLDED="true" POSITION="right" ID="Freeplane_Link_1528828442" CREATED="1124560950732" MODIFIED="1216228616420" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Printida saab nii, et kogu kaart mahutatakse &amp;#252;hele lehele v&amp;#245;i ka mitmele lehele. Seda saab seadistada Fail -&amp;gt; Lehek&amp;#252;lje seaded&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1240927179" CREATED="1124560950732" MODIFIED="1216220425067">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Ruumi paremaks &amp;#228;rakasutamiseks valida R&amp;#245;htasetus (ingl.k. &apos;landscape&apos;) lehek&amp;#252;lje seadistustes.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_176846213" CREATED="1124560950732" MODIFIED="1216221180496">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Eelvaade enne printimist ei ole tingimata vajalik. Kui Sul on PostScript printer siis saab kaardi printida *.ps faili ja vaadata seda sealt. Kui prindid printeriga, mis ei saa PostScript-ist aru siis printerile saab saata ehk faili, mis on PCL-is, mida aga ei saa ise arvutis kasutada.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_281927805" CREATED="1124560950732" MODIFIED="1216227265273">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Samuti saab printida veebilehitsejast peale kaardi HTML-i eksportimist v&amp;#245;i ka p&amp;#228;rast MS Word-i, MS Wordpad-i kopeerimist-asetamist. Nii saab ka stiile muuta vastavalt vajadusele.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_758130759" CREATED="1124560950732" MODIFIED="1216228605559">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="HTML-i kasutamine s&#xf5;lmede kujundamisel" FOLDED="true" POSITION="right" ID="Freeplane_Link_841140408" CREATED="1124560950732" MODIFIED="1216229413099" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      S&amp;#245;lmed, mis algavad m&amp;#228;rgendiga &amp;lt;html&amp;gt;, visualiseeritakse kasutades HTML-koodi. See omadus on abiks tehniliselt p&amp;#228;devatele inimestele. Allpool m&amp;#245;ned n&amp;#228;ited.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_166500306" CREATED="1124560950732" MODIFIED="1216228737174">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;h3&gt;&#xa;      HTML-i n&amp;#228;idis&#xa;    &lt;/h3&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Loetelu:&#xa;    &lt;/p&gt;&#xa;    &lt;ul type=&quot;disc&quot;&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;        esimene&#xa;      &lt;/li&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;        teine&#xa;      &lt;/li&gt;&#xa;    &lt;/ul&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Veel v&amp;#245;ib teha &lt;b&gt;rasvast&lt;/b&gt; v&amp;#245;i &lt;i&gt;kaldkirja&lt;/i&gt;. Samuti &lt;u&gt;allajoonitud&lt;/u&gt; v&amp;#245;i &lt;strike&gt;l&amp;#228;bikriipsutatud&lt;/strike&gt; kirja. Ka tabelit saame teha:&#xa;    &lt;/p&gt;&#xa;    &lt;table cellpadding=&quot;0&quot; class=&quot;msonormaltable&quot; cellspacing=&quot;0&quot; border=&quot;1&quot; style=&quot;border: none&quot;&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;padding-left: .75pt; padding-top: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt; padding-right: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            lahter1&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border-left: none; padding-left: .75pt; padding-top: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt; padding-right: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            lahter2&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;border-top: none; padding-left: .75pt; padding-top: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt; padding-right: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            lahter3&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border-left: none; border-top: none; padding-left: .75pt; padding-top: .75pt; padding-bottom: .75pt; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; padding-right: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            lahter4&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;    &lt;/table&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Ka erinevaid&amp;#160;&lt;font color=&quot;#999900&quot;&gt;teksti&lt;/font&gt; &lt;font color=&quot;#336600&quot;&gt;v&amp;#228;rve&lt;/font&gt; saab kasutada.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_900496350" CREATED="1124560950732" MODIFIED="1216228939238">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      HTML-i eksport tekstiks v&amp;#245;i rikkalikuks tekstiks (MS Word, MS Wordpad, jne) ei toeta vorminduse v&amp;#245;i piltide kaasapanemist. Samas on HTML-i eksport mugav veebis kasutamiseks kui on olemas Freeplane-i rakend veebilehitsejale.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_661706379" CREATED="1124560950732" MODIFIED="1216229407096">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Piltide kasutamine s&#xf5;lmede illustreerimiseks" FOLDED="true" POSITION="right" ID="Freeplane_Link_271176250" CREATED="1124560950732" MODIFIED="1216246952682" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Pildi lisamiseks Freeplane-i vajuta ALT + K v&amp;#245;i vali s&amp;#245;lme kiirmen&amp;#252;&amp;#252;st Lisamine -&amp;gt; Pilt&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Pildi lisamisel kaob kogu s&amp;#245;lmes olnud tekst. Selliselt lisatud pildid on viited kuna Freeplane-i *.mm fail on XML-ile sarnase struktuuriga ja peavad asuma ka hiljem samas kohas kus nad olid Freeplane-i lisamise hetkel. M&amp;#245;eldud on siin suhtelist aadressi *.mm v&amp;#245;i *.html faili suhtes, s&amp;#245;ltuvalt sellest, milleks kaarti salvestatakse v&amp;#245;i eksporditakse. Piltide suuruse muutmiseks on v&amp;#245;imalik kasutada HTML-i. Piltide lisamine Freeplane-i on arendusj&amp;#228;rgus olev v&amp;#245;imalus ja ei ole veel l&amp;#245;puni v&amp;#228;lja arendatud.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1646926562" CREATED="1124560950732" MODIFIED="1216230555707">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Toetatud pildifailide vormingud on PNG, JPEG ja GIF.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_234082439" CREATED="1124560950732" MODIFIED="1216230706364">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Viidatud piltide n&amp;#228;htavaks muutmiseks vajuta ALT + K. Sa v&amp;#245;id haarata ja kukutada mitmeid pilte Freeplane-i, m&amp;#228;rkida neid kui mitut erinevat s&amp;#245;lme. See omadus peaks v&amp;#228;hemalt MS Windowsis t&amp;#246;&amp;#246;tama.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_249180132" CREATED="1124560950732" MODIFIED="1216243961428">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Rohkem tehniline ja mitte nii algaja kasutaja s&amp;#245;bralik on pilte v&amp;#245;imalik lisada HTML-i abil. Sa pead alustama s&amp;#245;lme teksti m&amp;#228;rgendiga &amp;lt;html&amp;gt; - nii saad lisada pilte s&amp;#245;lme.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_632640717" CREATED="1124560950732" MODIFIED="1216244094033" COLOR="#000000">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      N&amp;#228;iteks&lt;br &gt;&amp;#160;&amp;#160;&amp;lt;html&amp;gt;&amp;lt;img src=&amp;quot;pildid/oun.png&amp;quot;&amp;gt; - see on suhteline aadress&lt;br &gt;&amp;#160;&amp;#160;&amp;lt;html&amp;gt;&amp;lt;img src=&amp;quot;file://C:/Users/Dokumendid/m6ttekaardid/pildid/oun.png&amp;quot;&amp;gt; - see on absoluutne aadress (ei ole soovitav kasutada)&lt;br &gt;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1152828233" CREATED="1124560950732" MODIFIED="1216244204676">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Sa v&amp;#245;id kasutada suhtelisi viiteid piltidele (v&amp;#228;ga soovitatav).&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1156720512" CREATED="1124560950732" MODIFIED="1216244235915">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      M&amp;#245;ned piltide lisamise n&amp;#228;ited, mis t&amp;#246;&amp;#246;tavad vastavates operatsioonis&amp;#252;steemides&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" FOLDED="true" ID="Freeplane_Link_1825247742" CREATED="1124560950732" MODIFIED="1216246934166" COLOR="#996600">
<font NAME="SansSerif" SIZE="12" BOLD="true"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &lt;img src=&quot;/usr/share/pixmaps/abiword.png&quot; &gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Linuxis Abiword&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_384038147" CREATED="1124560950732" MODIFIED="1216245022354">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF&quot; &gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      MS Windowsis MS Office&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_520083225" CREATED="1124560950732" MODIFIED="1216245000432">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &lt;img src=&quot;../../../../usr/share/pixmaps/vlc.png&quot; &gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Linuxis VLC&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_894022254" CREATED="1124560950732" MODIFIED="1216245014860">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &lt;img src=&quot;../../../../usr/share/pixmaps/thunderbird.png&quot; &gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Linuxis Thunderbird&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1825871160" CREATED="1124560950732" MODIFIED="1216244986912"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF&quot; &gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      MS Windowsis MS Office&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1605523460" CREATED="1124560950732" MODIFIED="1216245006660">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &lt;img src=&quot;../../../../usr/share/icons/skype.png&quot; &gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Linuxis Skype&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1830235047" CREATED="1124560950732" MODIFIED="1216244979507">
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      &lt;img src=&quot;../../../../usr/share/icons/amsn.png&quot; &gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Linuxis aMSN&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_306854150" CREATED="1124560950732" MODIFIED="1216245065511"/>
</node>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      GLOBE.WMF&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      MS Windowsis MS Office&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_860800567" CREATED="1124560950732" MODIFIED="1216245119049" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      autopackage-installer.png&#xa;    &lt;/p&gt;&#xa;    &lt;p&gt;&#xa;      Linuxis Synaptic&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_620168247" CREATED="1124560950732" MODIFIED="1216245224115" LINK="/usr/share/icons/autopackage-installer.png">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Eksperimentaalse faililukustuse kasutamine" FOLDED="true" POSITION="right" ID="ID_1101644015" CREATED="1124560950732" MODIFIED="1216247474477" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      K&amp;#228;esolev Freeplane-i versioon sisaldab katselist faililukustamise tuge, mis on vaikimisi v&amp;#228;lja l&amp;#252;litatud. Hetke seisuga ei ole k&amp;#245;ik asjad t&amp;#228;iuslikult veel lahendatud ent see peaks juba enamus olukordades t&amp;#246;&amp;#246;tama.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_155679724" CREATED="1124560950732" MODIFIED="1216247047622">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Faili lukustamine tagab selle, et sama faili ei muuda samal ajal rohkem kui &amp;#252;ks inimene v&amp;#228;ltimaks &amp;#252;ksteise poolt info &amp;#252;lekirjutamist.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1334618640" CREATED="1124560950732" MODIFIED="1216247111082">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Faililukustamise lubamiseks vali rippmen&amp;#252;&amp;#252;st T&amp;#246;&amp;#246;riistad -&amp;gt; Eelistused ja seal on esimese peat&amp;#252;ki &amp;quot;Keskkond&amp;quot; all jaotis &amp;quot;Failid&amp;quot; kus saab siis panna linnukese &amp;quot;Katseline faili lukustamine&amp;quot; ette.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1452514837" CREATED="1124560950732" MODIFIED="1216247269320">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Liikumine avatud m&#xf5;ttekaartide vahel" FOLDED="true" POSITION="right" ID="Freeplane_Link_516331171" CREATED="1124560950732" MODIFIED="1216247849400" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Teise, juba avatud m&amp;#245;ttekaardi peale liikumiseks saab teha eesoleval m&amp;#245;ttekaardi taustal hiire parema klahviga kl&amp;#245;psu ja sealt valida teine lahtiolev m&amp;#245;ttekaart. Samuti saab hiire vasaku klahviga kl&amp;#245;psata &amp;#252;laservas olevatel sakkidel. Klahvikombinatsioon on ALT + SHIFT + nooleklahv vasakule/paremale&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1694364871" CREATED="1124560950732" MODIFIED="1216247470550">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</map>
