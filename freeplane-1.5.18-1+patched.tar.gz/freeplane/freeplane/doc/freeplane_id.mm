<map version="freeplane 1.5.9">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body width=&quot;&quot;&gt;&#xa;    &lt;p align=&quot;center&quot;&gt;&#xa;      Freeplane&lt;br &gt;&lt;small&gt;- perangkat lunak bebas untuk&lt;/small&gt;&lt;br &gt;&lt;small&gt;pembuatan MindMap -&lt;/small&gt;&amp;#160;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" FOLDED="false" ID="ID_1694064349" CREATED="1124560950701" MODIFIED="1207926619789" COLOR="#993300">
<font NAME="Dialog" SIZE="18" BOLD="true"/>
<hook NAME="MapStyle">
    <properties fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt" TEXT_SHORTENED="true">
<font SIZE="24"/>
<richcontent TYPE="DETAILS" LOCALIZED_HTML="styles_background_html"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="default" COLOR="#000000" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0.0 pt" FORMAT="NO_FORMAT" TEXT_ALIGN="CENTER" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font NAME="Arial" SIZE="9" BOLD="true" ITALIC="false"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details">
<font SIZE="11"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#000000" BACKGROUND_COLOR="#ffffff">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
<edge COLOR="#0000cc"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" UNIFORM_SHAPE="true" MAX_WIDTH="120.0 pt" MIN_WIDTH="120.0 pt">
<font SIZE="24" ITALIC="true"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2">
<edge COLOR="#ff0033"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3">
<edge COLOR="#009933"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4">
<edge COLOR="#3333ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5">
<edge COLOR="#ff6600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6">
<edge COLOR="#cc00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7">
<edge COLOR="#ffbf00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8">
<edge COLOR="#00ff99"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9">
<edge COLOR="#0099ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10">
<edge COLOR="#996600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12">
<edge COLOR="#cc0066"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13">
<edge COLOR="#33ff00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14">
<edge COLOR="#ff9999"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15">
<edge COLOR="#0000cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16">
<edge COLOR="#cccc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17">
<edge COLOR="#0099cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18">
<edge COLOR="#006600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19">
<edge COLOR="#ff00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20">
<edge COLOR="#00cc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21">
<edge COLOR="#0066cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22">
<edge COLOR="#00ffff"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="Situs web Freeplane" POSITION="left" ID="ID_278812263" CREATED="1124560950701" MODIFIED="1207927061884" LINK="http://freeplane.sourceforge.net">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Tabel kunci pintasan" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1091417446" CREATED="1124560950701" MODIFIED="1207927121089" COLOR="#006699">
<node TEXT="Perintah berkas:&#xa;Peta baru       - Ctrl+N&#xa;Buka peta       - Ctrl+O&#xa;Simpan peta     - Ctrl+S&#xa;Simpan sebagai  - Ctrl+A&#xa;Cetak           - Ctrl+P&#xa;Tutup           - Ctrl+W&#xa;Keluar          - Ctrl+Q&#xa;Peta sblmnya    - Ctrl+LEFT&#xa;Peta berikutnya - Ctrl+RIGHT&#xa;Ekspor berkas ke HTML            - Ctrl+E&#xa;Ekspor cabang ke HTML            - Ctrl+H&#xa;Ekspor cabang ke berkas MM baru  - Alt+A&#xa;Buka berkas pertama dari riwayat - Ctrl+Shift+W&#xa;&#xa;Perintah edit:&#xa;Cari            - Ctrl+F&#xa;Cari berikutnya - Ctrl+G&#xa;Potong          - Ctrl+X&#xa;Salin           - Ctrl+C&#xa;Salin tunggal   - Ctrl+Y&#xa;Tempelkan       - Ctrl+V&#xa;&#xa;Perintah modus:&#xa;Modus MindMap - Alt+1&#xa;Modus jelajah - Alt+2 &#xa;Modus berkas  - Alt+3&#xa;&#xa;Perintah pemformatan node:&#xa;Miringkan                 - Ctrl+I&#xa;Tebalkan                  - Ctrl+B&#xa;Awan                      - Ctrl+Shift+B&#xa;Ubah warna node           - Alt+C&#xa;Campur warna node         - Alt+B&#xa;Ubah warna tangkai node   - Alt+E&#xa;Perbesar font node        - Ctrl+L&#xa;Perkecil font node        - Ctrl+M&#xa;Perbesar font cabang      - Ctrl+Shift+L&#xa;Perkecil font cabang      - Ctrl+Shift+M&#xa;&#xa;Perintah navigasi node:&#xa;Pergi ke akar   - ESCAPE&#xa;Pindah ke atas  - UP&#xa;Pindah ke bawah - DOWN&#xa;Pindah ke kiri  - LEFT&#xa;Pindah ke kanan - RIGHT&#xa;Ikuti taut      - Ctrl+ENTER&#xa;Zum keluar      - Alt+UP&#xa;Zum masuk       - Alt+DOWN&#xa;&#xa;Perintah node baru:&#xa;Tambah node adik  - ENTER&#xa;Tambah node anak  - INSERT&#xa;Tambah node kakak - Shift+ENTER&#xa;&#xa;Perintah edit node:&#xa;Edit node terpilih        - F2&#xa;Edit node panjang         - Alt+ENTER&#xa;Gabungkan node            - Ctrl+J&#xa;Buka-tutup lipatan        - SPACE&#xa;Buka-tutup lipatan anak   - Ctrl+SPACE&#xa;Setel taut lewat pemilih berkas   - Ctrl+Shift+K&#xa;Setel taut lewat kolom teks       - Ctrl+K&#xa;Setel gambar lewat pemilih berkas - Alt+K&#xa;Pindahkan node ke atas    - Ctrl+UP&#xa;Pindahkan node ke bawah   - Ctrl+DOWN&#xa;" ID="ID_163135330" CREATED="1124560950701" MODIFIED="1208312544662">
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node TEXT="Instalasi" FOLDED="true" POSITION="left" ID="_Freeplane_Link_904501221" CREATED="1124560950701" MODIFIED="1208312560404" COLOR="#006633">
<node TEXT="Taut" ID="_Freeplane_Link_1911559485" CREATED="1124560950701" MODIFIED="1208312973308" COLOR="#006699">
<node TEXT="Unduh Java Runtime Environment (minimal J2RE1.4)" ID="ID_1972294106" CREATED="1124560950701" MODIFIED="1208312579943" LINK="http://java.sun.com/j2se">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Unduh Aplikasi Freeplane" ID="_Freeplane_Link_1612101865" CREATED="1124560950701" MODIFIED="1208312597618" LINK="http://sourceforge.net/project/showfiles.php?project_id=211069">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Untuk instalasi Freeplane di Microsoft Windows, pasang Java dari Sun lalu pasang Freeplane menggunakan program pemasang (installer) yang tersedia." ID="_Freeplane_Link_139664576" CREATED="1124560950701" MODIFIED="1208312738440"/>
<node TEXT="Untuk instalasi Freeplane di Linux, unduh Java Runtime Environment dan aplikasi Freeplane itu sendiri. Pasang Java terlebih dahulu, lalu bongkar (unpack) paket Freeplane. Untuk menjalankan Freeplane, jalankan freeplane.sh." ID="_Freeplane_Link_1380352758" CREATED="1124560950701" MODIFIED="1208312876759"/>
<node TEXT="Di Microsoft Windows dan Mac OS X, Anda juga dapat langsung mendobel-klik berkas freeplane.jar yang berlokasi di map bernama lib untuk memulai Freeplane." ID="_Freeplane_Link_1808511462" CREATED="1124560950701" MODIFIED="1208312948773"/>
</node>
<node TEXT="Menjelajahi berkas dalam komputer" FOLDED="true" POSITION="left" ID="_Freeplane_Link_353522063" CREATED="1124560950701" MODIFIED="1208313002620" COLOR="#407000">
<node TEXT="Untuk menjelajahi sistem berkas komputer, beralihlah ke modus File lewat perintah Peta &gt; File dari menu." ID="ID_350447496" CREATED="1124560950701" MODIFIED="1208313244338"/>
<node TEXT="Anda dapat menjelajahi struktur berkas seolah membaca MindMap." ID="ID_1896842303" CREATED="1124560950701" MODIFIED="1208313283114"/>
<node TEXT="Agar suatu map menjadi node yang mengambil posisi tengah, klik kanan pada node tersebut lalu pilih Tengah." ID="ID_1343540447" CREATED="1124560950701" MODIFIED="1208773411572"/>
<node TEXT="Untuk melihat, mengedit, atau menjalankan berkas, ikuti tautan node tersebut." ID="ID_305820556" CREATED="1124560950701" MODIFIED="1208773450654"/>
<node TEXT="Modus File saat ini tidak begitu bermanfaat, melainkan hanya untuk menunjukkan bahwa tidak sulit untuk mengumpankan data ke dalam peta dari sumber data lain selain MindMap. Sejauh ini tampaknya orang tidak akan benar-benar menggunakan modus ini." ID="_Freeplane_Link_279880616" CREATED="1124560950701" MODIFIED="1208773660294"/>
</node>
<node TEXT="Menjelajahi MindMap" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1530607683" CREATED="1124560950701" MODIFIED="1208773697151" COLOR="#407000">
<node TEXT="Untuk menjelajahi MindMap namun tanpa mengeditnya, beralihlah ke modus Browse melalui menu Peta &gt; Browse. Fungsi ini tidak digunakan selain daripada di dalam Freeplane applet.&#xa;" ID="ID_245563788" CREATED="1124560950701" MODIFIED="1208773837850"/>
<node TEXT="Ada alasan teknis mengapa modus Browse terpisah dibutuhkan. Menjelajah (browse) adalah satu-satunya operasi yang dapat dilakukan melalui Freeplane applet, yang dapat ditempelkan dalam laman web Anda. Umumnya, Anda tidak akan menggunakan modus Browse dalam Freeplane.&#xa;" ID="ID_729697699" CREATED="1124560950701" MODIFIED="1208773954416"/>
</node>
<node TEXT="Tentang modus" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1136088046" CREATED="1124560950701" MODIFIED="1208961883966" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Walaupun Freeplane utamanya adalah alat penyunting MindMap, desainnya memungkinkan pemakaian untuk membaca data dari berbagai sumber. Untuk membuat suatu sumber data tertentu tersedia untuk dilihat di Freeplane, pemrogram harus membuat apa yang disebut modus untuk sumber data tersebut. Salah satu contohnya adalah modus File. Setahu kami belum ada modus lain yang telah diimplementasi. Belum pasti apakah akan ada yang memanfaatkan arsitektur ini, namun hal ini bisa dilakukan bila diinginkan." ID="_Freeplane_Link_1713057526" CREATED="1124560950701" MODIFIED="1208962776570">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Contoh lain yang sudah hampir jadi dibuat adalah ada modus Scheme, untuk menyunting program dalam bahasa Scheme. Sekali lagi, manfaatnnya masih belum jelas. Kecuali modus MindMap, modus-modus lain lebih merupakan demonstrasi tentang apa yang mungkin dilakukan dengan program ini, bukan untuk benar-benar digunakan." ID="_Freeplane_Link_700085988" CREATED="1124560950701" MODIFIED="1208963696673">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Instalasi applet Freeplane di situs web Anda" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1525986009" CREATED="1124560950701" MODIFIED="1208963727668" COLOR="#407000">
<node TEXT="Anda dapat memasang applet Freeplane di situs web Anda agar orang dapat membaca MindMap Anda." ID="ID_686268443" CREATED="1124560950701" MODIFIED="1208963801474" COLOR="#000000">
<font NAME="Dialog" SIZE="12"/>
</node>
<node TEXT="Unduh applet, yaitu freeplane-browser." ID="ID_1433718684" CREATED="1124560950701" MODIFIED="1208963819980" LINK="http://sourceforge.net/project/showfiles.php?group_id=211069"/>
<node TEXT="Paket unduhan berisi freeplanebrowser.jar dan freeplanebrowser.html. Buat tautan dari laman web Anda ke freeplanebrowser.html. Di dalam freeplanebrowser.html, ganti jalur (path) dalam berkas tersebut agar menunjuk ke MindMap yang Anda buat." ID="ID_316824945" CREATED="1124560950701" MODIFIED="1208964470245"/>
<node TEXT="Berkas jar dari applet tersebut harus diletakkan di peladen yang sama dengan MindMap yang dibuka, sebagai syarat keamanan dari Java. Anda harus mengunggah berka jar applet Freeplane dan MindMap Anda ke laman web tersebut." ID="ID_1135453004" CREATED="1124560950701" MODIFIED="1208964565172"/>
</node>
<node TEXT="Menggunakan Freeplane applet" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1083756111" CREATED="1124560950701" MODIFIED="1208964602766" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Dalam applet Freeplane, Anda hanya dapat menggunakan modus Browse (jelajah), Anda tidak dapat menyunting peta dari jarak jauh. Klik node untuk membuka-tutup lipatan atau membuka tautan. Seret latar belakang untuk memindahkan peta. Untuk mencari dalam peta, gunakan menu konteks node." ID="_Freeplane_Link_514864900" CREATED="1124560950701" MODIFIED="1208965257287">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Perubahan antarmuka di versi 0.6.5" FOLDED="true" POSITION="left" ID="_Freeplane_Link_1976458022" CREATED="1124560950701" MODIFIED="1208965297475" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Beberapa setelan papan ketik didefinisikan ulang untuk menyamakan dengan apa yang dianggap setelan bersama atau yang intuitif. Beberapa dari setelan tersebut dimodelkan atas program-program Windows. Beberapa setelan baru misalnya Enter untuk membuat saudara baru di bawah node sekarang, Insert untuk membuat anak baru, F2 untuk mengedit Node - di sini pengaruh Microsoft sangat jelas walaupun tidak ada alasan intuitif mengapa F2 dipakai untuk mengedit node. Namun begitu Anda terbiasa dengan hal tersebut di semua aplikasi yang Anda gunakan, Anda akan menginginkannya juga di Freeplane." ID="_Freeplane_Link_717349033" CREATED="1124560950701" MODIFIED="1208965557349" STYLE="fork">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Setelan papan ketik dapat diganti melalui menu Alat &gt; Preferensi." ID="_Freeplane_Link_1179893656" CREATED="1124560950701" MODIFIED="1208965331784">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Penghargaan" FOLDED="true" POSITION="left" ID="_Freeplane_Link_784043927" CREATED="1124560950701" MODIFIED="1208773990119" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Penulis" FOLDED="true" ID="Freeplane_Link_415458128" CREATED="1124560950701" MODIFIED="1208774001268" COLOR="#006699">
<node TEXT="Joerg Mueller" ID="_Freeplane_Link_1896457660" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="ponders@t-online.de" ID="ID_1636928501" CREATED="1124560950701" MODIFIED="1124560950701" LINK="mailto:ponders@t-online.de" COLOR="#558000">
<font NAME="Dialog" SIZE="10"/>
</node>
<node TEXT="University of Freiburg, Germany" ID="ID_960789639" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Daniel Polansky" ID="_Freeplane_Link_984984595" CREATED="1124560950701" MODIFIED="1124560950701" LINK="http://mujweb.cz/www/danielpolansky" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Petr Novak" ID="_Freeplane_Link_459203293" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Christian Foltin" ID="_Freeplane_Link_875814410" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
<node TEXT="Dimitri Polivaev" ID="_Freeplane_Link_1415293905" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Sumbangan lain" FOLDED="true" ID="Freeplane_Link_816166020" CREATED="1124560950701" MODIFIED="1208774033132" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Andrew Iggleden" FOLDED="true" ID="ID_1164774797" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Instalasi Windows" ID="ID_615905950" CREATED="1124560950701" MODIFIED="1208966039732" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Bob Alexander" FOLDED="true" ID="Freeplane_Link_1096673251" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Panduan Eclipse" ID="ID_1498630478" CREATED="1124560950701" MODIFIED="1208966051800" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="David Butt" FOLDED="true" ID="Freeplane_Link_1024053399" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Tutorial Flash" ID="ID_158863537" CREATED="1124560950701" MODIFIED="1208966057187" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="David Low" FOLDED="true" ID="ID_1572312597" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Membantu" ID="ID_760522438" CREATED="1124560950701" MODIFIED="1208966069585" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
</node>
<node TEXT="Penerjemahan" FOLDED="true" ID="Freeplane_Link_360501151" CREATED="1124560950701" MODIFIED="1208774040521" COLOR="#006699">
<node TEXT="Permata Harahap" FOLDED="true" ID="ID_962580873" CREATED="1208774087264" MODIFIED="1208774118696" COLOR="#996600" STYLE="fork">
<edge STYLE="bezier" COLOR="#808080" WIDTH="thin"/>
<node TEXT="terjemahan bahasa Indonesia" ID="ID_1424643889" CREATED="1208774125193" MODIFIED="1208966146215" COLOR="#999999" STYLE="fork">
<font NAME="SansSerif" SIZE="10"/>
<edge STYLE="bezier" COLOR="#808080" WIDTH="thin"/>
</node>
</node>
<node TEXT="Bob Alexander" FOLDED="true" ID="Freeplane_Link_807977431" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Italian translation" ID="ID_1125551331" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Knud Riish&#xf8;jg&#xe5;rd" FOLDED="true" ID="Freeplane_Link_1853214917" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Danish translation" ID="ID_846744145" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Takeshi Kakeda" FOLDED="true" ID="Freeplane_Link_1676529317" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Japanese translation" ID="ID_1368567351" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Kohichi Aoki" FOLDED="true" ID="Freeplane_Link_1172193026" CREATED="1124562983644" MODIFIED="1124562984816" COLOR="#996600">
<node TEXT="Japanese translation" ID="ID_934842072" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Alex Dukal" FOLDED="true" ID="ID_761116196" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Spanish translation" ID="ID_1434343377" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Hugo Gayosso" FOLDED="true" ID="Freeplane_Link_757563697" CREATED="1124562998159" MODIFIED="1124563008034" COLOR="#996600">
<node TEXT="Spanish translation" ID="Freeplane_Link_1783275246" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<edge WIDTH="thin"/>
</node>
</node>
<node TEXT="Sylvain Gamel" FOLDED="true" ID="Freeplane_Link_929540960" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#996600">
<node TEXT="French translation" ID="ID_387483489" CREATED="1124560950701" MODIFIED="1124560950701" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Koen Roggemans" FOLDED="true" ID="Freeplane_Link_946171164" CREATED="1124561242082" MODIFIED="1124561245019" COLOR="#996600">
<node TEXT="Dutch translation" ID="Freeplane_Link_1819881845" CREATED="1124561245957" MODIFIED="1124561251675" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Rafal Kraik" FOLDED="true" ID="Freeplane_Link_235962981" CREATED="1124561374999" MODIFIED="1124561376718" COLOR="#996600">
<node TEXT="Polish translation" ID="Freeplane_Link_459079511" CREATED="1124561377702" MODIFIED="1124561382155" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Goliath" FOLDED="true" ID="Freeplane_Link_653284985" CREATED="1124561969717" MODIFIED="1124561972920" COLOR="#996600">
<node TEXT="Korean translation" ID="Freeplane_Link_1387213811" CREATED="1124561438294" MODIFIED="1124561445950" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Martin Srebotnjak (nick: Miles a.k.a. filmsi)" FOLDED="true" ID="Freeplane_Link_35211963" CREATED="1124561753254" MODIFIED="1124563712385" COLOR="#996600">
<node TEXT="Slovenian translation" ID="Freeplane_Link_835144271" CREATED="1124561491886" MODIFIED="1124561506386" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="William Chen" FOLDED="true" ID="Freeplane_Link_1008886206" CREATED="1124561814721" MODIFIED="1124561818580" COLOR="#996600">
<node TEXT="Chinese translation" ID="Freeplane_Link_1960552629" CREATED="1124561497308" MODIFIED="1124561506011" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Radek &#x160;varc" FOLDED="true" ID="Freeplane_Link_1650138043" CREATED="1124561823877" MODIFIED="1124561876907" COLOR="#996600">
<node TEXT="Czech translation" ID="Freeplane_Link_768227373" CREATED="1124561515761" MODIFIED="1124561519885" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Bal&#xe1;zs M&#xe1;rton" FOLDED="true" ID="Freeplane_Link_901975324" CREATED="1124562250475" MODIFIED="1124562252007" COLOR="#996600">
<node TEXT="Hungarian translation" ID="Freeplane_Link_557911120" CREATED="1124562252585" MODIFIED="1124562258428" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Luis Ferreira " FOLDED="true" ID="Freeplane_Link_290351026" CREATED="1124562948942" MODIFIED="1124562950270" COLOR="#996600">
<node TEXT="Portuguese translation" ID="Freeplane_Link_6081004" CREATED="1124562956332" MODIFIED="1124562961879" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node TEXT="Daftar penerjemahan ini mungkin belum lengkap. Bila ada yang terlupakan, beritahu kami. Semua orang yang kami ketahui telah menyumbangkan paling sedikit penerjemahan sebagian sudah ada dalam daftar." ID="Freeplane_Link_23652566" CREATED="1124563066204" MODIFIED="1208966247321" COLOR="#999999">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node TEXT="Tekan Ctrl + F untuk mencari. Tekan Ctrl + G untuk mengulang pencarian terakhir. Agar pencarian dilakukan global, tekan Esc sebelum mencari." POSITION="right" ID="ID_487339822" CREATED="1124560950701" MODIFIED="1208967115239" COLOR="#0033ff"/>
<node TEXT="Tekan panah kanan untuk membuka lipatan node." POSITION="right" ID="ID_1540220959" CREATED="1124560950701" MODIFIED="1208967142848" COLOR="#0033ff"/>
<node TEXT="Pengantar" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1596161299" CREATED="1124560950701" MODIFIED="1465678903958" COLOR="#407000">
<node TEXT="Freeplane memungkinkan kita membuat apa yang disebut sebagai MindMap. Meski begitu, banyak orang menggunakannya sebagai alternatif dari buku catatan atau alat pengelola informasi pribadi." ID="ID_234585361" CREATED="1124560950701" MODIFIED="1209144426964"/>
<node TEXT="Informasi disimpan dalam kotak teks, disebut node. Node dihubungkan satu sama lain dengan garis melengkung yang kita sebut tangkai." ID="ID_660297789" CREATED="1124560950701" MODIFIED="1465678903990"/>
<node TEXT="Dokumentasi ini dibuat untuk Freeplane 0.8.0. Pemetaan kunci pintasan dan lokasi fungsi menu bisa berubah dari satu versi ke versi lainnya." ID="ID_1286515401" CREATED="1124560950701" MODIFIED="1209144542891"/>
</node>
<node TEXT="Demonstrasi beberapa fitur" FOLDED="true" POSITION="right" ID="_Freeplane_Link_706084071" CREATED="1124560950701" MODIFIED="1209144562459" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Tampilan" ID="_Freeplane_Link_735193624" CREATED="1124560950701" MODIFIED="1209144584160" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Node bisa dibuat berbagai warna" ID="ID_690312221" CREATED="1124560950701" MODIFIED="1209144600864">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Merah" ID="ID_1678736213" CREATED="1124560950701" MODIFIED="1209144605871" COLOR="#ff0000">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Hijau" ID="ID_767661247" CREATED="1124560950701" MODIFIED="1209144610358" COLOR="#009900">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Biru" ID="ID_1716843014" CREATED="1124560950701" MODIFIED="1209144614043" COLOR="#0000cc">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Node bisa punya berbagai warna latar belakang" ID="_" CREATED="1124560950701" MODIFIED="1209144652959">
<node TEXT="Ini" ID="_Freeplane_Link_1358611533" CREATED="1124560950701" MODIFIED="1209144658287"/>
<node TEXT="Itu" ID="_Freeplane_Link_1317973766" CREATED="1124560950701" MODIFIED="1209144661972"/>
</node>
<node TEXT="Node bisa dibuat dalam berbagai gaya huruf" ID="ID_1132374703" CREATED="1124560950701" MODIFIED="1209144683773">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Tebal" ID="ID_1639593324" CREATED="1124560950701" MODIFIED="1209144688971">
<font NAME="Dialog" SIZE="12" BOLD="true"/>
</node>
<node TEXT="Miring" ID="ID_1376999225" CREATED="1124560950701" MODIFIED="1209144693157">
<font NAME="Dialog" SIZE="12" ITALIC="true"/>
</node>
<node TEXT="Tebal dan miring" ID="ID_1864392974" CREATED="1124560950701" MODIFIED="1209144699045">
<font NAME="Dialog" SIZE="12" BOLD="true" ITALIC="true"/>
</node>
</node>
<node TEXT="Huruf node bisa dibuat dalam berbagai ukuran" ID="ID_834524132" CREATED="1124560950701" MODIFIED="1209144718984">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="kecil" ID="ID_1791375192" CREATED="1124560950701" MODIFIED="1209144724832">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node TEXT="normal" ID="ID_1751565530" CREATED="1124560950701" MODIFIED="1124560950701">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node TEXT="besar" ID="ID_816405856" CREATED="1124560950701" MODIFIED="1209144731953">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node TEXT="besar sekali" FOLDED="true" ID="ID_544909735" CREATED="1124560950701" MODIFIED="1209144737731">
<font NAME="SansSerif" SIZE="20"/>
<node TEXT="OOh" ID="ID_1478631569" CREATED="1124560950701" MODIFIED="1124560950701">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node TEXT="Jenis font yang digunakan bisa bermacam-macam" ID="ID_53656715" CREATED="1124560950701" MODIFIED="1209144772251">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Ini" ID="ID_1199607468" CREATED="1124560950701" MODIFIED="1209144776997">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node TEXT="Atau itu" ID="_Freeplane_Link_1568731425" CREATED="1124560950701" MODIFIED="1209144782796">
<font NAME="Verdana" SIZE="12"/>
</node>
<node TEXT="Atau yang itu" ID="ID_1961541891" CREATED="1124560950701" MODIFIED="1209144791218">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node TEXT="Gaya node bisa dibuat berbeda-beda" ID="_Freeplane_Link_1193071041" CREATED="1124560950701" MODIFIED="1209144850133">
<node TEXT="Ranting" ID="_Freeplane_Link_1979277285" CREATED="1124560950701" MODIFIED="1209144855040">
<node TEXT="Ranting" ID="_Freeplane_Link_89124429" CREATED="1124560950701" MODIFIED="1209144859226"/>
<node TEXT="Ranting" ID="_Freeplane_Link_173850525" CREATED="1124560950701" MODIFIED="1209144863081"/>
</node>
<node TEXT="Balon" ID="_Freeplane_Link_1001811541" CREATED="1124560950701" MODIFIED="1209144867427" STYLE="bubble">
<node TEXT="Balon" ID="_Freeplane_Link_1677737286" CREATED="1124560950701" MODIFIED="1209144870382" STYLE="bubble"/>
<node TEXT="Balon" ID="_Freeplane_Link_978246353" CREATED="1124560950701" MODIFIED="1209144875880" STYLE="bubble"/>
</node>
</node>
</node>
<node TEXT="Node bisa dilipat" ID="ID_483073690" CREATED="1124560950701" MODIFIED="1209144893635" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Lipat" FOLDED="true" ID="_Freeplane_Link_307016912" CREATED="1124560950701" MODIFIED="1209144900164">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Tersembunyi" ID="ID_953890024" CREATED="1124560950701" MODIFIED="1209144904120">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Pohon" FOLDED="true" ID="_Freeplane_Link_1488567837" CREATED="1124560950701" MODIFIED="1209144910239">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Ek" ID="ID_346141495" CREATED="1124560950701" MODIFIED="1209144968032">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Waru" ID="ID_1441151502" CREATED="1124560950701" MODIFIED="1209144978707">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Cemara" ID="ID_534141496" CREATED="1124560950701" MODIFIED="1209144975323">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Node bisa mengandung taut yang mengacu ke ..." ID="ID_641469382" CREATED="1124560950701" MODIFIED="1209145007859" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Laman web" ID="ID_339939684" CREATED="1124560950701" MODIFIED="1209145013397" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="http://www.google.com/" ID="ID_336090118" CREATED="1124560950701" MODIFIED="1124560950701" LINK="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="www.google.com" ID="ID_1493827529" CREATED="1124560950701" MODIFIED="1124560950701" LINK="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Menurut Freeplane, ini bisa dieksekusi :)" ID="ID_1854484178" CREATED="1124560950701" MODIFIED="1209145055708" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node TEXT="Map lokal" ID="ID_278779728" CREATED="1124560950701" MODIFIED="1209145035199" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:/Program Files/" ID="ID_1541289178" CREATED="1124560950701" MODIFIED="1124560950701" LINK="file:/C:/Program%20Files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="/home/" ID="ID_2370204" CREATED="1124560950701" MODIFIED="1124560950701" LINK="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Bisa dieksekusi" ID="ID_738829620" CREATED="1124560950701" MODIFIED="1209145122154" COLOR="#006699">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:\WINNT\regedit.exe" ID="ID_372784718" CREATED="1124560950701" MODIFIED="1124560950701" LINK="file:/C:/WINNT/regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Yang bisa dieksekusi terlihat dari ikonnya." ID="ID_785322201" CREATED="1124560950701" MODIFIED="1209145112239" COLOR="#006600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Dokumen apapun di komputer atau jaringan lokal Anda" ID="ID_1493178463" CREATED="1124560950717" MODIFIED="1209145084870">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Node baris banyak" ID="_Freeplane_Link_839677176" CREATED="1124560950717" MODIFIED="1209145146829" COLOR="#669900">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Node baris banyak dapat dilihat sebagai satu atau beberapa paragraf. Bila Anda hendak membangun basis pengetahuan menggunakan Freeplane, penggunaan hal ini tidak dapat dihindari. Alih-alih menggunakan berkas teks polos untuk menampung isi catatan Anda, Anda dapat menggunakan satu node pendek dengan beberapa node baris banyak sebagai anak-anaknya." ID="_Freeplane_Link_1423568963" CREATED="1124560950717" MODIFIED="1209145323754"/>
<node TEXT="&quot;Science is facts; just as houses are made of stones, so is science made of facts; but a pile of stones is not a house and a collection of facts is not necessarily science.&quot; --Henri Poincar&#xe9;" ID="_Freeplane_Link_1686184172" CREATED="1124560950717" MODIFIED="1124560950717"/>
</node>
<node TEXT="Node baris banyak pendek dengan baris baru" ID="ID_1903544860" CREATED="1124560950717" MODIFIED="1209145372504" COLOR="#669900">
<node TEXT="Baris,&#xa;yang kedua,&#xa;&#xa;lalu masih satu lagi,&#xa;jadi bagaimana menurut Anda?" ID="_Freeplane_Link_1957797574" CREATED="1124560950717" MODIFIED="1209145401345"/>
</node>
<node TEXT="Tangkai berlabel dapat diemulasi" ID="ID_1745174972" CREATED="1124560950717" MODIFIED="1209145414544" COLOR="#669900">
<node TEXT="Pohon" ID="ID_605733199" CREATED="1124560950717" MODIFIED="1209145421254">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="adalah" ID="ID_731706632" CREATED="1124560950717" MODIFIED="1209145426111" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Ek" ID="ID_181561435" CREATED="1124560950717" MODIFIED="1209145428945">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="adalah" ID="ID_897111444" CREATED="1124560950717" MODIFIED="1209145431819" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Waru" ID="ID_454264987" CREATED="1124560950717" MODIFIED="1209145434683">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="adalah" ID="ID_1002513327" CREATED="1124560950717" MODIFIED="1209145437397" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Cemara" ID="ID_22757936" CREATED="1124560950717" MODIFIED="1209145439951">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Pohon" ID="ID_701778556" CREATED="1124560950717" MODIFIED="1209145445198">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="&lt;&gt;" ID="ID_1248255979" CREATED="1124560950717" MODIFIED="1124560950717" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Daun" ID="ID_1769190795" CREATED="1124560950717" MODIFIED="1209145448172">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="&lt;&gt;" ID="ID_1881802723" CREATED="1124560950717" MODIFIED="1124560950717" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
<node TEXT="Batang" ID="ID_335664905" CREATED="1124560950717" MODIFIED="1209145450916">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="Node bisa diberi ikon" ID="ID_1556015660" CREATED="1124560950717" MODIFIED="1209145462263" COLOR="#669900">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node TEXT="Anda bisa pakai Awan" ID="_Freeplane_Link_318937820" CREATED="1124560950717" MODIFIED="1209145473319" COLOR="#407000">
<cloud COLOR="#f0f0f0" SHAPE="ARC"/>
<node TEXT="Dengan warna pilihan" ID="ID_963712048" CREATED="1124560950717" MODIFIED="1209145483894">
<cloud COLOR="#f1ede6" SHAPE="ARC"/>
</node>
</node>
<node TEXT="Anda bisa pakai taut grafis" ID="_Freeplane_Link_1750585847" CREATED="1124560950717" MODIFIED="1209145498705" COLOR="#407000">
<node TEXT="Menghubungkan node" ID="_Freeplane_Link_1212380407" CREATED="1124560950717" MODIFIED="1209145504193">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1249400461" STARTINCLINATION="41;0;" ENDINCLINATION="41;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Ke node lain" ID="_Freeplane_Link_1249400461" CREATED="1124560950717" MODIFIED="1209145509501">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#6600ff" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_880551392" STARTINCLINATION="47;0;" ENDINCLINATION="47;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Dengan warna berbeda" ID="_Freeplane_Link_880551392" CREATED="1124560950717" MODIFIED="1209145515299">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1789233193" STARTINCLINATION="82;44;" ENDINCLINATION="82;44;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Dan rute berbeda" ID="_Freeplane_Link_1789233193" CREATED="1124560950717" MODIFIED="1209145526135"/>
</node>
<node TEXT="Node bisa diposisikan secara bebas" ID="_Freeplane_Link_127668276" CREATED="1124560950717" MODIFIED="1209145535778" COLOR="#407000">
<node TEXT="Satu" ID="_Freeplane_Link_894936766" CREATED="1124560950717" MODIFIED="1209145538052"/>
<node TEXT="Lainnya" ID="_Freeplane_Link_1942481455" CREATED="1124560950717" MODIFIED="1209145541467"/>
</node>
</node>
<node TEXT="Membuat dan menghapus node" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1709752669" CREATED="1124560950717" MODIFIED="1209145567184" COLOR="#407000">
<node TEXT="Untuk membuat node anak, tekan Insert." ID="ID_13596821" CREATED="1124560950717" MODIFIED="1209145582576"/>
<node TEXT="Untuk membuat node anak selagi mengedit node lainnya, tekan Insert sambil mengedit." ID="ID_311857085" CREATED="1124560950717" MODIFIED="1209145615733"/>
<node TEXT="Untuk membuat node adik, tekan Enter." ID="ID_278636018" CREATED="1124560950717" MODIFIED="1209145637074"/>
<node TEXT="Untuk membuat node kakak, tekan Shift + Enter." ID="ID_1905108426" CREATED="1124560950717" MODIFIED="1209145650914"/>
<node TEXT="Untuk menghapus node, tekan Delete" ID="ID_244320564" CREATED="1124560950717" MODIFIED="1209145667187"/>
<node TEXT="Untuk menghapus node dan menyimpannya untuk ditempel, tekan Control + X." ID="ID_1712732486" CREATED="1124560950717" MODIFIED="1209145684793"/>
<node TEXT="Cara lain, gunakan menu konteks node dengan mengklik-kanan node." ID="ID_669932662" CREATED="1124560950717" MODIFIED="1209145717900"/>
</node>
<node TEXT="Mengedit teks node" FOLDED="true" POSITION="right" ID="Freeplane_Link_1700974092" CREATED="1124560950717" MODIFIED="1209146178042" COLOR="#407000">
<node TEXT="Untuk mengedit node, tekan F2, Home, atau End, atau dari menu konteks node pilih Edit. Untuk menyelesaikan penyuntingan, tekan Enter." ID="_Freeplane_Link_519923426" CREATED="1124560950717" MODIFIED="1209146228715">
<arrowlink SHAPE="LINE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_519923426" STARTINCLINATION="0;0;" ENDINCLINATION="0;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Untuk mengganti teks dalam node dengan yang baru, mulailah mengetik." ID="ID_193947887" CREATED="1124560950717" MODIFIED="1209146247882"/>
<node TEXT="Untuk memaksakan editor node panjang saat mengedit node pendek, tekan Alt + Enter." ID="ID_735369454" CREATED="1124560950717" MODIFIED="1209146277185"/>
<node TEXT="Untuk memisahkan sebuah node panjang, gunakan tombol Pisahkan di atas editor node panjang, atau tekan Alt + S di editor node panjang." ID="ID_1959309673" CREATED="1124560950717" MODIFIED="1209146378340"/>
<node TEXT="Untuk memasukkan baris baru dalam editor node panjang, tekan Control + Enter. Anda tidak dapat memasukkan baris baru di dalam editor node pendek." ID="ID_1980075999" CREATED="1124560950717" MODIFIED="1209146432428">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1445647544" STARTINCLINATION="118;0;" ENDINCLINATION="118;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Untuk menyalin pilihan ke papan klip saat mengedit node panjang, tekan tombol tetikus kanan dan pilih Salin." ID="ID_280042855" CREATED="1124560950717" MODIFIED="1209146502509"/>
<node TEXT="Untuk memasukkan simbol khusus seperti &#xa9;, sisipkan simbol lewat editor teks favorit Anda seperti  Microsoft Word, lalu tempelkan ke dalam Freeplane." ID="ID_816706434" CREATED="1124560950717" MODIFIED="1209146564448"/>
<node TEXT="Bawaannya, Enter mengakhiri penyuntingan node panjang, dan Control + Enter menyisipkan baris baru. Dengan menghapus kotak pilihan &quot;Enter untuk Menerapkan&quot;, Anda dapat membalik fungsi dari kunci-kunci tersebut, sehingga menjadi Enter untuk baris baru dan Control + Enter mengakhiri penyuntingan. Selanjutnya, pilihan yang Anda buat disimpan dalam setiap sesi Freeplane." ID="_Freeplane_Link_1445647544" CREATED="1124560950717" MODIFIED="1209146708815"/>
<node TEXT="Freeplane sepenuhnya mendukung Unicode. Jadi, Anda dapat menggunakan aksara apapun pilihan Anda." ID="ID_403957298" CREATED="1124560950717" MODIFIED="1209146748833" STYLE="fork"/>
</node>
<node TEXT="Memformat node" FOLDED="true" POSITION="right" ID="Freeplane_Link_1660149394" CREATED="1124560950717" MODIFIED="1209146760409" COLOR="#407000">
<node TEXT="Untuk menebalkan huruf node, tekan Ctrl + B." ID="ID_16709297" CREATED="1124560950717" MODIFIED="1209146794338">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk memiringkan huruf node, tekan Ctrl + I." ID="ID_436634279" CREATED="1124560950717" MODIFIED="1209146788710">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk mengganti warna teks node, tekan Alt + C." ID="ID_605709251" CREATED="1124560950717" MODIFIED="1209146806115">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk menggantui warna latar belakang node, dari menu konteks node pilih Format &gt; Warna Latar Belakang." ID="ID_1004006951" CREATED="1124560950717" MODIFIED="1209146860563"/>
<node TEXT="Untuk memperbesar huruf, tekan Control + plus (bukan plus di kunci numerik)." ID="ID_1279126013" CREATED="1124560950717" MODIFIED="1209146902223">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk memperkecil huruf, tekan Control + minus (bukan minus di kunci numerik)." ID="ID_689591166" CREATED="1124560950717" MODIFIED="1209146930163">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk mengganti jenis font, gunakan kotak di luntang utama." ID="ID_1883860478" CREATED="1124560950717" MODIFIED="1209146952315"/>
<node TEXT="Untuk menyalin format node, tekan Alt + C" ID="ID_934867667" CREATED="1124560950717" MODIFIED="1209146968589"/>
<node TEXT="Untuk menempelkan format ke node, tekan Alt + V." ID="ID_1327202234" CREATED="1124560950717" MODIFIED="1209146982909"/>
</node>
<node TEXT="Menggunakan gaya fisik" FOLDED="true" POSITION="right" ID="Freeplane_Link_526328879" CREATED="1124560950717" MODIFIED="1209174502297" COLOR="#407000">
<node TEXT="Untuk menerapkan gaya fisik, dari menu konteks node pilih Gaya Fisik &gt; Gaya Pilihan Anda. Untuk mempercepat penerapan gaya fisik, gunakan kunci pintasan seperti terlihat di menu konteks tersebut." ID="ID_163328245" CREATED="1124560950717" MODIFIED="1209174573249"/>
<node TEXT="Untuk menambahkan gaya fisik Anda sendiri, dengan asumsi Anda punya kemampuan teknis, edit berkas &quot;patterns.xml&quot; berlokasi di map &quot;.freeplane&quot; di home directory Anda." ID="ID_1479089058" CREATED="1124560950717" MODIFIED="1209174917774"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      [Paragraf ini sudah usang.] Berikut catatan tentang berkas patterns.xml. Gaya fisik diterapkan ke node, bila ada tanda &amp;lt;node&amp;gt;. Diterapkan ke tangkai, bila ada tanda &amp;lt;edge&amp;gt;. Tanda &amp;lt;node&amp;gt; bisa berisi tanda lain sebagai anaknya. Pelajari berkas &amp;quot;patterns.xml&amp;quot; yang disediakan dari Freeplane.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="Freeplane_Link_1514218661" CREATED="1124560950717" MODIFIED="1209175093417"/>
</node>
<node TEXT="Menandai node dengan awan" FOLDED="true" POSITION="right" ID="Freeplane_Link_1697687428" CREATED="1124560950717" MODIFIED="1209175158320" COLOR="#407000">
<node TEXT="Awan sangat cocok untuk menandai area tertentu. Yang ditandai adalah node dan semua keturunannya." ID="ID_819249895" CREATED="1124560950717" MODIFIED="1209175199559"/>
<node TEXT="Untuk menambahkan awan, tekan Ctrl + Shift + B atau dari menu konteks node, pilih Sisip &gt; Awan." ID="ID_1363990537" CREATED="1124560950717" MODIFIED="1209175237524"/>
<node TEXT="Untuk mengganti warna awan, dari menu konteks node, pilih Format &gt; Warna Awan." ID="ID_1293762493" CREATED="1124560950717" MODIFIED="1209175322426" STYLE="fork"/>
<node TEXT="Awan bisa menggunakan berbagai warna latar seperti hijau ..." ID="ID_1298148690" CREATED="1124560950717" MODIFIED="1209175360781">
<cloud COLOR="#e1f2e1" SHAPE="ARC"/>
<node TEXT="... atau coklat." ID="ID_251339755" CREATED="1124560950717" MODIFIED="1209175372228">
<cloud COLOR="#ede5d5" SHAPE="ARC"/>
</node>
</node>
</node>
<node TEXT="Menambahkan hipertaut" FOLDED="true" POSITION="right" ID="Freeplane_Link_203858515" CREATED="1124560950717" MODIFIED="1209175396833" COLOR="#407000">
<node TEXT="Untuk menambahkan hipertaut ke node, tekan Ctrl + K atau dari menu konteks node, pilih Sisip &gt; Hipertaut." ID="ID_951732434" CREATED="1124560950717" MODIFIED="1209175545367"/>
<node TEXT="Untuk mencopot hipertaut, kosongkan setelan hipertaut setelah menekan Ctrl + K." ID="ID_800098735" CREATED="1124560950717" MODIFIED="1209175628276"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Untuk membuat taut ke alamat pos-el, gunakan format &lt;i&gt;mailto:don.bonton@supermail.com&lt;/i&gt;.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_292357559" CREATED="1124560950717" MODIFIED="1209175738865">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Untuk membuat taut ke alamat pos-el dengan subjek, gunakan format &lt;i&gt;mailto:don.bonton@supermail.com?subject=Ini judul suratnya&lt;/i&gt;.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_299108667" CREATED="1124560950717" MODIFIED="1209175726237"/>
<node TEXT="Hipertaut dapat mengacu ke laman web, berkas lokal, local files, atau alamat pos-el." ID="ID_1536348129" CREATED="1124560950717" MODIFIED="1209175768918"/>
</node>
<node TEXT="Menambahkan ikon" FOLDED="true" POSITION="right" ID="Freeplane_Link_1044397139" CREATED="1124560950717" MODIFIED="1209175957209" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Node bisa memiliki beberapa ikon." ID="ID_943341306" CREATED="1124560950717" MODIFIED="1209175971259"/>
<node TEXT="Untuk menambahkan ikon ke node, pilih node dan klik satu dari beberapa ikon yang ditampilkan di luntang kedua. Ketika menggerakkan penunjuk tetikus ke luntang kedua, tahan Alt atau Control supaya fokus tidak lepas dari node tersebut." ID="ID_412021555" CREATED="1124560950717" MODIFIED="1209176046407"/>
<node TEXT="Untuk mencopot satu ikon, tekan tanda silang merah yang terletak paling atas di luntang ikon." ID="ID_1191551492" CREATED="1124560950717" MODIFIED="1209176262718"/>
<node TEXT="Untuk mencopot semua ikon, tekan tanda tempat sampah di bagian atas luntang ikon." ID="ID_1685973688" CREATED="1124560950717" MODIFIED="1209176295746"/>
<node TEXT="Untuk menambahkan ikon baru ke node tanpa menggunakan luntang kedua, tekan Alt + I." ID="ID_116898291" CREATED="1124560950717" MODIFIED="1209176327421"/>
<node TEXT="Tidak ada pilihan untuk menggunakan ikon Anda sendiri; Anda dapat memilih dari ikon yang disediakan oleh Freeplane saja." ID="ID_998319853" CREATED="1124560950717" MODIFIED="1209176368470"/>
<node TEXT="Untuk menampilkan atau menyembunyikan luntang ikon, dari menu konteks di latar belakang pilih Luntang Kedua. Luntang ikon disebut sebagai luntang kedua di sini." ID="ID_1861765800" CREATED="1124560950717" MODIFIED="1209225434093"/>
<node TEXT="Ikon yang tersedia adalah seperti yang ditempelkan di node ini.." ID="ID_1851690875" CREATED="1124560950717" MODIFIED="1209225471036" STYLE="fork">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node TEXT="Menambah taut grafis" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1996597932" CREATED="1124560950717" MODIFIED="1209225505646" COLOR="#407000">
<node TEXT="Untuk membuat taut grafis antara dua node, seret node dan jatuhkan di atas node lainnya sambil menahan sekaligus tombol Shift dan Control; lepaskan tombol tetikus sebelum melepaskan tombol Shift dan Control." ID="ID_1153966308" CREATED="1124560950717" MODIFIED="1209225584530">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_266716332" STARTINCLINATION="255;0;" ENDINCLINATION="255;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Cara lain, seret dan jatuhkan menggunakan tombol tetikus kanan." ID="ID_1650090059" CREATED="1124560950717" MODIFIED="1209225611809"/>
<node TEXT="Untuk mengganti warna taut, gunakan menu konteks taut, dengan mengklik-kanan taut grafis." ID="_Freeplane_Link_208378337" CREATED="1124560950717" MODIFIED="1209225642733"/>
<node TEXT="Untuk mengganti panah taut, gunakan menu konteks taut." ID="_Freeplane_Link_1484370636" CREATED="1124560950717" MODIFIED="1209225695830"/>
<node TEXT="Untuk menghapus taut, gunakan menu konteks taut," ID="ID_1700277646" CREATED="1124560950717" MODIFIED="1209225707637"/>
<node TEXT="Untuk bernavigasi ke salah satu node ujung suatu taut, gunakan menu konteks taut." ID="_Freeplane_Link_266716332" CREATED="1124560950717" MODIFIED="1209225733974"/>
<node TEXT="Untuk mengganti rute sebuah taut berpanah, seret dan pindahkan taut tersebut." ID="_Freeplane_Link_1015289745" CREATED="1124560950717" MODIFIED="1209225763717">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_266716332" STARTINCLINATION="244;32;" ENDINCLINATION="256;22;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Berikut contoh tautan grafis." ID="ID_1921255250" CREATED="1124560950717" MODIFIED="1209225773561"/>
<node TEXT="Contoh" FOLDED="true" ID="ID_1451667289" CREATED="1124560950717" MODIFIED="1209225777237" COLOR="#996600">
<node TEXT="Taut ke bagian lain" ID="_Freeplane_Link_1170112929" CREATED="1124560950717" MODIFIED="1209225782684" COLOR="#996600">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#9999ff" WIDTH="2" TRANSPARENCY="255" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1492563156" STARTINCLINATION="30;0;" ENDINCLINATION="117;0;" STARTARROW="DEFAULT" ENDARROW="DEFAULT"/>
</node>
<node TEXT="Node dengan anak terlipat" FOLDED="true" ID="ID_466382348" CREATED="1124560950717" MODIFIED="1209225792469" COLOR="#996600">
<node TEXT="Node anak" ID="_Freeplane_Link_1492563156" CREATED="1124560950717" MODIFIED="1209225807130"/>
</node>
<node TEXT="Taut lainnya" ID="_Freeplane_Link_1370577235" CREATED="1124560950717" MODIFIED="1209225796815" COLOR="#996600">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="_Freeplane_Link_1170112929" STARTINCLINATION="61;0;" ENDINCLINATION="61;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
</node>
</node>
</node>
<node TEXT="Mencari" FOLDED="true" POSITION="right" ID="Freeplane_Link_423038022" CREATED="1124560950717" MODIFIED="1209225822962" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Untuk mencari teks dalam suatu node dan semua node keturunannya, tekan Ctrl + F atau dari menu, pilih Edit &gt; Temukan." ID="ID_1853186827" CREATED="1124560950717" MODIFIED="1209226056919" STYLE="fork">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk menemukan kecocokan berikutnya dari pencarian sebelumnya, tekan Ctrl + G atau dari menu, pilih Edit &gt; Temukan Berikutnya." ID="ID_1654127314" CREATED="1124560950717" MODIFIED="1209226038713">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk mencari di seluruh peta, posisikan ke node tengah dengan menekan  Escape sebelum mencari." ID="ID_1278869580" CREATED="1124560950717" MODIFIED="1209226104828"/>
<node TEXT="Pencarian dilakukan melebar lebih dahulu, baru ke dalam. Ini sesuai dengan pemikiran bahwa makin dalam sebuah node, makin banyak detail yang disampaikan dalam node." ID="ID_642414422" CREATED="1124560950717" MODIFIED="1209226593901"/>
<node TEXT="Ingat bahwa tidak seluruh peta dicari, hanya node dan keturunannya saja." ID="ID_876514246" CREATED="1124560950717" MODIFIED="1209226615812"/>
</node>
<node TEXT="Memilih banyak node" FOLDED="true" POSITION="right" ID="Freeplane_Link_653540280" CREATED="1124560950717" MODIFIED="1209226631074" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Untuk memilih banyak node, tahan Shift atau Control sambil mengklik. " ID="ID_296855940" CREATED="1124560950717" MODIFIED="1209226650853">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk menambah satu node ke dalam pilihan banyak node, tahan Control ketika mengklik." ID="ID_35755182" CREATED="1124560950717" MODIFIED="1209226704931">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk memilih serentetan node berturutan, tahan Shift ketika mengklik, atau tahan Shift sambil berpindah-pindah menggunakan tombol panah." ID="ID_1770763567" CREATED="1124560950717" MODIFIED="1209227478723" STYLE="fork">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk memilih satu anak dan semua keturunannya, tahan Alt sambil mengklik, atau tahan Shift sambil berpindah dari suatu node ke induknya." ID="ID_88845581" CREATED="1124560950717" MODIFIED="1209273334978"/>
<node TEXT="Untuk membatalkan pilihan banyak node, klik pada latar belakang peta atau pada node yang tidak terpilih." ID="ID_922127420" CREATED="1124560950717" MODIFIED="1209273362337"/>
<node TEXT="Untuk memilih semua node yang terlihat, dari menu gunakan Edit &gt; Pilih Semua yang Terlihat." ID="ID_1592480083" CREATED="1124560950717" MODIFIED="1209273421031"/>
<node TEXT="Untuk memilih semua node yang terlihat dari suatu cabang, dari menu gunakan Edit &gt; Pilih Cabang yang Terlihat." ID="ID_1593012221" CREATED="1124560950717" MODIFIED="1209273506554"/>
</node>
<node TEXT="Seret dan jatuhkan" FOLDED="true" POSITION="right" ID="Freeplane_Link_1024903226" CREATED="1124560950717" MODIFIED="1209273548565" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="Anda dapat memindah-mindahkan node dengan menyeret dan menjatuhkannya." ID="ID_1178943684" CREATED="1124560950717" MODIFIED="1209273566891">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk menjatuhkan node sebagai anak, posisikan penunjuk di bagian luar node tujuan ketika menjatuhkan." ID="ID_215653657" CREATED="1124560950717" MODIFIED="1209273607279">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk menjatuhkan node sebagai saudara, posisikan penunjuk di bagian atas node tujuan ketika menjatuhkan." ID="ID_343240384" CREATED="1124560950717" MODIFIED="1209273638865">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk menyalin node alih-alih memindahkan, tahan Control saat menyeret, atau seret memakai tombol tetikus tengah." ID="_Freeplane_Link_1994214827" CREATED="1124560950717" MODIFIED="1209273677360">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Untuk mengedit peta yang sudah ada, seret berkasnya dan jatuhkan di latar belakang Freeplane. Hal ini bekerja minimal di sistem operasi Microsoft Windows." ID="ID_942351938" CREATED="1124560950717" MODIFIED="1209273829298"/>
<node TEXT="Untuk membuat taut grafis, seret dan jatuhkan node menggunakan tombol tetikus kanan." ID="ID_1876033674" CREATED="1124560950717" MODIFIED="1209273855256"/>
<node TEXT="Bila Anda memilih banyak node, maka semuanya akan dipindahkan atau disalin." ID="ID_1278420396" CREATED="1124560950717" MODIFIED="1209273877077">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Anda dapat menjatuhkan data dari aplikasi eksternal, seperti berkas dalam sistem operasi Microsoft Windows, atau teks terpilih dari Microsoft Internet Explorer." ID="ID_965930833" CREATED="1124560950717" MODIFIED="1209273918076"/>
</node>
<node TEXT="Menyalin dan menempel" FOLDED="true" POSITION="right" ID="Freeplane_Link_958781924" CREATED="1124560950717" MODIFIED="1209274000895" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Anda dapat menyalin dan menempel (banyak) node antar MindMap seperti biasa. Selain itu, Anda dapat menempelkan teks biasa atau HTML dari aplikasi lain." ID="ID_1561854528" CREATED="1124560950717" MODIFIED="1209274053671">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Bila menempelkan teks polos, banyak baris akan ditempelkan sebagai banyak node, dan posisi kedalamannya ditentukan oleh banyaknya spasi di awal teks. Berikut contohnya." ID="ID_65809205" CREATED="1124560950717" MODIFIED="1209274132074"/>
<node TEXT="Pohon&#xa;     Ek&#xa;     Cemara" ID="ID_1627092027" CREATED="1124560950717" MODIFIED="1209274187534" COLOR="#996600">
<node TEXT="ditempelkan sebagai" ID="ID_55526373" CREATED="1124560950717" MODIFIED="1209274156138">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Pohon" ID="ID_787112439" CREATED="1124560950717" MODIFIED="1209274159944" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Ek" ID="ID_1397202134" CREATED="1124560950717" MODIFIED="1209274162718" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Cemara" ID="ID_475104996" CREATED="1124560950717" MODIFIED="1209274165892" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="Teks HTML akan ditempelkan sebagai teks polos. Di samping itu, tautan yang tercantum dalam HTML akan ditempelkan sebagai anak dari sebuat node tambahan dengan nama &quot;Links&quot;. Berikut contohnya." ID="ID_838592934" CREATED="1124560950717" MODIFIED="1209274297221"/>
<node TEXT="Contoh hasil penempelan" ID="ID_498865809" CREATED="1124560950717" MODIFIED="1209274303911">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Belanja (120236)" ID="ID_785656568" CREATED="1124560950717" MODIFIED="1209274321686" STYLE="fork">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Gaya Hidup (19)" ID="ID_785399167" CREATED="1124560950717" MODIFIED="1209274335066">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Links" ID="ID_1914167530" CREATED="1124560950717" MODIFIED="1124560950717">
<font NAME="Dialog" SIZE="12" BOLD="true"/>
<node TEXT="Belanja" ID="ID_647961468" CREATED="1124560950717" MODIFIED="1209274342707" LINK="http://directory.google.com/Top/Shopping/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Gaya Hidup" ID="ID_1021552074" CREATED="1124560950717" MODIFIED="1209274348295" LINK="http://directory.google.com/Top/Home/Urban_Living/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Bila Anda menempelkan senarai berkas dari Explorer di Microsoft Windows, taut ke berkas-berkas tersebut akan ditempelkan." ID="ID_1204515717" CREATED="1124560950717" MODIFIED="1209274426878"/>
<node TEXT="Bila Anda menyalin suatu cabang dan menempelkannya ke dalam editor teks polos, struktur pohon akan ditunjukkan dengan indentasi. Hipertaut ditempelkan dalam tanda kurung &lt; &gt;. Berikut contohnya." ID="ID_673825377" CREATED="1124560950717" MODIFIED="1209275981453" STYLE="fork"/>
<node TEXT="Pohon" ID="ID_1447539819" CREATED="1124560950717" MODIFIED="1209275989294" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Ek" ID="ID_1516542995" CREATED="1124560950717" MODIFIED="1209275992168" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Cemara" ID="ID_133833504" CREATED="1124560950717" MODIFIED="1209275995003" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="ditempelkan sebagai" ID="ID_268647755" CREATED="1124560950717" MODIFIED="1209276004807">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Pohon&#xa;     Ek&#xa;     Cemara&#xa;     Google &lt;http://www.google.com/&gt;&#xa;" ID="ID_1462977187" CREATED="1124560950732" MODIFIED="1209276023614" COLOR="#996600" STYLE="fork">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Google" ID="ID_1281956134" CREATED="1124560950732" MODIFIED="1124560950732" LINK="http://www.google.com/" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Bila dari Freeplane Anda menyalin suatu cabang dan menempelkannya ke dalam editor yang mendukung format teks kaya (rich text format - RTF), pemformatan seperti warna dan font ikut ditempelkan juga. Hipertaut ditempelkan dalam tanda kurung &lt; &gt;, seperti pada teks polos. Editor yang mendukung teks kaya termasuk Microsoft Word, Wordpad atau Microsoft Outlook, atau beberapa editor catatan di Linux." ID="ID_1354652421" CREATED="1124560950732" MODIFIED="1209276139520" STYLE="fork"/>
<node TEXT="Untuk menyalin node tanpa keturunannya, tekan Ctrl + Shift + C atau dari menu konteks node, pilih Salin Tunggal." ID="ID_866129685" CREATED="1124560950732" MODIFIED="1209276823784"/>
</node>
<node TEXT="Berpindah-pindah" FOLDED="true" POSITION="right" ID="_Freeplane_Link_1540212684" CREATED="1124560950732" MODIFIED="1209276831606" COLOR="#407000">
<node TEXT="Untuk menggerakan penunjuk ke atas, bawah, kri atau kanan, gunakan tombol panah." ID="ID_553732792" CREATED="1124560950732" MODIFIED="1209276874027"/>
<node TEXT="Untuk berpindah ke puncak cabang suatu pohon, tekan PageUp." ID="ID_1130754383" CREATED="1124560950732" MODIFIED="1209277294121"/>
<node TEXT="Untuk berpindah ke ujung bawah suatu pohon, tekan PageDown." ID="ID_1966957004" CREATED="1124560950732" MODIFIED="1209277312187"/>
<node TEXT="Untuk berpindah ke node akar, tekan Escape." ID="ID_1257350203" CREATED="1124560950732" MODIFIED="1209277327238"/>
<node TEXT="Untuk memposisikan node secara bebas, seret pegangan yang tidak terlihat di sisi node ke arah node akar, dan pindahkan." ID="_Freeplane_Link_97763226" CREATED="1124560950732" MODIFIED="1209277557089"/>
</node>
<node TEXT="Membuka-tutup lipatan" FOLDED="true" POSITION="right" ID="Freeplane_Link_4727471" CREATED="1124560950732" MODIFIED="1209277604066" COLOR="#407000">
<node TEXT="Untuk melipat node, tekan Space, atau dari menu konteks node, pilih Buka/Tutup Lipatan." ID="ID_1044015528" CREATED="1124560950732" MODIFIED="1209277633639"/>
<node TEXT="Untuk membuka lipatan, tekan Space, atau dari menu konteks node, pilih Buka/Tutup Lipatan, atau tekan tombol panah ke arah pembukaan lipatan." ID="ID_1520325492" CREATED="1124560950732" MODIFIED="1209277684542"/>
<node TEXT="Untuk membuka-tutup lipatan secara bertingkat, tahan Alt sambil menggunakan roda tetikus, atau tekan Alt + PageUp atau Alt + PageDown. Pada peta ukuran besar, gunakan fungsi ini dengan hati-hati, karena dapat menyebabkan masalah memori." ID="ID_871275537" CREATED="1124560950732" MODIFIED="1209277858893"/>
<node TEXT="Untuk membuka semua lipatan, gunakan tombol tanda plus abu-abu di luntang utama, atau dari menu pilih Navigasi &gt; Buka Semua." ID="ID_245769138" CREATED="1124560950732" MODIFIED="1209277930345"/>
<node TEXT="Untuk melipat semua, tekan tombol tanda minus abu-abu di luntang utama, atau dari menu pilih Navigasi &gt; Lipat Semua." ID="ID_91039853" CREATED="1124560950732" MODIFIED="1209277985695"/>
<node TEXT="Node terlipat ditandai dengan lingkaran kecil yang menempel ke arah luar." ID="ID_162455080" CREATED="1124560950732" MODIFIED="1209278021336"/>
</node>
<node TEXT="Berpindah ke peta lain" FOLDED="true" POSITION="right" ID="Freeplane_Link_516331171" CREATED="1124560950732" MODIFIED="1209278047444" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Untuk berpindah ke peta lain yang sudah dibuka, klik kanan di latar belakang dan pilih peta lain tersebut dari menu konteks." ID="ID_396490844" CREATED="1124560950732" MODIFIED="1209278081583">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Menggulung peta" FOLDED="true" POSITION="right" ID="Freeplane_Link_467411537" CREATED="1124560950732" MODIFIED="1209278088763" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Untuk menggulung peta, seret latar belakang dan pindah-pindahkan, atau gunakan roda tetikus. Untuk menggulung secara mendatar dengan roda tetikus, tahan Shift atau salah satu tombol tetikus." ID="ID_517576721" CREATED="1124560950732" MODIFIED="1209278135130">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Melakukan zum" FOLDED="true" POSITION="right" ID="Freeplane_Link_913137192" CREATED="1124560950732" MODIFIED="1209278154197" COLOR="#407000">
<node TEXT="Untuk zum, gunakan roda tetikus sambil menahan tombol Control, atau tekan tombol Alt + Up atau Down. Cara lain, gunakan kolom zum di luntang utama." ID="ID_1845799508" CREATED="1124560950732" MODIFIED="1209278210508"/>
</node>
<node TEXT="Urungkan" FOLDED="true" POSITION="right" ID="Freeplane_Link_1318678369" CREATED="1124560950732" MODIFIED="1209278220012" COLOR="#407000">
<node TEXT="Untuk mengurungkan, tekan Control + Z, atau dari menu, pilih Edit &gt; Urungkan." ID="ID_447059498" CREATED="1124560950732" MODIFIED="1209278246220"/>
<node TEXT="Untuk mengulang, tekan Control + Y, atau dari menu, pilih Edit &gt; Ulangi." ID="ID_496703552" CREATED="1124560950732" MODIFIED="1209278269393"/>
<node TEXT="Untuk menyetel jumlah langkah yang dicatat untuk bisa diurungkan, dari menu pilih Alat &gt; Preferensi." ID="ID_983204383" CREATED="1124560950732" MODIFIED="1209278313516"/>
</node>
<node TEXT="Ekspor ke HTML" FOLDED="true" POSITION="right" ID="Freeplane_Link_22510332" CREATED="1124560950732" MODIFIED="1209278324883" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Untuk mengekspor cabang ke HTML, tekan Control + H. Halaman hasil ekspor HTML dapat mendukung pelipatan, tergantung dari setelan preferensi." ID="ID_979412403" CREATED="1124560950732" MODIFIED="1209283147141"/>
<node TEXT="Fungsi ekspor yang lain bisa diaktifkan dari menu, pilih Ekspor &gt; Sebagai XHTML (versi Javascript)." ID="ID_655995359" CREATED="1124560950732" MODIFIED="1209283183713"/>
<node TEXT="Untuk mengekspor peta dengan gambar pratinjau dalam format HTML, dari menu pilih Ekspor &gt; Sebagai XHTML (versi gambar peta yang dapat diklik)." ID="ID_1772530062" CREATED="1124560950732" MODIFIED="1209283265471"/>
</node>
<node TEXT="Ekspor ke gambar bitmap atau vektor" FOLDED="true" POSITION="right" ID="Freeplane_Link_1908686168" CREATED="1124560950732" MODIFIED="1209283287583" COLOR="#407000">
<node TEXT="Untuk mengekspor peta sebaga citra PNG, dari menu pilih Berkas &gt; Ekspor &gt; Sebagai PNG." ID="ID_1425718492" CREATED="1124560950732" MODIFIED="1209283319959"/>
<node TEXT="Untuk mengekspor peta sebagai citra JPEG, dari menu pilih Berkas &gt; Ekspor &gt; Sebagai JPEG." ID="ID_1060323115" CREATED="1124560950732" MODIFIED="1209283347339"/>
<node TEXT="Untuk mengekspor peta sebagai SVG, dari menu piih Berkas &gt; Ekspor &gt; Sebagai SVG. Fungsi ini hanya tersedia bila tancapan (plug-in)  SVG telah  terpasang." ID="ID_443611240" CREATED="1124560950732" MODIFIED="1209283422497"/>
</node>
<node TEXT="Ekspor ke format XML lainnya" FOLDED="true" POSITION="right" ID="Freeplane_Link_329770204" CREATED="1124560950732" MODIFIED="1209283434003" COLOR="#407000">
<node TEXT="Untuk mengekspor peta ke format XML lainnya menggunakan lembar transformasi XSLT (XSLT transformation sheet), dari menu pilih Berkas &gt; Ekspor &gt; Dengan XSLT." ID="ID_209299544" CREATED="1124560950732" MODIFIED="1209283534357"/>
<node TEXT="Untuk mengekspor peta ke dokumen OpenOffice.org 1.4 Writer, dari menu pilih Berkas &gt; Ekspor &gt; Sebagai dokumen OpenOffice.org Writer." ID="ID_897570861" CREATED="1124560950732" MODIFIED="1209283591640"/>
</node>
<node TEXT="Mengimpor struktur map" FOLDED="true" POSITION="right" ID="Freeplane_Link_1841136119" CREATED="1124560950732" MODIFIED="1209283607262" COLOR="#407000">
<font NAME="Dialog" SIZE="12"/>
<node TEXT="Untuk mengimpor struktur berkas, dari menu pilih Berkas &gt; Impor &gt; Struktur Map. Anda akan ditanya tentang map yang strukturnya hendak diimpor. Yang dimaksud struktur adalah pohon dari semua submap (baik langsung maupun tidak) dengan tautan ke berkas-berkas dalam submap tersebut. Contoh dari struktur yang diimpor sebagai berikut." ID="ID_1862161571" CREATED="1124560950732" MODIFIED="1209283832536"/>
<node TEXT="Contoh" FOLDED="true" ID="ID_1276543096" CREATED="1124560950732" MODIFIED="1209283619300" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Map terpilih" ID="ID_1028597241" CREATED="1124560950732" MODIFIED="1209283613201" COLOR="#996600">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps" ID="ID_1506382314" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Dbwiz" ID="ID_697101222" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/">
<node TEXT="ASSETS.GIF" ID="ID_64562177" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ASSETS.GIF"/>
<node TEXT="CONTACTS.GIF" ID="ID_1059574094" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF"/>
<node TEXT="EVTMGMT.GIF" ID="ID_1354607487" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF"/>
<node TEXT="EXPENSES.GIF" ID="ID_1726967143" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF"/>
<node TEXT="INVENTRY.GIF" ID="ID_985249474" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF"/>
<node TEXT="LEDGER.GIF" ID="ID_29733514" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/LEDGER.GIF"/>
<node TEXT="ORDPROC.GIF" ID="ID_232554023" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF"/>
<node TEXT="RESOURCE.GIF" ID="ID_629100023" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF"/>
<node TEXT="SERVICE.GIF" ID="ID_166552432" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/SERVICE.GIF"/>
<node TEXT="TIMEBILL.GIF" ID="ID_287145336" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF"/>
</node>
<node TEXT="Styles" ID="ID_923094028" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/">
<node TEXT="ACBLENDS.GIF" ID="ID_428890757" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLENDS.GIF"/>
<node TEXT="ACBLUPRT.GIF" ID="ID_376498909" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLUPRT.GIF"/>
<node TEXT="ACEXPDTN.GIF" ID="ID_262314525" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACEXPDTN.GIF"/>
<node TEXT="ACINDSTR.GIF" ID="ID_1779868142" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACINDSTR.GIF"/>
<node TEXT="ACRICEPR.GIF" ID="ID_1533780306" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACRICEPR.GIF"/>
<node TEXT="ACSNDSTN.GIF" ID="ID_765857968" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSNDSTN.GIF"/>
<node TEXT="ACSUMIPT.GIF" ID="ID_1214888313" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSUMIPT.GIF"/>
<node TEXT="GLOBE.WMF" ID="ID_691308381" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF"/>
<node TEXT="STONE.BMP" ID="ID_172077095" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP"/>
</node>
</node>
</node>
<node TEXT="Mengimpor Favorit Internet Explorer" FOLDED="true" POSITION="right" ID="Freeplane_Link_269203785" CREATED="1124560950732" MODIFIED="1209284117917" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<edge WIDTH="thin"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;p&gt;&#xa;      Untuk mengimpor favorit dari Internet Explorer ke dalam Freeplane,dari menu pilih Berkas &amp;gt; Impor &amp;gt; Favorit dari Explorer. Anda akan diminta memasukkan jalur ke map tempat favorit disimpan. Nama map tersebut adalah Favorit (atau Favorites) dan Anda dapat mencarinya di sistem Anda. Di Windows XP dengan antarmuka bahasa Indonesia, jalurnya adalah C:\Documents and Settings\&amp;lt;nama pemakai&amp;gt;\Favorit.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="Freeplane_Link_260446736" CREATED="1124560950732" MODIFIED="1209284330122"/>
<node TEXT="Kata kunci: Microsoft Internet Explorer, MSIE, MS IE." ID="ID_1939528579" CREATED="1124560950732" MODIFIED="1209284341398" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Mengimpor MindMap dari MindManager X5" FOLDED="true" POSITION="right" ID="Freeplane_Link_1709974530" CREATED="1124560950732" MODIFIED="1209284361837" COLOR="#407000">
<node TEXT="Untuk mengimpor MindMap dari MindManager X5, dari menu, pilih Berkas &gt; Impor &gt; Peta MindManager X5." ID="ID_1824289094" CREATED="1124560950732" MODIFIED="1209284400102"/>
</node>
<node TEXT="Integrasi dengan Word atau Outlook" FOLDED="true" POSITION="right" ID="Freeplane_Link_913645795" CREATED="1124560950732" MODIFIED="1209284422485" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Anda dapat menempelkan peta atau cabang ke dalam Microsoft Word, Wordpad, atau pesan Outlook. Pada umumnya, Anda dapat menempel ke aplikasi apapun yang mendukung teks kaya. Pemformatan teks dan tautan akan ikut ditempelkan." ID="ID_239999971" CREATED="1124560950732" MODIFIED="1209284474209">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Klik pada taut surat (mailto:don.bonton@supermail.com) akan membuka Outlook untuk membuat pesan baru, bila tidak disetel lain di  Windows." ID="ID_1941398988" CREATED="1124560950732" MODIFIED="1209284522989" LINK="mailto:don.bonton@supermail.com">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Anda dapat menggunakan Subjek di tautan surat." ID="ID_273515249" CREATED="1124560950732" MODIFIED="1209284611046" LINK="mailto:don.bonton@supermail.com?subject=Ini%20subjeknya"/>
<node TEXT="Cara lain untuk menempelkan MindMap ke Microsoft Word adalah dengan mengekspornya ke HTML berdasarkan tajuk, menyalin HTML-nya dan menempelkannya ke Word." ID="ID_546445267" CREATED="1124560950732" MODIFIED="1209284658063"/>
</node>
<node TEXT="Menyetel preferensi" FOLDED="true" POSITION="right" ID="Freeplane_Link_1822195277" CREATED="1124560950732" MODIFIED="1209284665834" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Untuk mengedit preferensi, dari menu, pilih Alat &gt; Preferensi. Kebanyakan perubahan akan diterapkan hanya setelah Freeplane dimulai ulang." ID="ID_748595231" CREATED="1124560950732" MODIFIED="1209284705802"/>
<node TEXT="Preferensi mencakup pemetaan papan ketik, tingkah laku ekspor HTML, cara memilih node dengan tetikus, pilihan antialias, dan lain-lain." ID="ID_571002233" CREATED="1124560950732" MODIFIED="1209284752729"/>
<node TEXT="Kata kunci: penyesuaian." ID="ID_598925427" CREATED="1124560950732" MODIFIED="1209284763535" COLOR="#999999">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node TEXT="Pencetakan" FOLDED="true" POSITION="right" ID="Freeplane_Link_1528828442" CREATED="1124560950732" MODIFIED="1209284775042" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Anda dapat mencetak baik dengan menyesuaikan seluruh peta ke satu halaman, atau dengan mencetak peta ke beberapa lembar kertas. Pilihan ini dapat disetel dari menu Berkas &gt; Penataan Halaman." ID="ID_70287433" CREATED="1124560950732" MODIFIED="1209285126817"/>
<node TEXT="Untuk pemakaian ruang yang lebih baik, gunakan Lanskap dari Penataan Halaman." ID="ID_756004595" CREATED="1124560950732" MODIFIED="1209284879542">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Belum ada cara mudah untuk membuat pratinjau dari peta Anda sebelum mencetak. Bila Anda memiliki pencetak PostScript atau pengandar (driver) PostScript generik, Anda dapat mencetak peta ke dalam sebuah berkas dan menampilkan berkasnya menggunakan Ghostview atau program serupa. Bila Anda mencoba mencetak peta dengan pencetak yang tidak mengerti PostScript, berkas yang dihasilkan tidak akan menjadi PostScript tapi mungkin PCL, yang tidak bermanfaat bagi Anda." ID="ID_122221947" CREATED="1124560950732" MODIFIED="1209285103974"/>
<node TEXT="Anda juga dapat mencetak dari perambah (browser) Anda setelah mengekspor peta ke HTML, atau dari Word atau Wordpad setelah menyalin dan menempelkan peta ke dalamnya. Anda juga dapat mengekspor peta ke dalam HTML dengan tajuk, salin dan tempel ke Microsoft Word dan cetak dari situ. Dengan begitu, Anda dapat mengubah-ubah gayanya sesuai keinginan." ID="ID_1665441334" CREATED="1124560950732" MODIFIED="1209285283413">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Menggunakan teks kaya melalui HTML dalam node" FOLDED="true" POSITION="right" ID="Freeplane_Link_841140408" CREATED="1124560950732" MODIFIED="1209286969016" COLOR="#407000">
<node TEXT="Node yang dimulai dengan &lt;html&gt; dilukis menggunakan HTML yang terkandung di dalamnya. Fitur ini bermanfaat bagi pemakai dengan pengetahuan teknis. Contohnya sebagai berikut." ID="ID_1000519218" CREATED="1124560950732" MODIFIED="1209285355456"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;h3&gt;&#xa;      Contoh HTML&#xa;    &lt;/h3&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Ada beberapa lema:&#xa;    &lt;/p&gt;&#xa;    &lt;ul type=&quot;disc&quot;&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;        Lema satu&#xa;      &lt;/li&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;        Lema dua&#xa;      &lt;/li&gt;&#xa;    &lt;/ul&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Anda bisa menggunakan &lt;b&gt;cetak tebal&lt;/b&gt; or &lt;i&gt;miring&lt;/i&gt;. &lt;u&gt;Garis bawah&lt;/u&gt; dan juga &lt;strike&gt;coret&lt;/strike&gt;.&#xa;    &lt;/p&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Anda bisa buat tabel:&#xa;    &lt;/p&gt;&#xa;    &lt;table class=&quot;msonormaltable&quot; cellpadding=&quot;0&quot; border=&quot;1&quot; style=&quot;border: none&quot; cellspacing=&quot;0&quot;&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;border: solid windowtext 1.0pt; padding-top: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-left: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            Sel1&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border-left: none; border: solid windowtext 1.0pt; padding-top: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-left: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            Sel2&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;border: solid windowtext 1.0pt; border-top: none; padding-top: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-left: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            Sel3&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border-left: none; border-top: none; padding-top: .75pt; padding-right: .75pt; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; padding-bottom: .75pt; padding-left: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            Sel4.&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;    &lt;/table&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      &#xa;    &lt;/p&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Anda bisa menggunakan berbagai &lt;font color=&quot;#999900&quot;&gt;warna latar depan.&lt;/font&gt;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_854898297" CREATED="1124560950732" MODIFIED="1209285514234"/>
<node TEXT="Node HTML dan gambar tidak didukung ketika mengekspor teks atau RTP (Word, Wordpad). Minimal, penggunaan HTML adalah cara yang mudah untuk publikasi di Web menggunakan applet Freeplane." ID="ID_919917120" CREATED="1124560950732" MODIFIED="1209285575412">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node TEXT="Menggunakan gambar dalam node" FOLDED="true" POSITION="right" ID="Freeplane_Link_271176250" CREATED="1124560950732" MODIFIED="1209286979321" COLOR="#407000">
<font NAME="SansSerif" SIZE="12"/>
<node TEXT="Untuk menyisipkan gambar ke dalam Freeplane, tekan ALT + SHIFT + K, atau dari menu konteks node, pilih Sisip &gt; Gambar. Dengan menyisipkan gambar, Anda akan kehiangan semua teks yang sebelumnya ada dalam node tersebut. Gambar yang dimasukkan dengan cara ini tidak akan ditempelkan secara benar di luar Freeplane dan mungkin tidak akan terekspor secara benar ke HTML. Gambar dalam Freeplane masih merupakan fitur tahap awal." ID="ID_187126341" CREATED="1124560950732" MODIFIED="1209287077452"/>
<node TEXT="Format gambar yang didukung adalah PNG, JPEG dan GIF." ID="ID_1340853323" CREATED="1124560950732" MODIFIED="1209287107225" STYLE="fork"/>
<node TEXT="Untuk mengubah tautan ke gambar menjadi gambar yang tertampilkan, tekan ALT + SHIFT + K. Anda dapat menyeret dan menjatuhkan beberapa berkas gambar ke dalam Freeplane, memilih beberapa node sekaligus, lalu mengubah semuanya menjadi gambar dengan menekan ALT + SHIFT + K." ID="ID_987713301" CREATED="1124560950732" MODIFIED="1209287766393"/>
<node TEXT="Cara yang lebih teknis dan sedikit lebih sukar untuk menyisipkan gambar adalah sebagai berikut. Anda dapat memasukkan HTML dalam node. Anda perlu memulai isi node dengan tanda &lt;html&gt;. Dengan cara ini, Anda bisa memasukkan gambar ke dalam node." ID="ID_238102754" CREATED="1124560950732" MODIFIED="1209287838507" COLOR="#000000">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Sebagai contoh&#xa;  &lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;&#xa;  &lt;html&gt;&lt;img src=&quot;file://C:/Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;&#xa;" ID="ID_412481192" CREATED="1124560950732" MODIFIED="1209287848180">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Anda dapat menggunakan taut relatif untuk gambar." ID="ID_1072263410" CREATED="1124560950732" MODIFIED="1209287867909">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node TEXT="Contoh gambar, berhasil dengan baik di beberapa distribusi Windows" ID="Freeplane_Link_1825247742" CREATED="1124560950732" MODIFIED="1209287950708" COLOR="#996600">
<font NAME="SansSerif" SIZE="12" BOLD="true"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF&quot;&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_325280427" CREATED="1124560950732" MODIFIED="1124560950732"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF&quot;&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1959298514" CREATED="1124560950732" MODIFIED="1124560950732"/>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF&quot;&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_759752350" CREATED="1124560950732" MODIFIED="1124560950732">
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF&quot;&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1865341323" CREATED="1124560950732" MODIFIED="1124560950732"/>
</node>
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF&quot;&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_280022215" CREATED="1124560950732" MODIFIED="1124560950732">
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF&quot;&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1587596019" CREATED="1124560950732" MODIFIED="1124560950732">
<node TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF&quot;&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;" ID="ID_1942337749" CREATED="1124560950732" MODIFIED="1124560950732"/>
</node>
</node>
<node TEXT="GLOBE.WMF" ID="ID_585304648" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF"/>
<node TEXT="STONE.BMP" ID="ID_694785743" CREATED="1124560950732" MODIFIED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP"/>
</node>
</node>
<node TEXT="Menggunakan penguncian berkas eksperimental" FOLDED="true" POSITION="right" ID="ID_389666008" CREATED="1124560950732" MODIFIED="1209287968654" COLOR="#407000">
<node TEXT="Versi Freeplane saa ini memiliki penguncian berkas eksperimental, yang secara bawaan dinonaktifkan. Implementasi saat ini tidak mencegah konflik penyuntingan (race condition) secara sempurna, tapi mestinya cukup untuk kebanyakan kegunaan praktis. " ID="ID_783273897" CREATED="1124560950732" MODIFIED="1209289277205"/>
<node TEXT="Penguncian berkas memastikan tidak ada lebih dari satu pemakai yang mengedit suatu peta pada saat yang sama, sehingga mencegah agar mereka tidak saling menimpa informasi tanpa sengaja." ID="ID_540318221" CREATED="1124560950732" MODIFIED="1209288452680"/>
<node TEXT="Untuk mengaktifkan penguncian berkas eksperimental, dari menu, pilih Alat &gt; Preferensi." ID="ID_1073463144" CREATED="1124560950732" MODIFIED="1209288477115"/>
</node>
</node>
</map>
