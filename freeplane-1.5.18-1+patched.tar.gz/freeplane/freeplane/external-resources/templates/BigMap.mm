<map version="freeplane 1.5.3">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node LOCALIZED_TEXT="new_mindmap">
<hook NAME="MapStyle">
<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24 pt"  TEXT_SHORTENED="true">
<font SIZE="24"/>
<richcontent TYPE="DETAILS" LOCALIZED_HTML="styles_background_html"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="default" COLOR="#000000" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0.0 pt" TEXT_ALIGN="CENTER" MAX_WIDTH_QUANTITY="120.0 pt" MIN_WIDTH_QUANTITY="120.0 pt">
<font NAME="Arial" SIZE="9" BOLD="true" ITALIC="false"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details">
<font SIZE="11" BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#000000" BACKGROUND_COLOR="#ffffff">
<font SIZE="9" BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#000000" BACKGROUND_COLOR="#ffffff" TEXT_ALIGN="LEFT">
<font BOLD="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
<edge COLOR="#0000cc"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right">
<font SIZE="9"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" UNIFORM_SHAPE="true" MAX_WIDTH_QUANTITY="120.0 pt" MIN_WIDTH_QUANTITY="120.0 pt">
<font SIZE="24" ITALIC="true"/>
<edge STYLE="bezier" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2">
<edge COLOR="#ff0033"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3">
<edge COLOR="#009933"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4">
<edge COLOR="#3333ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5">
<edge COLOR="#ff6600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6">
<edge COLOR="#cc00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7">
<edge COLOR="#ffbf00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8">
<edge COLOR="#00ff99"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9">
<edge COLOR="#0099ff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10">
<edge COLOR="#996600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11">
<edge COLOR="#000000"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12">
<edge COLOR="#cc0066"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13">
<edge COLOR="#33ff00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14">
<edge COLOR="#ff9999"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15">
<edge COLOR="#0000cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16">
<edge COLOR="#cccc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17">
<edge COLOR="#0099cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18">
<edge COLOR="#006600"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19">
<edge COLOR="#ff00cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20">
<edge COLOR="#00cc00"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21">
<edge COLOR="#0066cc"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22">
<edge COLOR="#00ffff"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<font SIZE="24"/>
<hook NAME="AutomaticEdgeColor" COUNTER="0" RULE="FOR_COLUMNS"/>
</node>
</map>
