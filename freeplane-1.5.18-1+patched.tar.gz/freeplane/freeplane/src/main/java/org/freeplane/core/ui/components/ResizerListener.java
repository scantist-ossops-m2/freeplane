package org.freeplane.core.ui.components;


public interface ResizerListener {
	public void componentResized(ResizeEvent event);
}
