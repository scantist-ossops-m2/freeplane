package org.freeplane.core.ui.menubuilders.generic;


public interface EntryPopupListener {

	void childEntriesWillBecomeVisible(Entry entry);

	void childEntriesHidden(Entry entry);

}
