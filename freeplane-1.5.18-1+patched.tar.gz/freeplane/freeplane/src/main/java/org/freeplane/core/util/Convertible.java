package org.freeplane.core.util;

public interface Convertible {
	double factor();
}
