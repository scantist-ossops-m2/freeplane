package org.freeplane.core.ui.components;

public interface IKeyBindingManager {
	public boolean isKeyBindingProcessed();
}
